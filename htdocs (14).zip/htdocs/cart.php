<?php
require __DIR__ . '/includes/bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $action = post('action', 20);
    $id = (int)($_POST['id'] ?? 0);

    if ($action === 'add') {
        $qty = max(1, (int)($_POST['qty'] ?? 1));
        if (cart_add($id, $qty)) {
            flash('success', 'Added to your cart.');
        } else {
            flash('error', 'Sorry, that product is not available.');
        }
    } elseif ($action === 'update') {
        foreach (($_POST['qty'] ?? []) as $pid => $qty) {
            cart_set((int)$pid, (int)$qty);
        }
        flash('success', 'Cart updated.');
    } elseif ($action === 'remove') {
        cart_set($id, 0);
        flash('success', 'Item removed.');
    } elseif ($action === 'coupon') {
        $code = strtoupper(post('coupon', 30));
        if ($code === '') {
            unset($_SESSION['coupon']);
        } elseif (isset(COUPONS[$code])) {
            $_SESSION['coupon'] = $code;
            flash('success', "Coupon $code applied: " . COUPONS[$code] . '% off.');
        } else {
            flash('error', 'That coupon code is not valid.');
        }
    } elseif ($action === 'zone') {
        $z = post('zone', 20);
        if (isset(ZONES[$z])) {
            $_SESSION['zone'] = $z;
        }
    }
    redirect('cart.php');
}

$items = cart_items();
$zone = $_SESSION['zone'] ?? 'masaka';
$t = cart_totals($items, $zone, $_SESSION['coupon'] ?? '');
$title = 'Your cart';
require __DIR__ . '/includes/header.php';
?>
<h1>Your cart</h1>
<?php if (!$items): ?>
  <div class="empty"><p>Your cart is empty.</p><a class="btn" href="<?= e(url('products.php')) ?>">Start shopping</a></div>
<?php else: ?>
<div class="cart-layout">
  <form method="post" action="<?= e(url('cart.php')) ?>" class="cart-table">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="update">
    <?php foreach ($items as $i): ?>
      <div class="cart-row">
        <a class="thumb" href="<?= e(url('product.php?slug=' . $i['slug'])) ?>"><?= product_media($i) ?></a>
        <div class="info">
          <a href="<?= e(url('product.php?slug=' . $i['slug'])) ?>"><strong><?= e($i['name']) ?></strong></a>
          <span class="muted"><?= e($i['brand']) ?> · <?= e(money($i['price'])) ?> each</span>
          <button class="link" type="submit" form="rm-<?= (int)$i['id'] ?>">Remove</button>
        </div>
        <label class="qty">Qty
          <input type="number" name="qty[<?= (int)$i['id'] ?>]" value="<?= (int)$i['qty'] ?>" min="0" max="<?= min(20, (int)$i['stock']) ?>">
        </label>
        <div class="line"><?= e(money($i['line'])) ?></div>
      </div>
    <?php endforeach; ?>
    <div class="cart-actions">
      <a class="btn ghost" href="<?= e(url('products.php')) ?>">← Continue shopping</a>
      <button class="btn ghost" type="submit">Update quantities</button>
    </div>
  </form>
  <?php foreach ($items as $i): ?>
    <form id="rm-<?= (int)$i['id'] ?>" method="post" action="<?= e(url('cart.php')) ?>" hidden>
      <?= csrf_field() ?><input type="hidden" name="action" value="remove"><input type="hidden" name="id" value="<?= (int)$i['id'] ?>">
    </form>
  <?php endforeach; ?>

  <aside class="summary">
    <h2>Order summary</h2>
    <form method="post" action="<?= e(url('cart.php')) ?>" class="inline-form">
      <?= csrf_field() ?><input type="hidden" name="action" value="zone">
      <label>Delivery estimate
        <select name="zone" data-autosubmit>
          <?php foreach (ZONES as $k => $z): ?>
            <option value="<?= e($k) ?>" <?= $zone === $k ? 'selected' : '' ?>><?= e($z[0]) ?></option>
          <?php endforeach; ?>
        </select>
      </label>
      <noscript><button class="btn small" type="submit">Set</button></noscript>
    </form>
    <form method="post" action="<?= e(url('cart.php')) ?>" class="inline-form">
      <?= csrf_field() ?><input type="hidden" name="action" value="coupon">
      <label>Coupon code
        <span class="row"><input type="text" name="coupon" value="<?= e($_SESSION['coupon'] ?? '') ?>" placeholder="e.g. STUDENT10" maxlength="30"><button class="btn small" type="submit">Apply</button></span>
      </label>
    </form>
    <dl class="totals">
      <div><dt>Subtotal</dt><dd><?= e(money($t['subtotal'])) ?></dd></div>
      <?php if ($t['discount']): ?><div class="good"><dt>Discount (<?= e($t['coupon']) ?>)</dt><dd>-<?= e(money($t['discount'])) ?></dd></div><?php endif; ?>
      <div><dt>Delivery</dt><dd><?= $t['delivery'] ? e(money($t['delivery'])) : 'Free' ?></dd></div>
      <div class="grand"><dt>Total</dt><dd><?= e(money($t['total'])) ?></dd></div>
    </dl>
    <a class="btn block" href="<?= e(url('checkout.php')) ?>">Proceed to checkout</a>
    <p class="muted small"><?= pesajet_enabled() ? 'Secure checkout · Pay with MTN or Airtel mobile money, or on delivery.' : 'Secure checkout · Payments are simulated; no real money is charged.' ?></p>
  </aside>
</div>
<?php endif; ?>
<?php require __DIR__ . '/includes/footer.php'; ?>

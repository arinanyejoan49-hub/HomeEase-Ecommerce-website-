# Business concept and requirements analysis (DRAFT: edit in your own words)

## 1. Business concept
**HomeEase** is an online e-tailer (B2C retail model) selling affordable kitchen and home appliances in Uganda.
- **Target customers:** university and college students moving into hostels or rented rooms; young families and first-time home setters; budget-conscious households in Kampala, Greater Kampala and upcountry.
- **Value proposition:** genuine, warranty-backed appliances at low prices; a student discount and starter bundle; fast delivery in Kampala; mobile money and cash on delivery; honest specifications and energy ratings.
- **E-commerce type:** B2C online retailer (pure-play, with store pickup).
- **Revenue model:** product sales margin (main); delivery fees; later: extended warranty/installation services, supplier-paid featured listings.
- **Competitors / context:** physical shops in Kampala, Jumia Uganda, Facebook/WhatsApp sellers. Differentiation: student focus, transparency, trust and local payment.

## 2. Functional requirements
| ID | Requirement |
|----|-------------|
| F1 | Customers browse products by category and see price, brand, specs, stock, warranty |
| F2 | Customers search and filter by brand and price, and sort results |
| F3 | Customers add products to a cart, change quantity, remove items, see totals |
| F4 | Customers apply a coupon and choose a delivery option, with the fee shown |
| F5 | Customers check out as guests and pay by mobile money, card or cash on delivery (test mode) |
| F6 | System reduces stock when an order is placed and prevents overselling |
| F7 | Customers see an order confirmation and can track an order using number + email |
| F8 | Customers can contact support, read an FAQ and reach the shop on WhatsApp |
| F9 | Admin logs in securely and manages products (add, edit, hide, delete, image upload) |
| F10 | Admin views orders, updates status and views customer messages |
| F11 | Site shows delivery, returns, privacy and terms information |
| F12 | Site records visits with Google Analytics, after consent |

## 3. Non-functional requirements
- **Usability / mobile:** most Ugandan users browse on phones, so the layout is mobile-first and responsive
- **Performance:** light pages (no frameworks, system fonts, lazy-loaded images) for slow or costly mobile data
- **Security:** hashed passwords, SQL injection and XSS protection, CSRF tokens, no card storage, HTTPS
- **Reliability:** order and stock updates in one database transaction
- **Privacy / legal:** Data Protection and Privacy Act 2019, consent for analytics cookies
- **Localisation:** UGX prices, Ugandan phone number validation, MTN and Airtel mobile money
- **Maintainability:** simple PHP/MySQL, documented, kept in Git
- **Accessibility:** semantic HTML, labels, keyboard focus styles, alt text, sufficient contrast
- **Compatibility:** works on current Chrome, Firefox, Safari, Edge and on shared PHP/MySQL free hosting

## 4. Platform and hosting rationale (complete after deployment)
Custom PHP/MySQL (not Shopify/WooCommerce) because the course requires hand-built code and understanding; free shared hosting (e.g. InfinityFree) because it supports PHP 8, MySQL, phpMyAdmin and free SSL at no cost, which suits a student project. Limitation: shared hosting is slower and has no guaranteed uptime.

## 5. International, ethical and sustainability considerations
- International: imported brands, 220-240 V compatibility, UGX pricing with a plan for other East African currencies and cross-border delivery
- Ethical: honest prices and specifications, privacy and consent, no stored card data, fair returns
- Sustainability: energy-rating badges, e-waste take-back, repair-first warranty

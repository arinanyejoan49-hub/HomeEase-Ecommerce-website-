# AI usage disclosure and log (complete this honestly)

**Tool(s) used:** Claude (Anthropic), via claude.ai. Add any others.

| Date | Part of the site | What I asked the AI | What I changed or checked myself |
|------|------------------|---------------------|----------------------------------|
| 27 Oct 2026 | Whole project scaffold | Generate a PHP/MySQL store for affordable home appliances (catalogue, cart, test checkout, admin, policy pages) based on my project brief | (write here: what you read, tested and edited) |
| | | | |

## Be ready to explain
- How `db()` and prepared statements in `includes/bootstrap.php` prevent SQL injection
- How the cart is stored in the session and totals are recalculated from the database
- How `checkout.php` validates a card (Luhn check), why it stores only the last 4 digits, and how the stock transaction works
- How CSRF tokens, password hashing and the admin login rate limit work
- How the database tables relate (products, categories, orders, order_items)

<?php
require __DIR__ . '/includes/bootstrap.php';

$order = null;
$items = [];
$searched = false;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $searched = true;
    $no = strtoupper(preg_replace('/\s+/', '', post('order_no', 24)));
    $email = strtolower(post('email', 160));
    // Both order number AND email must match, so order details cannot be guessed.
    $order = q(
        'SELECT * FROM orders WHERE UPPER(TRIM(order_no)) = ? AND LOWER(TRIM(email)) = ?',
        [$no, $email]
    )->fetch() ?: null;
    if ($order) {
        $items = q('SELECT oi.*, p.slug, p.image FROM order_items oi LEFT JOIN products p ON p.id = oi.product_id WHERE oi.order_id = ? ORDER BY oi.id', [$order['id']])->fetchAll();
    }
}
$title = 'Track your order';
require __DIR__ . '/includes/header.php';
$steps = ['pending' => 'Order received', 'confirmed' => 'Confirmed', 'dispatched' => 'Out for delivery', 'delivered' => 'Delivered'];
?>
<h1>Track your order</h1>
<form method="post" class="narrow panel" action="<?= e(url('track.php')) ?>">
  <?= csrf_field() ?>
  <label>Order number <input name="order_no" required placeholder="HE-261027-ABC123" maxlength="24" value="<?= e($_POST['order_no'] ?? '') ?>"></label>
  <label>Email used at checkout <input type="email" name="email" required maxlength="160" value="<?= e($_POST['email'] ?? '') ?>"></label>
  <button class="btn" type="submit">Find my order</button>
</form>

<?php if ($searched && !$order): ?>
  <div class="alert error">We could not find an order with that number and email. Check both and try again, or <a href="<?= e(url('contact.php')) ?>">contact us</a>.</div>
<?php elseif ($order): ?>
  <section class="panel">
    <h2>Order <?= e($order['order_no']) ?></h2>
    <?php if ($order['status'] === 'cancelled'): ?>
      <p class="alert error">This order was cancelled.</p>
    <?php else:
        $keys = array_keys($steps);
        $idx = array_search($order['status'], $keys, true);
        if ($idx === false) { $idx = 0; } ?>
      <ol class="timeline">
        <?php foreach ($keys as $n => $k): ?>
          <li class="<?= $n < $idx ? 'done' : ($n === $idx ? 'current' : '') ?>"><?= e($steps[$k]) ?></li>
        <?php endforeach; ?>
      </ol>
    <?php endif; ?>
    <p>Placed <?= e(date('j M Y, H:i', strtotime($order['created_at']))) ?> · Payment: <?= e(payment_status_label($order['payment_status'])) ?> · Delivery: <?= e((ZONES[$order['zone']][0] ?? '')) ?></p>
    <ul class="mini-items">
      <?php foreach ($items as $i): ?>
      <li class="order-item">
        <span class="order-item-product"><?= product_media($i, 'order-item-image') ?><span><?= e($i['name']) ?> × <?= (int)$i['qty'] ?></span></span>
        <b class="order-item-price"><?= e(money($i['price'] * $i['qty'])) ?></b>
      </li>
      <?php endforeach; ?>
    </ul>
    <p><strong>Total: <?= e(money($order['total'])) ?></strong></p>
    <?php if (receipt_is_paid($order)): ?><p><a class="btn small" href="<?= e(receipt_url($order)) ?>">View receipt</a></p><?php endif; ?>
  </section>
<?php endif; ?>
<?php require __DIR__ . '/includes/footer.php'; ?>

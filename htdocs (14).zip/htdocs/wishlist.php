<?php
require __DIR__ . '/includes/bootstrap.php';
require __DIR__ . '/includes/card.php';

$title = 'Wishlist';
$desc = 'Your saved items. Add products to your wishlist and come back to buy them later.';
$here = 'wishlist.php';

$action = $_GET['action'] ?? '';
$id = (int)($_GET['id'] ?? 0);
if ($action === 'add' && $id) { wishlist_add($id); redirect('wishlist.php'); }
if ($action === 'remove' && $id) { wishlist_remove($id); redirect('wishlist.php'); }

$items = wishlist_items();
require __DIR__ . '/includes/header.php';
?>
<h1>Wishlist</h1>
<?php if (!$items): ?>
  <div class="empty"><p>Your wishlist is empty.</p><a class="btn" href="<?= e(url('products.php')) ?>">Start shopping</a></div>
<?php else: ?>
  <p class="muted"><?= count($items) ?> saved item<?= count($items) === 1 ? '' : 's' ?></p>
  <div class="grid"><?php foreach ($items as $p) product_card($p); ?></div>
  <p class="muted small">Remove an item by opening it and clicking "Remove from wishlist", or add items from any product page.</p>
<?php endif; ?>
<?php require __DIR__ . '/includes/footer.php'; ?>

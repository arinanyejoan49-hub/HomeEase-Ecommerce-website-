-- Add products represented by the downloaded photos and connect existing
-- sample products to their matching branded photos. Safe to run more than once.
START TRANSACTION;

UPDATE products
SET image = CASE slug
    WHEN 'microwave-oven-20l' THEN 'microwave-oven-20l-lifestyle.webp'
    WHEN 'air-fryer-4l' THEN 'air-fryer-4l-white.webp'
    WHEN 'double-door-fridge-200l' THEN 'double-door-fridge-200l.webp'
    WHEN '2-plate-electric-hotplate' THEN '2-plate-electric-hotplate.jpg'
    WHEN 'rechargeable-fan-light' THEN 'rechargeable-fan-light.webp'
    WHEN 'non-stick-cookware-set-7pc' THEN 'tefal-non-stick-cookware-set-7pc.webp'
    WHEN 'solar-rechargeable-led-lamp' THEN 'solar-rechargeable-led-lamp.webp'
    ELSE image
END
WHERE image = ''
  AND slug IN (
    'microwave-oven-20l', 'air-fryer-4l', 'double-door-fridge-200l',
    '2-plate-electric-hotplate', 'rechargeable-fan-light',
    'non-stick-cookware-set-7pc', 'solar-rechargeable-led-lamp'
  );

INSERT INTO products (category_id, name, slug, brand, description, specs, price, old_price, stock, energy_rating, warranty_months, is_featured, image)
SELECT 1, 'Mini Blender Personal', 'mini-blender-personal', '', 'A compact personal blender for smoothies and drinks on the go.', 'Type: Personal blender', 85000, NULL, 10, '', 12, 0, 'mini-blender-personal.webp'
WHERE NOT EXISTS (SELECT 1 FROM products WHERE slug = 'mini-blender-personal');
INSERT INTO products (category_id, name, slug, brand, description, specs, price, old_price, stock, energy_rating, warranty_months, is_featured, image)
SELECT 9, 'Air Cooler 20L', 'air-cooler-20l', '', 'A portable air cooler for keeping a room comfortable.', 'Capacity: 20 L', 350000, NULL, 10, '', 12, 0, 'air-cooler-20l.webp'
WHERE NOT EXISTS (SELECT 1 FROM products WHERE slug = 'air-cooler-20l');
INSERT INTO products (category_id, name, slug, brand, description, specs, price, old_price, stock, energy_rating, warranty_months, is_featured, image)
SELECT 4, 'Clothes Dryer 7kg', 'clothes-dryer-7kg', '', 'A 7 kg clothes dryer for household laundry.', 'Capacity: 7 kg', 550000, NULL, 10, '', 12, 0, ''
WHERE NOT EXISTS (SELECT 1 FROM products WHERE slug = 'clothes-dryer-7kg');
INSERT INTO products (category_id, name, slug, brand, description, specs, price, old_price, stock, energy_rating, warranty_months, is_featured, image)
SELECT 1, 'Coffee Maker 12-Cup', 'coffee-maker-12-cup', '', 'A countertop coffee maker for home use.', 'Capacity: 12 cups', 150000, NULL, 10, '', 12, 0, 'coffee-maker-12-cup.webp'
WHERE NOT EXISTS (SELECT 1 FROM products WHERE slug = 'coffee-maker-12-cup');
INSERT INTO products (category_id, name, slug, brand, description, specs, price, old_price, stock, energy_rating, warranty_months, is_featured, image)
SELECT 6, 'Desk Lamp LED', 'desk-lamp-led', '', 'An LED desk lamp for reading and workspace lighting.', 'Light source: LED', 45000, NULL, 10, '', 12, 0, 'desk-lamp-led.webp'
WHERE NOT EXISTS (SELECT 1 FROM products WHERE slug = 'desk-lamp-led');
INSERT INTO products (category_id, name, slug, brand, description, specs, price, old_price, stock, energy_rating, warranty_months, is_featured, image)
SELECT 1, 'Electric Deep Fryer 3L', 'electric-deep-fryer-3l', '', 'A countertop electric deep fryer for home cooking.', 'Capacity: 3 L', 250000, NULL, 10, '', 12, 0, 'electric-deep-fryer-3l.webp'
WHERE NOT EXISTS (SELECT 1 FROM products WHERE slug = 'electric-deep-fryer-3l');
INSERT INTO products (category_id, name, slug, brand, description, specs, price, old_price, stock, energy_rating, warranty_months, is_featured, image)
SELECT 1, 'Electric Griddle', 'electric-griddle', '', 'An electric griddle for countertop cooking.', '', 150000, NULL, 10, '', 12, 0, 'electric-griddle.webp'
WHERE NOT EXISTS (SELECT 1 FROM products WHERE slug = 'electric-griddle');
INSERT INTO products (category_id, name, slug, brand, description, specs, price, old_price, stock, energy_rating, warranty_months, is_featured, image)
SELECT 2, 'Electric Oven 30L', 'electric-oven-30l', '', 'A countertop electric oven for everyday cooking.', 'Capacity: 30 L', 320000, NULL, 10, '', 12, 0, 'electric-oven-30l.webp'
WHERE NOT EXISTS (SELECT 1 FROM products WHERE slug = 'electric-oven-30l');
INSERT INTO products (category_id, name, slug, brand, description, specs, price, old_price, stock, energy_rating, warranty_months, is_featured, image)
SELECT 1, 'Food Processor 2L', 'food-processor-2l', '', 'A food processor for preparing ingredients at home.', 'Capacity: 2 L', 250000, NULL, 10, '', 12, 0, ''
WHERE NOT EXISTS (SELECT 1 FROM products WHERE slug = 'food-processor-2l');
INSERT INTO products (category_id, name, slug, brand, description, specs, price, old_price, stock, energy_rating, warranty_months, is_featured, image)
SELECT 4, 'Fully Automatic Washing Machine 8kg', 'fully-automatic-washing-machine-8kg', '', 'A fully automatic washing machine for household laundry.', 'Wash capacity: 8 kg', 1200000, NULL, 10, '', 12, 0, 'fully-automatic-washing-machine-8kg.webp'
WHERE NOT EXISTS (SELECT 1 FROM products WHERE slug = 'fully-automatic-washing-machine-8kg');
INSERT INTO products (category_id, name, slug, brand, description, specs, price, old_price, stock, energy_rating, warranty_months, is_featured, image)
SELECT 2, 'Gas Oven with Hob', 'gas-oven-with-hob', '', 'A gas oven with a hob for kitchen cooking.', '', 850000, NULL, 10, '', 12, 0, 'gas-oven-with-hob.webp'
WHERE NOT EXISTS (SELECT 1 FROM products WHERE slug = 'gas-oven-with-hob');
INSERT INTO products (category_id, name, slug, brand, description, specs, price, old_price, stock, energy_rating, warranty_months, is_featured, image)
SELECT 14, 'LED Ring Light with Stand', 'led-ring-light-with-stand', '', 'An LED ring light supplied with a stand for home-office use.', 'Light source: LED\nIncludes: Stand', 85000, NULL, 10, '', 12, 0, 'led-ring-light-with-stand.webp'
WHERE NOT EXISTS (SELECT 1 FROM products WHERE slug = 'led-ring-light-with-stand');
INSERT INTO products (category_id, name, slug, brand, description, specs, price, old_price, stock, energy_rating, warranty_months, is_featured, image)
SELECT 6, 'Power Bank 20000mAh', 'power-bank-20000mah', '', 'A portable power bank for charging compatible devices.', 'Capacity: 20000 mAh', 75000, NULL, 10, '', 12, 0, 'power-bank-20000mah.webp'
WHERE NOT EXISTS (SELECT 1 FROM products WHERE slug = 'power-bank-20000mah');
INSERT INTO products (category_id, name, slug, brand, description, specs, price, old_price, stock, energy_rating, warranty_months, is_featured, image)
SELECT 2, 'Pressure Cooker 6L', 'pressure-cooker-6l', '', 'A 6 L pressure cooker for preparing meals at home.', 'Capacity: 6 L', 180000, NULL, 10, '', 12, 0, 'pressure-cooker-6l.webp'
WHERE NOT EXISTS (SELECT 1 FROM products WHERE slug = 'pressure-cooker-6l');
INSERT INTO products (category_id, name, slug, brand, description, specs, price, old_price, stock, energy_rating, warranty_months, is_featured, image)
SELECT 3, 'Single Door Fridge 135L', 'single-door-fridge-135l', '', 'A 135 L single-door refrigerator for home or hostel use.', 'Capacity: 135 L\nDoors: 1', 750000, NULL, 10, '', 12, 0, 'single-door-fridge-135l.webp'
WHERE NOT EXISTS (SELECT 1 FROM products WHERE slug = 'single-door-fridge-135l');
INSERT INTO products (category_id, name, slug, brand, description, specs, price, old_price, stock, energy_rating, warranty_months, is_featured, image)
SELECT 8, 'Steam Mop', 'steam-mop', '', 'A steam mop for household floor cleaning.', '', 280000, NULL, 10, '', 12, 0, 'steam-mop.webp'
WHERE NOT EXISTS (SELECT 1 FROM products WHERE slug = 'steam-mop');
INSERT INTO products (category_id, name, slug, brand, description, specs, price, old_price, stock, energy_rating, warranty_months, is_featured, image)
SELECT 13, 'Water Dispenser', 'water-dispenser', '', 'A water dispenser for home or office use.', '', 400000, NULL, 10, '', 12, 0, 'water-dispenser.webp'
WHERE NOT EXISTS (SELECT 1 FROM products WHERE slug = 'water-dispenser');
INSERT INTO products (category_id, name, slug, brand, description, specs, price, old_price, stock, energy_rating, warranty_months, is_featured, image)
SELECT 2, 'Nutrichef Non-stick Cookware Set', 'nutrichef-non-stick-cookware-set', 'Nutrichef', 'A non-stick cookware set for everyday kitchen use.', '', 250000, NULL, 10, '', 12, 0, 'nutrichef-blue-cookware-set.avif'
WHERE NOT EXISTS (SELECT 1 FROM products WHERE slug = 'nutrichef-non-stick-cookware-set');

COMMIT;

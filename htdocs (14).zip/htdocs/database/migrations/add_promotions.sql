-- Admin-managed homepage promotions ("Promotion of the month").
-- The app also creates this table automatically the first time it is needed,
-- so running this file is optional.
CREATE TABLE IF NOT EXISTS promotions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  badge VARCHAR(60) NOT NULL DEFAULT '',
  title VARCHAR(120) NOT NULL,
  button_text VARCHAR(40) NOT NULL DEFAULT 'Shop the offer',
  link_url VARCHAR(255) NOT NULL DEFAULT 'products.php',
  starts_at DATETIME NOT NULL,
  ends_at DATETIME NOT NULL,
  color_from CHAR(7) NOT NULL DEFAULT '#E86A00',
  color_to CHAR(7) NOT NULL DEFAULT '#B84400',
  color_accent CHAR(7) NOT NULL DEFAULT '#FFF1DD',
  color_text CHAR(7) NOT NULL DEFAULT '#FFFFFF',
  sort_order INT NOT NULL DEFAULT 0,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO promotions (badge, title, button_text, link_url, starts_at, ends_at, sort_order, is_active)
SELECT 'Black Friday offer', 'Black Friday', 'Shop the offer', 'products.php', '2026-11-01 00:00:00', '2026-11-27 23:59:59', 1, 1
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM promotions WHERE title = 'Black Friday');

INSERT INTO promotions (badge, title, button_text, link_url, starts_at, ends_at, sort_order, is_active)
SELECT 'November offer', 'Black November', 'Shop the offer', 'products.php', '2026-11-01 00:00:00', '2026-11-30 23:59:59', 2, 1
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM promotions WHERE title = 'Black November');

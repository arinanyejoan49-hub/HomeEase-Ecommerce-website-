-- Payment receipts (one per paid order). The site also creates this table automatically on first load
-- (ensure_tables in includes/bootstrap.php), so running this file is optional.
CREATE TABLE IF NOT EXISTS order_receipts (
  id INT AUTO_INCREMENT PRIMARY KEY,
  order_id INT NOT NULL,
  receipt_no VARCHAR(48) NOT NULL,
  issued_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  emailed_at DATETIME NULL,
  email_status VARCHAR(30) NOT NULL DEFAULT 'not_sent',
  email_error VARCHAR(255) NULL,
  UNIQUE KEY uniq_receipt_order (order_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Google sign-in: links a customer account to its Google account id.
-- Optional: the app adds this column automatically the first time someone signs in with Google.
ALTER TABLE users ADD COLUMN google_sub VARCHAR(64) NULL;
CREATE UNIQUE INDEX idx_users_google_sub ON users (google_sub);

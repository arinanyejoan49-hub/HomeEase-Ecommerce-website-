-- Preserve existing reset rows while allowing each reset token to belong to
-- either a customer (user_id) or an administrator (admin_id).
-- Back up the database before applying this migration.

SET @make_reset_user_nullable = IF(
    EXISTS (
        SELECT 1
        FROM information_schema.columns
        WHERE table_schema = DATABASE()
          AND table_name = 'password_resets'
          AND column_name = 'user_id'
          AND is_nullable = 'NO'
    ),
    'ALTER TABLE `password_resets` MODIFY `user_id` INT NULL',
    'SELECT 1'
);
PREPARE make_reset_user_nullable_stmt FROM @make_reset_user_nullable;
EXECUTE make_reset_user_nullable_stmt;
DEALLOCATE PREPARE make_reset_user_nullable_stmt;

SET @add_reset_admin_id = IF(
    EXISTS (
        SELECT 1
        FROM information_schema.columns
        WHERE table_schema = DATABASE()
          AND table_name = 'password_resets'
          AND column_name = 'admin_id'
    ),
    'SELECT 1',
    'ALTER TABLE `password_resets` ADD COLUMN `admin_id` INT NULL'
);
PREPARE add_reset_admin_id_stmt FROM @add_reset_admin_id;
EXECUTE add_reset_admin_id_stmt;
DEALLOCATE PREPARE add_reset_admin_id_stmt;

SET @add_reset_admin_index = IF(
    EXISTS (
        SELECT 1
        FROM information_schema.statistics
        WHERE table_schema = DATABASE()
          AND table_name = 'password_resets'
          AND index_name = 'idx_password_resets_admin'
    ),
    'SELECT 1',
    'CREATE INDEX `idx_password_resets_admin` ON `password_resets` (`admin_id`)'
);
PREPARE add_reset_admin_index_stmt FROM @add_reset_admin_index;
EXECUTE add_reset_admin_index_stmt;
DEALLOCATE PREPARE add_reset_admin_index_stmt;

SET @add_reset_admin_foreign_key = IF(
    EXISTS (
        SELECT 1
        FROM information_schema.key_column_usage
        WHERE constraint_schema = DATABASE()
          AND table_name = 'password_resets'
          AND column_name = 'admin_id'
          AND referenced_table_name = 'admins'
    ),
    'SELECT 1',
    'ALTER TABLE `password_resets` ADD CONSTRAINT `fk_password_resets_admin` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`) ON DELETE CASCADE'
);
PREPARE add_reset_admin_fk_stmt FROM @add_reset_admin_foreign_key;
EXECUTE add_reset_admin_fk_stmt;
DEALLOCATE PREPARE add_reset_admin_fk_stmt;

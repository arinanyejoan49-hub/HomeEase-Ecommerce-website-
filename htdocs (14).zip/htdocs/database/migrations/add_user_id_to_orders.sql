-- Add user_id to orders for customer-order relationships without dropping or
-- changing existing orders. Existing rows remain guest orders (user_id NULL).
SET @add_orders_user_id = IF(
    EXISTS (
        SELECT 1
        FROM information_schema.columns
        WHERE table_schema = DATABASE()
          AND table_name = 'orders'
          AND column_name = 'user_id'
    ),
    'SELECT 1',
    'ALTER TABLE `orders` ADD COLUMN `user_id` INT NULL'
);
PREPARE add_orders_user_id_stmt FROM @add_orders_user_id;
EXECUTE add_orders_user_id_stmt;
DEALLOCATE PREPARE add_orders_user_id_stmt;
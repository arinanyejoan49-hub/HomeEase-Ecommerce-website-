-- Apply once to an existing MySQL/MariaDB database that already has return_requests.
-- Existing requests are preserved and start with no refund claim.
ALTER TABLE return_requests
  ADD COLUMN refund_status VARCHAR(24) NOT NULL DEFAULT 'not_applicable';

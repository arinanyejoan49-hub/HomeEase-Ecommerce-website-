-- Admin-side notifications (shared feed for all admin accounts).
-- The site also creates this table automatically on first load (ensure_tables in includes/bootstrap.php),
-- so running this file is optional.
CREATE TABLE IF NOT EXISTS admin_notifications (
  id INT AUTO_INCREMENT PRIMARY KEY,
  type VARCHAR(24) NOT NULL DEFAULT 'order',
  title VARCHAR(160) NOT NULL,
  message VARCHAR(500) NOT NULL,
  link VARCHAR(255) NULL,
  is_read TINYINT(1) NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_admin_notif_read (is_read, id),
  INDEX idx_admin_notif_type (type, id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

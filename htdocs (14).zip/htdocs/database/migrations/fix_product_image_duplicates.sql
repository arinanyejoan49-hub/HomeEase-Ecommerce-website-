-- Correct existing image references without changing product or order data.
-- Apply once after the matching files are deployed to assets/products/.
START TRANSACTION;

UPDATE products
SET image = 'air-fryer-4l-white.webp'
WHERE slug = 'air-fryer-4l'
  AND name = 'Air Fryer 4L'
  AND image = '';

UPDATE products
SET image = 'double-door-fridge-200l.webp'
WHERE slug = 'double-door-fridge-200l'
  AND image = '015435d7859d84202d1b.webp';

UPDATE products
SET image = 'double-door-fridge-samsung-200l.webp'
WHERE name = 'Double Door Fridge 200L'
  AND image = '0c7b0dfb086b6865560d.webp';

UPDATE products
SET image = 'mini-blender-personal.webp'
WHERE slug = 'mini-blender-personal'
  AND image = 'Mini Blender Personal.webp';

UPDATE products
SET image = 'tefal-non-stick-cookware-set-7pc.webp'
WHERE name = 'Non-stick Cookware Set 7pc Tefal 11'
  AND image = 'Non-stick Cookware Set 7pc Tefal 11.webp';

COMMIT;

-- Roll back by restoring each row's previous image value from the statements above.
-- UPDATE products SET image = ''
-- WHERE slug = 'air-fryer-4l' AND name = 'Air Fryer 4L'
--   AND image = 'air-fryer-4l-white.webp';
-- UPDATE products SET image = '015435d7859d84202d1b.webp'
-- WHERE slug = 'double-door-fridge-200l'
--   AND image = 'double-door-fridge-200l.webp';
-- UPDATE products SET image = '0c7b0dfb086b6865560d.webp'
-- WHERE name = 'Double Door Fridge 200L'
--   AND image = 'double-door-fridge-samsung-200l.webp';
-- UPDATE products SET image = 'Mini Blender Personal.webp'
-- WHERE slug = 'mini-blender-personal'
--   AND image = 'mini-blender-personal.webp';
-- UPDATE products SET image = 'Non-stick Cookware Set 7pc Tefal 11.webp'
-- WHERE name = 'Non-stick Cookware Set 7pc Tefal 11'
--   AND image = 'tefal-non-stick-cookware-set-7pc.webp';

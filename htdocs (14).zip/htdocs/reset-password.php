<?php
require __DIR__ . '/includes/bootstrap.php';
header('Cache-Control: no-store');
header('Referrer-Policy: no-referrer');

$title = 'Reset password';
$desc = 'Set a new password.';
$here = 'reset-password.php';

$resetTableAvailable = table_exists('password_resets');
$customerAccountsAvailable = table_exists('users') && $resetTableAvailable;
$adminAccountsAvailable = table_exists('admins')
    && $resetTableAvailable
    && column_exists('password_resets', 'admin_id');
$resetAvailable = $customerAccountsAvailable || $adminAccountsAvailable;

$token = is_string($_GET['token'] ?? '') ? (string)($_GET['token'] ?? '') : '';
$tokenHash = $token !== '' ? hash('sha256', $token) : '';

$errors = [];
$values = ['password' => '', 'confirm' => ''];
$valid = false;
$resetRow = null;
$user = null;
$admin = null;

if ($resetAvailable && $tokenHash !== '') {
    $resetRow = q('SELECT * FROM password_resets WHERE token = ? AND used = 0 AND expires_at > CURRENT_TIMESTAMP', [$tokenHash])->fetch();
    if ($resetRow) {
        if (!empty($resetRow['user_id']) && $customerAccountsAvailable) {
            $user = q('SELECT * FROM users WHERE id = ? AND status = "active" AND role = "customer"', [(int)$resetRow['user_id']])->fetch();
            $valid = (bool)$user;
        } elseif (!empty($resetRow['admin_id']) && $adminAccountsAvailable) {
            $admin = q('SELECT * FROM admins WHERE id = ?', [(int)$resetRow['admin_id']])->fetch();
            $valid = (bool)$admin;
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    if (!$resetAvailable) {
        $errors['_general'] = 'Password reset is unavailable.';
    } elseif (!$valid) {
        $errors['_general'] = 'This reset link is invalid or has expired.';
    } else {
        $password = (string)($_POST['password'] ?? '');
        $confirm = (string)($_POST['confirm_password'] ?? '');
        if (strlen($password) < 8) { $errors['password'] = 'Password must be at least 8 characters.'; }
        elseif (!preg_match('/[A-Z]/', $password)) { $errors['password'] = 'Password must contain an uppercase letter.'; }
        elseif (!preg_match('/[a-z]/', $password)) { $errors['password'] = 'Password must contain a lowercase letter.'; }
        elseif (!preg_match('/[0-9]/', $password)) { $errors['password'] = 'Password must contain a number.'; }
        if ($confirm === '' || $confirm !== $password) { $errors['confirm_password'] = 'Passwords do not match.'; }

        if (empty($errors)) {
            $pdo = db();
            try {
                $pdo->beginTransaction();
                if ($user) {
                    q('UPDATE users SET password_hash = ?, updated_at = CURRENT_TIMESTAMP, remember_token = NULL, remember_expires = NULL WHERE id = ?', [password_hash($password, PASSWORD_DEFAULT), (int)$user['id']]);
                    q('UPDATE password_resets SET used = 1 WHERE user_id = ? AND used = 0', [(int)$user['id']]);
                } else {
                    q('UPDATE admins SET password_hash = ? WHERE id = ?', [password_hash($password, PASSWORD_DEFAULT), (int)$admin['id']]);
                    q('UPDATE password_resets SET used = 1 WHERE admin_id = ? AND used = 0', [(int)$admin['id']]);
                }
                $pdo->commit();
                flash('success', 'Your password has been reset. Please log in.');
                redirect('login.php');
            } catch (Throwable $e) {
                if ($pdo->inTransaction()) {
                    $pdo->rollBack();
                }
                error_log('Reset failed: ' . $e->getMessage());
                $errors['_general'] = 'Could not reset password. Please try again.';
            }
        }
    }
}

require __DIR__ . '/includes/header.php';
?>
<h1>Reset your password</h1>

<?php if (!empty($errors['_general'])): ?>
  <div class="alert error" role="alert"><?= e($errors['_general']) ?></div>
<?php endif; ?>

<?php if (!$resetAvailable): ?>
  <div class="alert error" role="alert">Account recovery is not set up yet.</div>
<?php elseif (!$valid): ?>
  <div class="alert error" role="alert">This reset link is invalid or has expired. <a href="<?= e(url('forgot-password.php')) ?>">Request a new one</a>.</div>
<?php else: ?>
<form method="post" action="<?= e(url('reset-password.php?token=' . urlencode($token))) ?>" class="auth-form" novalidate>
  <?= csrf_field() ?>
  <input type="hidden" name="token" value="<?= e($token) ?>">
  <div class="form-field">
    <label for="password">New Password <span class="required">*</span></label>
    <input type="password" id="password" name="password" minlength="8"
           <?= isset($errors['password']) ? 'aria-invalid="true"' : '' ?>>
    <?php if (isset($errors['password'])): ?><span class="field-error"><?= e($errors['password']) ?></span><?php endif; ?>
  </div>
  <div class="form-field">
    <label for="confirm_password">Confirm New Password <span class="required">*</span></label>
    <input type="password" id="confirm_password" name="confirm_password" minlength="8"
           <?= isset($errors['confirm_password']) ? 'aria-invalid="true"' : '' ?>>
    <?php if (isset($errors['confirm_password'])): ?><span class="field-error"><?= e($errors['confirm_password']) ?></span><?php endif; ?>
  </div>
  <div class="form-actions">
    <button type="submit" class="btn">Reset password</button>
  </div>
</form>
<?php endif; ?>

<p class="auth-switch"><a href="<?= e(url('login.php')) ?>">Back to login</a></p>

<?php require __DIR__ . '/includes/footer.php'; ?>
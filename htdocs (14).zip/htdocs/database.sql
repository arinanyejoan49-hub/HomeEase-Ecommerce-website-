-- Home Appliances E-commerce Website
-- User Account Registration and Management System
-- Safe migration: creates missing account tables and adds the nullable order
-- relationship column when needed.
-- Does NOT drop or modify existing tables. Import via phpMyAdmin.
-- Database: homeease (existing project database)

-- --------------------------------------------------------
-- 1. Users table (customer accounts)
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  first_name VARCHAR(100) NOT NULL,
  last_name VARCHAR(100) NOT NULL,
  username VARCHAR(50) NOT NULL UNIQUE,
  email VARCHAR(150) NOT NULL UNIQUE,
  phone VARCHAR(20) NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  gender VARCHAR(20) NULL,
  date_of_birth DATE NULL,
  country VARCHAR(100) NOT NULL DEFAULT 'Uganda',
  district VARCHAR(100) NULL,
  address VARCHAR(255) NULL,
  role VARCHAR(20) NOT NULL DEFAULT 'customer',
  status VARCHAR(20) NOT NULL DEFAULT 'active',
  google_sub VARCHAR(64) NULL UNIQUE,
  remember_token CHAR(64) NULL,
  remember_expires TIMESTAMP NULL DEFAULT NULL,
  terms_accepted_at TIMESTAMP NULL DEFAULT NULL,
  privacy_accepted_at TIMESTAMP NULL DEFAULT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_users_email (email),
  INDEX idx_users_username (username),
  INDEX idx_users_status (status),
  INDEX idx_users_role (role)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------
-- 2. Login attempts table (brute-force throttling)
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS login_attempts (
  id INT AUTO_INCREMENT PRIMARY KEY,
  identifier VARCHAR(255) NOT NULL,
  attempted_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  success TINYINT(1) NOT NULL DEFAULT 0,
  INDEX idx_login_attempts_identifier (identifier),
  INDEX idx_login_attempts_time (attempted_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------
-- 3. Password reset tokens table
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS password_resets (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NULL,
  admin_id INT NULL,
  token VARCHAR(64) NOT NULL UNIQUE,
  expires_at TIMESTAMP NOT NULL DEFAULT (CURRENT_TIMESTAMP + INTERVAL 1 HOUR),
  used TINYINT(1) NOT NULL DEFAULT 0,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_password_resets_admin (admin_id),
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (admin_id) REFERENCES admins(id) ON DELETE CASCADE,
  INDEX idx_password_resets_token (token),
  INDEX idx_password_resets_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Existing orders remain guest orders. This is compatible with MySQL versions
-- that do not support ALTER TABLE ... ADD COLUMN IF NOT EXISTS.
SET @add_orders_user_id = IF(
    EXISTS (
        SELECT 1
        FROM information_schema.columns
        WHERE table_schema = DATABASE()
          AND table_name = 'orders'
          AND column_name = 'user_id'
    ),
    'SELECT 1',
    'ALTER TABLE `orders` ADD COLUMN `user_id` INT NULL'
);
PREPARE add_orders_user_id_stmt FROM @add_orders_user_id;
EXECUTE add_orders_user_id_stmt;
DEALLOCATE PREPARE add_orders_user_id_stmt;

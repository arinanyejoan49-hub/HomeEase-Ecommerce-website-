<?php
define('HOMEEASE_TEST_SQLITE', true);
defined('DB_DRIVER') or define('DB_DRIVER', 'sqlite');
defined('DB_PATH') or define('DB_PATH', getenv('HOMEEASE_TEST_DB_PATH') ?: __DIR__ . '/test.sqlite');
defined('SITE_URL') or define('SITE_URL', getenv('HOMEEASE_TEST_SITE_URL') ?: 'http://127.0.0.1:8080');
defined('APP_ENV') or define('APP_ENV', 'development');

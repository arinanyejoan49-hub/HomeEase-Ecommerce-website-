import hashlib, os, re, sqlite3, sys, requests
from html import escape
from urllib.parse import parse_qs, quote, unquote, urljoin, urlparse
B = os.environ.get('HOMEEASE_TEST_BASE_URL', 'http://127.0.0.1:8080/')
TEST_DB = os.environ.get('HOMEEASE_TEST_DB_PATH', os.path.join(os.path.dirname(__file__), 'test.sqlite'))
def csrf(html): return re.search(r'name="csrf" value="([^"]+)"', html).group(1)
def ok(name, cond, extra=''):
    print(('PASS ' if cond else 'FAIL ') + name + (' ' + extra if (extra and not cond) else ''))
    if not cond: ok.fails += 1
ok.fails = 0

# Homepage hero carousel
store = requests.Session()
r = store.get(B + 'index.php')
ok('homepage shows four accessible hero slides', len(re.findall(r'class="hero-slide(?: is-active)?"', r.text)) == 4)
products_listing = store.get(B + 'products.php')
ok('back-to-top control is available only on products page', (
    'class="back-to-top"' not in r.text
    and 'class="back-to-top"' in products_listing.text
    and 'aria-label="Back to top"' in products_listing.text
    and ' hidden>' in products_listing.text
))
ok('homepage hero images are local assets', all('assets/images/hero/' + image in r.text for image in [
    'home-interior.jpg', 'modern-kitchen.jpg', 'laundry-room.jpg', 'smart-living-room.jpg',
]))
ok('homepage hero buttons link to existing shop routes', all(href in r.text for href in [
    'products.php', 'categories.php', 'products.php?cat=kitchen', 'products.php?cat=cleaning',
]))
category_cards = [
    card for card in re.findall(r'<a class="cat"[^>]*>.*?</a>', r.text, re.S)
    if 'class="cat-image category-image"' in card
]
ok('homepage category cards each show one representative image', len(category_cards) == 20 and all(
    card.count('class="cat-image category-image"') == 1
    and card.count('<img ') == 1
    for card in category_cards
))
popular_position = r.text.find('<h2>Popular picks</h2>')
featured_position = r.text.find('<h2 id="featured-products-heading">Featured Products</h2>')
deals_position = r.text.find('<h2>Best deals</h2>')
deals_section = re.search(r'<section>\s*<div class="section-head"><h2>Best deals</h2>.*?</section>', r.text, re.S)
featured_section_open = r.text.rfind('<section class="featured-products-section"', 0, featured_position)
next_section_open = r.text.find('<section', deals_section.end()) if deals_section else -1
ok('featured products section is directly below best deals', (
    featured_position > deals_position >= 0
    and deals_section is not None
    and featured_section_open == next_section_open
))
featured_section = re.search(r'<section class="featured-products-section".*?</section>', r.text, re.S)
featured_cards = re.findall(r'<article class="card product featured-product-card".*?</article>', featured_section.group(0), re.S) if featured_section else []
featured_db = sqlite3.connect(TEST_DB)
popular_ids = [row[0] for row in featured_db.execute(
    'SELECT id FROM products WHERE is_active = 1 AND is_featured = 1 ORDER BY id LIMIT 8'
)]
featured_rows = featured_db.execute(
    'SELECT p.id, p.name, p.slug, p.price, p.old_price, p.stock, c.name FROM products p JOIN categories c ON c.id = p.category_id '
    'WHERE p.is_active = 1 AND p.is_featured = 1 '
    + ('AND p.id NOT IN (' + ','.join('?' for _ in popular_ids) + ') ' if popular_ids else '')
    + 'ORDER BY p.id DESC LIMIT 8',
    popular_ids,
).fetchall()
featured_db.close()
ok('featured products use database-featured cards with product, cart, and wishlist actions', bool(featured_section) and (
    all(
        'class="badge featured-label">Featured</span>' in card
        and 'class="product-category"' in card
        and 'class="product-image' in card
        and 'View Product</a>' in card
        and 'Add to Cart</button>' in card
        and ('class="featured-wishlist"' in card)
        and '/assets/images/product-image-unavailable.svg' not in re.search(r'<img class="product-image[^"]*" src="([^"]+)"', card).group(1)
        and ('action" value="add"' in card or 'Out of stock' in card)
        for card in featured_cards
    ) if featured_cards else 'Browse all products' in featured_section.group(0)
))
ok('featured product names, categories, prices, and count match database', (
    len(featured_cards) == len(featured_rows)
    and all(
        name in card
        and escape(category) in card
        and ('UGX ' + format(price, ',') in card)
        and f'product.php?slug={slug}' in card
        and ('class="badge sale"' in card) == (old_price is not None and old_price > price)
        and ('Out of stock' in card if stock < 1 else 'In stock' in card or f'Only {stock} left in stock' in card)
        for card, (_, name, slug, price, old_price, stock, category) in zip(featured_cards, featured_rows)
    )
))
featured_product_links = [
    re.search(r'href="([^"]*product\.php\?slug=[^"]+)"', card).group(1)
    for card in featured_cards
]
ok('featured product detail links open the matching active products', len(featured_product_links) == len(featured_rows) and all(
    requests.get(urljoin(B, href)).status_code == 200 and '<h1>' in requests.get(urljoin(B, href)).text
    for href in featured_product_links
))
featured_images = re.findall(r'<img class="product-image[^"]*" src="([^"]+)"', featured_section.group(0), re.S) if featured_section else []
ok('featured product photographs load from local project image assets', len(featured_images) == len(featured_rows) and all(
    '/assets/products/' in image and requests.get(urljoin(B, image)).status_code == 200
    for image in featured_images
))
featured_add_form = re.search(r'<form method="post" action="[^"]*cart\.php">.*?name="id" value="(\d+)".*?</form>', featured_section.group(0), re.S) if featured_section else None
if featured_add_form:
    featured_form = re.search(r'<form method="post" action="([^"]*cart\.php)">.*?</form>', featured_section.group(0), re.S)
    featured_csrf = re.search(r'name="csrf" value="([^"]+)"', featured_form.group(0), re.S) if featured_form else None
    r = store.post(urljoin(B, featured_form.group(1)), data={
        'csrf': featured_csrf.group(1) if featured_csrf else '',
        'action': 'add',
        'id': featured_add_form.group(1),
    })
    ok('featured product add-to-cart form uses the existing cart route', 'Added to cart' in r.text or 'Cart' in r.text)
    wishlist_add_response = store.get(B + 'wishlist.php?action=add&id=1', allow_redirects=False)
    ok('wishlist add redirects before rendering page output', wishlist_add_response.status_code == 302 and 'Warning: Cannot modify header information' not in wishlist_add_response.text)
    wishlist_page = store.get(B + 'wishlist.php')
    ok('wishlist add redirect displays the saved product', 'Electric Kettle 1.7L' in wishlist_page.text)
    wishlist_remove_response = store.get(B + 'wishlist.php?action=remove&id=1', allow_redirects=False)
    ok('wishlist remove redirects before rendering page output', wishlist_remove_response.status_code == 302 and 'Warning: Cannot modify header information' not in wishlist_remove_response.text)
    category_page = store.get(B + 'categories.php')
category_page_cards = re.findall(r'<a class="cat"[^>]*>.*?</a>', category_page.text, re.S)
ok('all categories page uses one representative image per category', len(category_page_cards) == 20 and all(
    card.count('class="cat-image category-image"') == 1
    and card.count('<img ') == 1
    for card in category_page_cards
))

# Customer registration and remembered-login restoration
customer = requests.Session()
r = customer.get(B + 'register.php'); token = csrf(r.text)
customer_data = {
    'csrf': token, 'first_name': 'Test', 'last_name': 'Customer',
    'username': 'e2ecustomer', 'email': 'e2e@example.com', 'phone': '0772000001',
    'password': 'StrongPass123', 'confirm_password': 'StrongPass123',
    'terms': '1', 'privacy': '1', 'role': 'admin',
}
r = customer.post(B + 'register.php', data=customer_data)
ok('customer registration', 'My Account' in r.text and 'Test Customer' in r.text, r.text[:200])
role_db = sqlite3.connect(TEST_DB)
registered_role = role_db.execute("SELECT role FROM users WHERE email = 'e2e@example.com'").fetchone()
role_db.close()
ok('public registration ignores administrator role input', bool(registered_role) and registered_role[0] == 'customer')
r = customer.get(B + 'logout.php')
token = csrf(customer.get(B + 'login.php').text)
r = customer.post(B + 'login.php', data={
    'csrf': token, 'email': 'e2ecustomer', 'password': 'StrongPass123', 'remember': '1',
})
ok('customer uses shared login with username', 'My Account' in r.text)
remember_token = customer.cookies.get('he_remember')
ok('remembered login token issued', bool(remember_token) and 'My Account' in r.text)
restored = requests.Session()
restored.cookies.set('he_remember', remember_token)
r = restored.get(B + 'customer/dashboard.php')
ok('remembered login restored', 'Test Customer' in r.text)
customer.get(B + 'logout.php')
protected_customer_page = customer.get(B + 'customer/dashboard.php', allow_redirects=False)
ok('customer logout ends the authenticated session', protected_customer_page.status_code == 302)
token = csrf(customer.get(B + 'login.php').text)
r = customer.post(B + 'login.php', data={
    'csrf': token, 'email': 'e2e@example.com', 'password': 'StrongPass123',
})
ok('customer can sign in by email after logout', 'My Account' in r.text)
wishlist_db = sqlite3.connect(TEST_DB)
customer_id = wishlist_db.execute("SELECT id FROM users WHERE email = 'e2e@example.com'").fetchone()[0]
wishlist_db.execute('INSERT INTO wishlists (user_id, product_id) VALUES (?, ?)', [customer_id, 1])
wishlist_db.execute("UPDATE users SET status = 'suspended' WHERE id = ?", [customer_id])
wishlist_db.commit()
wishlist_db.close()
inactive_session = requests.Session()
token = csrf(inactive_session.get(B + 'login.php').text)
inactive_response = inactive_session.post(B + 'login.php', data={
    'csrf': token, 'email': 'e2e@example.com', 'password': 'StrongPass123',
})
ok('disabled customer account cannot sign in', 'currently disabled' in inactive_response.text)
status_db = sqlite3.connect(TEST_DB)
status_db.execute("UPDATE users SET status = 'active' WHERE id = ?", [customer_id])
status_db.commit()
status_db.close()
for reset_email, owner_column in [('admin@homeease.ug', 'admin_id'), ('e2e@example.com', 'user_id')]:
    recovery = requests.Session()
    token = csrf(recovery.get(B + 'forgot-password.php').text)
    reset_response = recovery.post(B + 'forgot-password.php', data={'csrf': token, 'email': reset_email})
    link_match = re.search(r'href="([^"]*reset-password\.php\?token=[^"]+)"', reset_response.text)
    reset_link = urljoin(B, unquote(link_match.group(1))) if link_match else ''
    raw_token = parse_qs(urlparse(reset_link).query).get('token', [''])[0]
    reset_db = sqlite3.connect(TEST_DB)
    reset_row = reset_db.execute(
        'SELECT user_id, admin_id, token FROM password_resets WHERE token = ?',
        [hashlib.sha256(raw_token.encode()).hexdigest()],
    ).fetchone() if raw_token else None
    reset_db.close()
    expected_owner = reset_row[0] if reset_row and owner_column == 'user_id' else (reset_row[1] if reset_row else None)
    r = recovery.get(reset_link) if reset_link else None
    reset_page_ok = bool(r) and 'Reset your password' in r.text and 'invalid or has expired' not in r.text
    ok('password reset issues a hashed single-use token for ' + owner_column, (
        reset_row is not None
        and reset_row[2] != raw_token
        and bool(expected_owner)
        and reset_page_ok
    ))
    if r:
        reset_csrf = csrf(r.text)
        invalid_reset = recovery.post(reset_link, data={
            'csrf': reset_csrf, 'password': 'short', 'confirm_password': 'short',
        })
        ok('password reset validates new password for ' + owner_column, 'at least 8 characters' in invalid_reset.text)
r = customer.get(B + 'customer/wishlist.php')
ok('wishlist renders product photo with valid src', 'class="product-image"' in r.text and 'assets/products/electric-kettle-1-7l.jpg' in r.text)
ok('customer dashboard recommendations render product photos', 'class="product-image"' in r.text and 'Recommended Products' in customer.get(B + 'customer/dashboard.php').text)

# Account-linked orders and customer requests
r = customer.get(B + 'products.php'); t = csrf(r.text)
r = customer.post(B + 'cart.php', data={'csrf': t, 'action': 'add', 'id': 20})
r = customer.get(B + 'checkout.php'); t = csrf(r.text)
r = customer.post(B + 'checkout.php', data={
    'csrf': t, 'name': 'Test Customer', 'email': 'e2e@example.com',
    'phone': '0772000001', 'zone': 'pickup', 'address': '',
    'method': 'cod', 'network': 'MTN',
})
linked_match = re.search(r'HE-\d{6}-[A-F0-9]{6}', r.text)
linked_no = linked_match.group(0) if linked_match else ''
ok('registered checkout creates account order', bool(linked_no) and 'Your order is in' in r.text)
ok('order confirmation includes product image', 'class="product-image order-item-image"' in r.text and '6-way-surge-protected-extension.webp' in r.text)
db = sqlite3.connect(TEST_DB)
linked_row = db.execute('SELECT id FROM orders WHERE order_no = ?', [linked_no]).fetchone()
db.close()
linked_id = linked_row[0] if linked_row else 0
r = customer.get(B + 'customer/orders.php')
ok('customer order list shows account-linked order', bool(linked_no) and linked_no in r.text)
ok('customer order history includes product thumbnail', 'class="product-image admin-product-image"' in r.text)
r = customer.get(B + 'customer/order.php?id=' + str(linked_id))
ok('customer order detail includes product image', 'class="product-image order-item-image"' in r.text and '6-way-surge-protected-extension.webp' in r.text)
r = customer.get(B + 'customer/returns.php'); t = csrf(r.text)
r = customer.post(B + 'customer/returns.php', data={
    'csrf': t, 'order_id': linked_id, 'reason': 'Test return request',
})
ok('customer can request return for own order', 'Return request submitted' in r.text)
r = customer.get(B + 'customer/support.php'); t = csrf(r.text)
r = customer.post(B + 'customer/support.php', data={
    'csrf': t, 'subject': 'Test support ticket',
    'message': 'Please help with this test order.', 'order_no': linked_no,
})
ok('customer can submit support ticket for own order', 'Support request submitted' in r.text)

s = requests.Session()
# add to cart (two products), update qty, coupon, zone
r = s.get(B + 'products.php'); t = csrf(r.text)
db = sqlite3.connect(TEST_DB)
seeded_product_count = db.execute('SELECT COUNT(*) FROM products WHERE is_active = 1').fetchone()[0]
db.close()
ok('all seeded products listed', f'{seeded_product_count} products found' in r.text)
ok('product catalogue uses shared image markup', 'class="product-image"' in r.text and 'alt="Electric Kettle 1.7L"' in r.text)
db = sqlite3.connect(TEST_DB)
slugs = [row[0] for row in db.execute('SELECT slug FROM products')]
db.close()
project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
base_path = urlparse(B).path.strip('/')
missing_images = []
fallback_images = []
for slug in slugs:
    page = s.get(B + 'product.php?slug=' + quote(slug))
    match = re.search(r'<img class="product-image[^"]*" src="([^"]+)"', page.text)
    if not match:
        missing_images.append(slug)
        continue
    image_path = unquote(urlparse(urljoin(B, match.group(1))).path).lstrip('/')
    if base_path and image_path.startswith(base_path + '/'):
        image_path = image_path[len(base_path) + 1:]
    if image_path.endswith('assets/images/product-image-unavailable.svg'):
        fallback_images.append(slug)
    elif not os.path.isfile(os.path.join(project_root, image_path.replace('/', os.sep))):
        missing_images.append(slug)
ok('every product resolves to an existing photo or fallback', not missing_images, ', '.join(missing_images))
ok('all products have a matching photo without using the fallback', not fallback_images, ', '.join(fallback_images))
food_processor = s.get(B + 'product.php?slug=food-processor-2l')
ok('food processor uses its matching locally stored photo', 'assets/products/food-processor-2l.jpg' in food_processor.text and 'alt="Food Processor 2L"' in food_processor.text)
clothes_dryer = s.get(B + 'product.php?slug=clothes-dryer-7kg')
ok('clothes dryer uses its matching locally stored photo', 'assets/products/clothes-dryer-7kg.jpg' in clothes_dryer.text and 'alt="Clothes Dryer 7kg"' in clothes_dryer.text)
air_fryer = s.get(B + 'product.php?slug=air-fryer-4l')
ok('generic air fryer uses its correctly matched distinct photo', 'assets/products/air-fryer-4l-white.webp' in air_fryer.text)
nutrichef = s.get(B + 'product.php?slug=nutrichef-non-stick-cookware-set')
ok('Nutrichef cookware uses its brand-matched photo', 'assets/products/nutrichef-blue-cookware-set.avif' in nutrichef.text)
db = sqlite3.connect(TEST_DB)
db.execute(
    "INSERT INTO products (category_id,name,slug,brand,description,specs,price,stock,image) "
    "VALUES (1,'Unmapped Product','image-fallback-probe','Test','Fallback test item','',1000,1,'')"
)
db.commit()
db.close()
r = s.get(B + 'product.php?slug=image-fallback-probe')
ok('missing product photo uses local fallback image', 'assets/images/product-image-unavailable.svg' in r.text and 'alt="Unmapped Product"' in r.text)
db = sqlite3.connect(TEST_DB)
db.execute("UPDATE products SET image = ? WHERE slug = ?", ['rechargeable-solar-fan.jpg', 'rechargeable-fan-light'])
db.commit()
db.close()
r = s.get(B + 'product.php?slug=rechargeable-fan-light')
ok('assigned public image filename is honored', 'assets/products/rechargeable-solar-fan.jpg' in r.text)
r = s.get(B + 'product.php?slug=2-plate-electric-hotplate')
ok('hotplate uses matching real product photo', '2-plate-electric-hotplate.jpg' in r.text and 'alt="2-Plate Electric Hotplate"' in r.text)
r = s.post(B + 'cart.php', data={'csrf': t, 'action': 'add', 'id': 1}); ok('add kettle', 'Added to your cart' in r.text)
r = s.get(B + 'cart.php')
ok('cart product thumbnail uses shared image helper', 'class="product-image"' in r.text and 'assets/products/electric-kettle-1-7l.jpg' in r.text)
r = s.post(B + 'cart.php', data={'csrf': t, 'action': 'add', 'id': 10, 'qty': 1}); ok('add fridge', 'Mini Fridge' in r.text)
r = s.post(B + 'cart.php', data={'csrf': t, 'action': 'update', 'qty[1]': 3}); ok('update qty', 'UGX 165,000' in r.text, 'line total')
r = s.post(B + 'cart.php', data={'csrf': t, 'action': 'coupon', 'coupon': 'student10'}); ok('coupon', 'STUDENT10 applied' in r.text)
r = s.post(B + 'cart.php', data={'csrf': t, 'action': 'coupon', 'coupon': 'BOGUS'}); ok('bad coupon rejected', 'not valid' in r.text)
r = s.post(B + 'cart.php', data={'csrf': t, 'action': 'update', 'qty[1]': 3}); 
# subtotal 165000+650000=815000; 10% => 81500; total free delivery kampala => 733500
ok('totals w/ coupon + free delivery', 'UGX 733,500' in r.text, re.findall(r'UGX [\d,]+', r.text)[-6:].__str__())
# CSRF
r = requests.post(B + 'cart.php', data={'action': 'add', 'id': 1}); ok('csrf blocks', r.status_code == 400)
# checkout validation
r = s.get(B + 'checkout.php'); t = csrf(r.text); ok('checkout page', 'Payment simulation' in r.text)
ok('checkout summary includes product image', 'class="product-image order-item-image"' in r.text)
base = {'csrf': t, 'name': 'Jane Doe', 'email': 'jane@example.com', 'phone': '0772123456', 'zone': 'kampala', 'address': 'Ntinda, near the market', 'method': 'card', 'network': 'MTN'}
r = s.post(B + 'checkout.php', data={**base, 'card_number': '4242 4242 4242 4243', 'card_exp': '12/29', 'card_cvc': '123'}); ok('luhn fail', 'not valid' in r.text)
r = s.post(B + 'checkout.php', data={**base, 'card_number': '4000 0000 0000 0002', 'card_exp': '12/29', 'card_cvc': '123'}); ok('declined card', 'declined' in r.text)
r = s.post(B + 'checkout.php', data={**base, 'card_number': '4242 4242 4242 4242', 'card_exp': '01/20', 'card_cvc': '123'}); ok('expired card', 'future expiry' in r.text)
r = s.post(B + 'checkout.php', data={**base, 'phone': '123'}); ok('bad phone', 'valid Ugandan phone' in r.text)
r = s.post(B + 'checkout.php', data={**base, 'method': 'momo', 'momo_phone': '0772000000'}); ok('momo decline', 'declined' in r.text)
r = s.post(B + 'checkout.php', data={**base, 'card_number': '4242 4242 4242 4242', 'card_exp': '12/29', 'card_cvc': '123'})
ok('card order placed', 'Your order is in' in r.text, r.text[:300])
m = re.search(r'HE-\d{6}-[A-F0-9]{6}', r.text); no = m.group(0) if m else ''
ok('order number shown', bool(no), no)
guest_db = sqlite3.connect(TEST_DB)
guest_row = guest_db.execute('SELECT id FROM orders WHERE order_no = ?', [no]).fetchone()
guest_db.close()
ok('total saved', 'UGX 733,500' in r.text)
ok('card last4 only', 'card ending 4242' in r.text and '4242 4242 4242 4242' not in r.text)
if guest_row:
    r = customer.get(B + 'customer/order.php?id=' + str(guest_row[0]))
    ok('account cannot open unlinked guest order by ID', 'Order not found' in r.text)
r = s.get(B + 'cart.php'); ok('cart cleared', 'cart is empty' in r.text)
# stock decremented
r = requests.get(B + 'products.php?q=Mini+Fridge'); ok('stock lowered (fridge 8->7)', 'In stock' in r.text or 'Add to cart' in r.text)
# order-success blocked for other sessions
r = requests.get(B + 'order-success.php?no=' + no, allow_redirects=False); ok('success page session-bound', r.status_code == 302)
# tracking
t2 = requests.Session(); tk = csrf(t2.get(B + 'track.php').text)
r = t2.post(B + 'track.php', data={'csrf': tk, 'order_no': no, 'email': 'wrong@example.com'}); ok('track wrong email', 'could not find' in r.text)
r = t2.post(B + 'track.php', data={'csrf': tk, 'order_no': no, 'email': 'jane@example.com'}); ok('track ok', 'Order received' in r.text or 'Confirmed' in r.text)
ok('order tracking includes product image', 'class="product-image order-item-image"' in r.text and 'assets/products/electric-kettle-1-7l.jpg' in r.text)
r = t2.post(B + 'track.php', data={'csrf': tk, 'order_no': '  ' + no.lower() + '  ', 'email': '  JANE@EXAMPLE.COM  '})
ok('track accepts copied order number and email casing', 'Order ' + no in r.text and 'could not find' not in r.text)
# COD + momo + pickup order
tk = csrf(s.get(B + 'products.php').text)
s.post(B + 'cart.php', data={'csrf': tk, 'action': 'add', 'id': 19})
r = s.get(B + 'checkout.php'); t = csrf(r.text)
r = s.post(B + 'checkout.php', data={'csrf': t, 'name': 'Sam', 'email': 'sam@example.com', 'phone': '+256701234567', 'zone': 'pickup', 'address': '', 'method': 'momo', 'network': 'Airtel', 'momo_phone': '0701234567'})
ok('momo pickup order', 'Your order is in' in r.text and 'paid (simulated)' in r.text.lower(), r.text[:200])
s.post(B + 'cart.php', data={'csrf': t, 'action': 'add', 'id': 1})
r = s.get(B + 'checkout.php'); t = csrf(r.text)
r = s.post(B + 'checkout.php', data={'csrf': t, 'name': 'Cod Buyer', 'email': 'cod@example.com', 'phone': '0752000111', 'zone': 'greater', 'address': 'Mukono town, Main St', 'method': 'cod', 'network': 'MTN'})
ok('cod order', 'Your order is in' in r.text and 'Pay on delivery' in r.text, r.text[:200])
# contact form
c = requests.Session(); t = csrf(c.get(B + 'contact.php').text)
r = c.post(B + 'contact.php', data={'csrf': t, 'name': 'Ann', 'email': 'ann@example.com', 'subject': 'Warranty', 'message': 'Does the kettle have a warranty?'}); ok('contact saved', 'message has been received' in r.text)
r = c.post(B + 'contact.php', data={'csrf': t, 'name': 'Bot', 'email': 'b@example.com', 'subject': 'x', 'message': 'spam spam spam spam', 'website': 'http://spam'}); 
r = c.post(B + 'contact.php', data={'csrf': t, 'name': 'A', 'email': 'bad', 'subject': '', 'message': 'hi'}); ok('contact validation', 'valid email' in r.text)
# SQL injection / XSS probes
r = requests.get(B + "products.php?q=' OR 1=1 --"); ok('sqli search safe', r.status_code == 200 and 'Fatal' not in r.text)
r = requests.get(B + 'products.php?q=<script>alert(1)</script>'); ok('xss escaped', '<script>alert(1)</script>' not in r.text)
r = requests.get(B + 'products.php?cat[]=x'); ok('array param safe', r.status_code == 200)

# ---- Admin ----
a = requests.Session()
r = a.get(B + 'admin/products.php', allow_redirects=False); ok('admin guarded by shared login', r.status_code == 302 and r.headers.get('Location', '').endswith('/login.php'))
t = csrf(a.get(B + 'admin/login.php').text)
ok('legacy admin login URL redirects to shared login', a.get(B + 'admin/login.php', allow_redirects=False).status_code == 302)
login_page = a.get(B + 'login.php')
ok('shared login is branded for both account roles', 'Welcome Back to HomeEase' in login_page.text and 'Email address or username' in login_page.text)
ok('login page has no background image and retains its requested subtitle', (
    'class="login-shell"' in login_page.text
    and 'assets/images/homeease-login-background.jpg' not in login_page.text
    and 'login_background_image' not in login_page.text
    and 'Your home, your comfort, our priority.' in login_page.text
))
login_styles = requests.get(B + 'assets/css/style.css')
ok('login page uses a solid centered background', (
    login_styles.status_code == 200
    and 'background: #f5f5f5;' in login_styles.text
    and 'background-size: cover' not in login_styles.text
    and 'body.login-shell .auth-page' in login_styles.text
    and '@media (max-width: 640px)' in login_styles.text
))
t = csrf(login_page.text)
r = a.post(B + 'login.php', data={'csrf': t, 'email': 'admin@homeease.ug', 'password': 'wrong'}); ok('shared login rejects incorrect administrator password', 'incorrect' in r.text.lower())
t = csrf(a.get(B + 'login.php').text)
r = a.post(B + 'login.php', data={'csrf': t, 'email': 'unknown@example.com', 'password': 'wrong'}); ok('unknown login gets generic error', 'Email/username or password is incorrect.' in r.text)
t = csrf(a.get(B + 'login.php').text)
r = a.post(B + 'login.php', data={'csrf': t, 'email': 'admin@homeease.ug', 'password': 'Admin@12345'}); ok('administrator uses shared login and reaches dashboard', 'Dashboard' in r.text, r.text[:200])
r = customer.get(B + 'admin/products.php', allow_redirects=False); ok('customer is denied direct administrator access', r.status_code == 403)
r = a.get(B + 'customer/dashboard.php', allow_redirects=False); ok('administrator is not treated as a customer', r.status_code == 302 and r.headers.get('Location', '').endswith('/admin/index.php'))
r = a.get(B + 'admin/email-inbox.php')
ok('website enquiries have a direct reply action in inbox', 'reply_source=website&amp;reply_id=' in r.text and '>Reply</a>' in r.text)
r = a.get(B + 'admin/products.php'); ok('admin products', 'Add product' in r.text); t = csrf(r.text)
ok('administrator product table includes image thumbnails', 'class="product-image admin-product-image"' in r.text)
r = a.get(B + 'admin/product_form.php?id=1')
ok('administrator product form previews image', 'class="product-image"' in r.text and 'electric-kettle-1-7l.jpg' in r.text)
r = a.get(B + 'admin/products.php?q=Electric+Kettle')
ok('admin product search', 'Electric Kettle 1.7L' in r.text and 'Mini Fridge 90L' not in r.text)
r = a.get(B + 'admin/support.php'); t = csrf(r.text)
ok('admin support queue shows customer ticket', 'Test support ticket' in r.text and linked_no in r.text)
ticket_db = sqlite3.connect(TEST_DB)
ticket_row = ticket_db.execute("SELECT id FROM support_tickets WHERE subject = 'Test support ticket'").fetchone()
return_row = ticket_db.execute('SELECT id FROM return_requests WHERE order_id = ?', [linked_id]).fetchone()
ticket_db.close()
if ticket_row:
    r = a.post(B + 'admin/support.php', data={
        'csrf': t, 'id': ticket_row[0], 'status': 'answered',
        'admin_reply': 'We received your request.',
    })
    ok('admin can respond to support ticket', 'Support ticket updated' in r.text)
    r = customer.get(B + 'customer/support.php')
    ok('customer sees administrator response', 'We received your request.' in r.text)
r = a.get(B + 'admin/returns.php'); t = csrf(r.text)
legacy_db = sqlite3.connect(TEST_DB)
legacy_db.execute('ALTER TABLE return_requests DROP COLUMN admin_reply')
legacy_db.commit()
legacy_db.close()
r = a.get(B + 'admin/returns.php'); t = csrf(r.text)
upgrade_db = sqlite3.connect(TEST_DB)
upgrade_row = upgrade_db.execute('SELECT refund_status, admin_reply FROM return_requests WHERE id = ?', [return_row[0]]).fetchone() if return_row else None
upgrade_db.close()
ok('legacy return requests gain reply field when refund status already exists', bool(upgrade_row) and upgrade_row == ('not_applicable', None) and 'Reply to customer' in r.text)
legacy_db = sqlite3.connect(TEST_DB)
legacy_db.execute('ALTER TABLE return_requests DROP COLUMN refund_status')
legacy_db.commit()
legacy_db.close()
r = a.get(B + 'admin/returns.php'); t = csrf(r.text)
upgrade_db = sqlite3.connect(TEST_DB)
upgrade_row = upgrade_db.execute('SELECT refund_status, admin_reply FROM return_requests WHERE id = ?', [return_row[0]]).fetchone() if return_row else None
upgrade_db.close()
ok('legacy return requests gain missing refund status without losing replies', bool(upgrade_row) and upgrade_row == ('not_applicable', None) and 'Install the return-refund status migration' not in r.text)
ok('admin return queue shows request and customer', linked_no in r.text and 'Test Customer' in r.text)
if return_row:
    r = a.post(B + 'admin/returns.php', data={
        'csrf': t, 'id': return_row[0], 'status': 'approved',
        'refund_status': 'awaiting_verification',
        'admin_note': 'Verify transaction separately.',
        'admin_reply': 'We are checking your delivery and will update you shortly.',
    })
    ok('admin can approve return without claiming refund paid and reply', 'Return request updated' in r.text)
    r = customer.get(B + 'customer/returns.php')
    ok('customer sees return status, refund follow-up, and admin reply', 'approved' in r.text and 'awaiting verification' in r.text and 'We are checking your delivery and will update you shortly.' in r.text)
    notification_db = sqlite3.connect(TEST_DB)
    notification = notification_db.execute(
        'SELECT title, message, link, is_read FROM notifications WHERE user_id = ? ORDER BY id DESC LIMIT 1',
        [customer_id],
    ).fetchone()
    notification_db.close()
    ok('customer receives a notification when the admin replies', bool(notification) and notification[0] == 'Return request reply' and linked_no in notification[1] and notification[2] == 'customer/returns.php' and notification[3] == 0)
r = a.get(B + 'admin/customers.php')
ok('admin customer management page', r.status_code == 200 and 'Manage Customers' in r.text)
ok('admin customer page exposes add and edit actions', 'Add customer' in r.text and 'Edit</a>' in r.text)
new_user_page = a.get(B + 'admin/customer-form.php')
new_user_token = csrf(new_user_page.text)
new_user_response = a.post(B + 'admin/customer-form.php', data={
    'csrf': new_user_token, 'first_name': 'Admin', 'last_name': 'Created',
    'username': 'admincreated', 'email': 'admincreated@example.com',
    'phone': '0772000002', 'country': 'Uganda', 'status': 'active',
    'password': 'StrongPass456', 'role': 'admin',
})
new_user_db = sqlite3.connect(TEST_DB)
admin_created_user = new_user_db.execute(
    "SELECT id, role, password_hash FROM users WHERE email = 'admincreated@example.com'"
).fetchone()
new_user_db.close()
ok('admin can add customer without granting admin role', (
    'Customer account created.' in new_user_response.text
    and admin_created_user is not None
    and admin_created_user[1] == 'customer'
    and admin_created_user[2] != 'StrongPass456'
))
edit_user_page = a.get(B + 'admin/customer-form.php?id=' + str(admin_created_user[0]))
edit_user_response = a.post(B + 'admin/customer-form.php?id=' + str(admin_created_user[0]), data={
    'csrf': csrf(edit_user_page.text), 'id': admin_created_user[0],
    'first_name': 'Admin Updated', 'last_name': 'Customer',
    'username': 'admincreated', 'email': 'admincreated@example.com',
    'phone': '0772000003', 'country': 'Uganda', 'status': 'suspended',
    'role': 'admin',
})
edit_user_db = sqlite3.connect(TEST_DB)
edited_user = edit_user_db.execute(
    'SELECT first_name, phone, status, role, password_hash FROM users WHERE id = ?',
    [admin_created_user[0]],
).fetchone()
edit_user_db.close()
ok('admin can edit customer without changing its role or password', (
    'Customer account updated.' in edit_user_response.text
    and edited_user is not None
    and edited_user[0] == 'Admin Updated'
    and edited_user[1] == '0772000003'
    and edited_user[2] == 'suspended'
    and edited_user[3] == 'customer'
    and edited_user[4] == admin_created_user[2]
))
ok('admin dashboard links to customer add and management', (
    'Manage users' in a.get(B + 'admin/index.php').text
    and 'Add user' in a.get(B + 'admin/index.php').text
))
toggle_id = re.search(r'action="[^"]*admin/toggle-customer\.php"[^>]*>.*?name="id" value="(\d+)"', r.text, re.S)
toggle_token = csrf(r.text)
if toggle_id:
    r = a.post(B + 'admin/toggle-customer.php', data={
        'csrf': toggle_token, 'id': toggle_id.group(1), 'status': 'suspended',
    })
ok('customer status change is CSRF-protected POST', bool(toggle_id) and 'suspended' in r.text.lower())
if toggle_id:
    r = a.get(B + 'admin/toggle-customer.php?id=' + toggle_id.group(1) + '&action=activate')
    ok('customer status cannot be changed through GET', 'Activate' in r.text)
    r = a.get(B + 'admin/customer-details.php?id=' + toggle_id.group(1))
    ok('customer details uses protected status form', 'method="post"' in r.text and 'admin/toggle-customer.php' in r.text)
r = a.get(B + 'admin/product_form.php'); t = csrf(r.text)
# png upload
import struct, zlib
def png():
    raw = b'\x00\xff\x00\x00' * 4 * 1
    def ch(k, d): return struct.pack('>I', len(d)) + k + d + struct.pack('>I', zlib.crc32(k + d) & 0xffffffff)
    return b'\x89PNG\r\n\x1a\n' + ch(b'IHDR', struct.pack('>IIBBBBB', 1, 1, 8, 6, 0, 0, 0)) + ch(b'IDAT', zlib.compress(b'\x00\xff\x00\x00\xff')) + ch(b'IEND', b'')
dashboard_page = a.get(B + 'admin/index.php').text
login_page = requests.get(B + 'login.php').text
ok('login page displays without a background image', (
    'class="auth-page"' in login_page
    and 'login_background_image' not in login_page
    and 'homeease-login-background.jpg' not in login_page
    and 'assets/uploads/' not in login_page
    and 'Login page design' not in dashboard_page
))
form = {'csrf': t, 'id': 0, 'name': 'Test Toaster XL', 'brand': 'Acme', 'category_id': 1, 'price': 99000, 'old_price': 120000, 'stock': 5, 'description': 'desc', 'specs': 'Power: 900 W', 'warranty_months': 12, 'is_active': 'on'}
r = a.post(B + 'admin/product_form.php', data=form, files={'image': ('x.png', png(), 'image/png')}); ok('add product w/ image', 'Product added' in r.text, r.text[:300])
r = a.post(B + 'admin/product_form.php', data={**form, 'name': 'Evil'}, files={'image': ('x.php', b'<?php echo 1;', 'image/png')}); ok('php upload rejected', 'Only JPG' in r.text)
r = requests.get(B + 'product.php?slug=test-toaster-xl'); ok('new product visible', 'Test Toaster XL' in r.text and '/assets/uploads/' in r.text)
pid = re.search(r'name="id" value="(\d+)"', requests.get(B + 'products.php?q=Test+Toaster').text)
r = a.get(B + 'admin/orders.php'); ok('admin orders', 'HE-' in r.text)
oid = re.search(r'order\.php\?id=(\d+)', r.text).group(1)
r = a.get(B + 'admin/order.php?id=' + oid); t = csrf(r.text)
r = a.post(B + 'admin/order.php', data={'csrf': t, 'id': oid, 'status': 'dispatched'}); ok('status update', 'Order status updated' in r.text)
r = a.post(B + 'admin/order.php', data={'csrf': t, 'id': oid, 'status': 'cancelled'}); ok('cancel restores stock', 'updated' in r.text)
r = a.get(B + 'admin/messages.php'); ok('admin messages', 'Warranty' in r.text)
ok('website enquiries have a reply action on customer messages page', 'reply_source=website&amp;reply_id=' in r.text and '>Reply to customer</a>' in r.text)
r = a.get(B + 'admin/account.php'); t = csrf(r.text)
r = a.post(B + 'admin/account.php', data={'csrf': t, 'current': 'Admin@12345', 'new': 'short', 'confirm': 'short'}); ok('weak pw rejected', 'at least 10' in r.text)
r = a.get(B + 'admin/index.php')
ok('admin dashboard loads with customer metric', r.status_code == 200 and 'Total Customers' in r.text)
t = csrf(r.text)
r = a.post(B + 'admin/logout.php', data={'csrf': t}, allow_redirects=False)
r = a.get(B + 'admin/index.php', allow_redirects=False); ok('administrator logout ends authenticated session', r.status_code == 302 and r.headers.get('Location', '').endswith('/login.php'))

# Older store databases may not yet have the customer-account migration.
db = sqlite3.connect(TEST_DB)
db.executescript('DROP TABLE password_resets; DROP TABLE users; DROP TABLE login_attempts;')
db.commit()
db.close()
legacy_admin = requests.Session()
t = csrf(legacy_admin.get(B + 'login.php').text)
legacy_admin.post(B + 'login.php', data={
    'csrf': t, 'email': 'admin@homeease.ug', 'password': 'Admin@12345',
})
r = legacy_admin.get(B + 'admin/index.php')
ok('legacy database dashboard shows upgrade notice', r.status_code == 200 and 'database.sql' in r.text and 'Total Customers' in r.text)
r = legacy_admin.get(B + 'admin/customers.php')
ok('legacy database customer admin explains migration', r.status_code == 200 and 'import' in r.text.lower() and 'database.sql' in r.text)
r = requests.get(B + 'register.php')
ok('legacy database registration explains migration', r.status_code == 200 and 'database.sql' in r.text)
r = requests.get(B + 'login.php')
ok('legacy database login explains migration', r.status_code == 200 and 'database.sql' in r.text)
print('FAILS:', ok.fails)

import argparse
import os
import re
import sqlite3
import tempfile
from pathlib import Path


ROOT = Path(__file__).resolve().parent
DEFAULT_DB = Path(os.environ.get("HOMEEASE_TEST_DB_PATH", ROOT / "test.sqlite"))


def sqlite_schema(mysql_sql: str) -> str:
    sqlite_indexes = []

    sql = re.sub(
        r"\)\s*ENGINE\s*=\s*InnoDB\b[^;]*;",
        ");",
        mysql_sql,
        flags=re.IGNORECASE,
    )
    sql = re.sub(
        r"^\s*SET NAMES\s+\w+\s*;\s*",
        "",
        sql,
        flags=re.MULTILINE | re.IGNORECASE,
    )
    sql = re.sub(
        r"\bUNIQUE\s+KEY\s+([A-Za-z_][A-Za-z0-9_]*)\s*\(([^)]+)\)",
        r"CONSTRAINT \1 UNIQUE (\2)",
        sql,
        flags=re.IGNORECASE,
    )
    sql = re.sub(
        r"\bINT\s+AUTO_INCREMENT\s+PRIMARY\s+KEY\b",
        "INTEGER PRIMARY KEY AUTOINCREMENT",
        sql,
        flags=re.IGNORECASE,
    )

    def move_inline_indexes(match: re.Match[str]) -> str:
        table_name = match.group(1)
        body = match.group(2)
        for index_name, columns in re.findall(
            r",?\s*INDEX\s+([A-Za-z_][A-Za-z0-9_]*)\s*\(([^)]+)\)",
            body,
            flags=re.IGNORECASE,
        ):
            sqlite_indexes.append(
                f"CREATE INDEX IF NOT EXISTS {index_name} ON {table_name} ({columns});"
            )
        body = re.sub(
            r",?\s*INDEX\s+[A-Za-z_][A-Za-z0-9_]*\s*\([^)]+\)",
            "",
            body,
            flags=re.IGNORECASE,
        )
        return f"CREATE TABLE IF NOT EXISTS {table_name} ({body});"

    sql = re.sub(
        r"CREATE TABLE IF NOT EXISTS\s+([A-Za-z_][A-Za-z0-9_]*)\s*\((.*?)\)\s*;",
        move_inline_indexes,
        sql,
        flags=re.IGNORECASE | re.DOTALL,
    )
    sql += "\n" + "\n".join(sqlite_indexes)
    return sql


def build_database(destination: Path, force: bool) -> None:
    if destination.exists() and destination.stat().st_size and not force:
        raise FileExistsError(
            f"{destination} already contains data; choose another --output or pass --force "
            "only if it is a disposable test database."
        )

    destination.parent.mkdir(parents=True, exist_ok=True)
    fd, temp_name = tempfile.mkstemp(
        prefix=f".{destination.name}.", suffix=".tmp", dir=destination.parent
    )
    os.close(fd)
    temp_path = Path(temp_name)

    try:
        connection = sqlite3.connect(temp_path)
        try:
            connection.execute("PRAGMA foreign_keys = ON")
            schema = (ROOT.parent / "sql" / "schema.sql").read_text(encoding="utf8")
            connection.executescript(sqlite_schema(schema))
            seed = (ROOT.parent / "sql" / "seed.sql").read_text(encoding="utf8")
            connection.executescript(sqlite_schema(seed))
            # Disposable e2e-only administrator; production seed data creates no admin.
            connection.execute(
                "INSERT INTO admins (name, email, password_hash) VALUES (?, ?, ?)",
                [
                    "Test Store Admin",
                    "admin@homeease.ug",
                    "$2y$10$lt1R/eykB98UsFVpjOSgzOa.cFY99nEp4i/vH96PKfoGH85QqRbHu",
                ],
            )
            connection.commit()
        finally:
            connection.close()

        os.replace(temp_path, destination)
    except Exception:
        temp_path.unlink(missing_ok=True)
        raise


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Build a disposable SQLite database from the MySQL schema and seed."
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=DEFAULT_DB,
        help=f"output database path (default: {DEFAULT_DB})",
    )
    parser.add_argument(
        "--force",
        action="store_true",
        help="replace a non-empty output file; use only for a disposable test database",
    )
    args = parser.parse_args()

    build_database(args.output.resolve(), args.force)
    print(f"SQLite test database built: {args.output.resolve()}")


if __name__ == "__main__":
    main()

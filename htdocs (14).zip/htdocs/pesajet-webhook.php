<?php
// PesaJet webhook receiver. Set this URL in the PesaJet dashboard:
//   https://YOUR-DOMAIN/pesajet-webhook.php
require __DIR__ . '/includes/bootstrap.php';

header('Content-Type: application/json');

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    http_response_code(405);
    exit(json_encode(['error' => 'POST only']));
}
if (PESAJET_WEBHOOK_SECRET === '') {
    error_log('PesaJet webhook received but PESAJET_WEBHOOK_SECRET is not configured.');
    http_response_code(500);
    exit(json_encode(['error' => 'Webhook not configured']));
}

$raw = (string)file_get_contents('php://input');
$sig = (string)($_SERVER['HTTP_X_WEBHOOK_SIGNATURE'] ?? '');
if (!pesajet_verify_signature($raw, $sig)) {
    http_response_code(401);
    exit(json_encode(['error' => 'Invalid signature']));
}

$p = json_decode($raw, true);
if (!is_array($p)) {
    http_response_code(400);
    exit(json_encode(['error' => 'Invalid JSON']));
}

$event = (string)($p['event'] ?? '');
if ($event === 'webhook.test') {
    exit(json_encode(['received' => true]));
}

$orderNo = (string)($p['reference'] ?? ($p['metadata']['orderId'] ?? ''));
$result = 'ignored';
if ($orderNo !== '' && in_array($event, ['payment.completed', 'payment.failed', 'payment.expired'], true)) {
    try {
        $result = pesajet_apply_status(
            $orderNo,
            (string)($p['status'] ?? ''),
            (string)($p['transactionId'] ?? ''),
            isset($p['amount']) ? (int)$p['amount'] : null
        );
    } catch (Throwable $e) {
        error_log('PesaJet webhook error: ' . $e->getMessage());
        http_response_code(500); // PesaJet can retry
        exit(json_encode(['error' => 'Processing error']));
    }
}
echo json_encode(['received' => true, 'result' => $result]);

<?php
require __DIR__ . '/includes/bootstrap.php';
$title = 'Terms & conditions';
require __DIR__ . '/includes/header.php';
?>
<h1>Terms &amp; conditions</h1>
<p class="muted">Last updated <?= e(date('j F Y')) ?>. These terms form a contract between you and <?= e(SITE_NAME) ?> under Ugandan law, including the Electronic Transactions Act, 2011.</p>
<h2>1. About this site</h2>
<p><?= e(SITE_NAME) ?> is an online store for home appliances. <?= pesajet_enabled() ? 'Mobile-money payments are processed securely by PesaJet; we never see or store your PIN.' : '<strong>Card and mobile-money payments are simulated; no real money is transferred through this website.</strong>' ?> Cash-on-delivery orders are submitted for confirmation.</p>
<h2>2. Orders and prices</h2>
<ul>
  <li>Prices are in Uganda Shillings (UGX) and include applicable taxes unless stated.</li>
  <li>An order is accepted when we confirm it. We may cancel an order if an item is out of stock or a price was shown in error, and will refund any payment made.</li>
  <li>Coupon codes cannot be combined and have no cash value.</li>
</ul>
<h2>3. Payment</h2>
<p>You can pay by mobile money, card or cash on delivery. You confirm you are authorised to use the payment method you choose.</p>
<h2>4. Delivery</h2>
<p>Delivery times are estimates. Risk passes to you when the goods are delivered. See <a href="<?= e(url('delivery.php')) ?>">Delivery information</a>.</p>
<h2>5. Returns and warranty</h2>
<p>Governed by our <a href="<?= e(url('returns.php')) ?>">Returns &amp; warranty policy</a>. Nothing here limits your statutory rights, including that goods must match their description and be of satisfactory quality.</p>
<h2>6. Your account and conduct</h2>
<p>Provide accurate information. Do not misuse the site, attempt to disrupt it or access areas you are not permitted to use.</p>
<h2>7. Liability</h2>
<p>We are not liable for indirect loss, or for loss caused by events beyond our control, such as power outages or network failures. Our total liability for an order will not exceed the price paid for it, except where the law does not allow this limit.</p>
<h2>8. Privacy</h2>
<p>We handle your data as described in our <a href="<?= e(url('privacy.php')) ?>">privacy policy</a>.</p>
<h2>9. Disputes</h2>
<p>These terms are governed by the laws of Uganda. Please contact us first so we can try to resolve any complaint.</p>
<?php require __DIR__ . '/includes/footer.php'; ?>

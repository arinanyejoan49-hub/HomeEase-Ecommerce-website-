<?php
require __DIR__ . '/includes/bootstrap.php';

customer_logout();
$_SESSION = [];
if (ini_get('session.use_cookies')) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', [
        'expires' => time() - 42000,
        'path' => $params['path'],
        'domain' => $params['domain'] ?? '',
        'secure' => $params['secure'],
        'httponly' => $params['httponly'],
        'samesite' => 'Lax',
    ]);
}
session_destroy();
setcookie('he_remember', '', [
    'expires' => time() - 3600,
    'path' => '/',
    'secure' => request_is_https(),
    'httponly' => true,
    'samesite' => 'Lax',
]);

$title = 'Logged Out';
$desc = 'You have been signed out of your account.';
$here = 'logout.php';
require __DIR__ . '/includes/header.php';
?>
<h1>Logged Out</h1>
<p class="lead">You have been signed out successfully.</p>
<p><a class="btn" href="<?= e(url('index.php')) ?>">Return to Home</a></p>
<?php require __DIR__ . '/includes/footer.php'; ?>
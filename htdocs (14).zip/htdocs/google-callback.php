<?php
// Step 2: Google sends the visitor back here with a one-time code.
require __DIR__ . '/includes/bootstrap.php';
require __DIR__ . '/includes/google_auth.php';
header('Cache-Control: no-store');

function google_fail(string $message): void
{
    flash('error', $message);
    redirect('login.php');
}

if (is_admin() || is_customer()) {
    redirect(is_admin() ? 'admin/index.php' : 'customer/dashboard.php');
}
if (!google_login_enabled()) {
    google_fail('Google sign-in is not available right now. Please use your email and password.');
}

$saved = $_SESSION['google_oauth'] ?? null;
unset($_SESSION['google_oauth']); // one use only

if (isset($_GET['error'])) {
    google_fail('Google sign-in was cancelled.');
}
$state = $_GET['state'] ?? '';
$code = $_GET['code'] ?? '';
if (!is_array($saved) || !is_string($state) || !is_string($code) || $code === ''
    || !hash_equals((string)$saved['state'], $state) || (time() - (int)$saved['time']) > 600) {
    google_fail('Your Google sign-in expired. Please try again.');
}

$tokens = google_token_request([
    'code' => $code,
    'client_id' => GOOGLE_CLIENT_ID,
    'client_secret' => GOOGLE_CLIENT_SECRET,
    'redirect_uri' => google_redirect_uri(),
    'grant_type' => 'authorization_code',
    'code_verifier' => $saved['verifier'],
]);
$claims = is_array($tokens) && !empty($tokens['id_token']) ? google_claims((string)$tokens['id_token'], (string)$saved['nonce']) : null;
if (!$claims) {
    google_fail('We could not verify your Google account. Please try again or use your email and password.');
}

try {
    [$user, $error] = google_find_or_create_customer($claims);
} catch (Throwable $e) {
    error_log('Google sign-in failed: ' . $e->getMessage());
    google_fail('Google sign-in failed. Please try again.');
}
if (!$user) {
    google_fail($error ?? 'Google sign-in failed. Please try again.');
}

customer_login($user);
flash('success', 'Welcome, ' . $user['first_name'] . '!');
redirect('customer/dashboard.php');

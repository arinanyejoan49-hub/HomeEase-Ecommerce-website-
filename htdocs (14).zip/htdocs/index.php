<?php
require __DIR__ . '/includes/bootstrap.php';
require __DIR__ . '/includes/card.php';
require __DIR__ . '/includes/promotions.php';
$title = SITE_NAME;
$featured = q('SELECT p.*, c.icon FROM products p JOIN categories c ON c.id = p.category_id
               WHERE p.is_active = 1 AND p.is_featured = 1 ORDER BY p.id LIMIT 8')->fetchAll();
$popularIds = array_map('intval', array_column($featured, 'id'));
$featuredExclusion = $popularIds
    ? ' AND p.id NOT IN (' . implode(',', array_fill(0, count($popularIds), '?')) . ')'
    : '';
$featuredCandidates = q(
    'SELECT p.*, c.icon, c.name AS category_name
     FROM products p JOIN categories c ON c.id = p.category_id
     WHERE p.is_active = 1 AND p.is_featured = 1' . $featuredExclusion . '
     ORDER BY p.id DESC',
    $popularIds
)->fetchAll();
$featuredProducts = [];
$featuredImageUrls = [];
foreach ($featuredCandidates as $product) {
    $imageUrl = product_image_url($product);
    if (str_ends_with($imageUrl, '/assets/images/product-image-unavailable.svg')
        || isset($featuredImageUrls[$imageUrl])) {
        continue;
    }

    $featuredImageUrls[$imageUrl] = true;
    $featuredProducts[] = $product;
    if (count($featuredProducts) === 8) {
        break;
    }
}
$deals = q('SELECT p.*, c.icon FROM products p JOIN categories c ON c.id = p.category_id
            WHERE p.is_active = 1 AND p.old_price IS NOT NULL AND p.old_price > p.price ORDER BY (p.old_price - p.price) * 1.0 / p.old_price DESC LIMIT 4')->fetchAll();
$catCounts = q('SELECT c.*, (SELECT COUNT(*) FROM products p WHERE p.category_id = c.id AND p.is_active = 1) AS n FROM categories c ORDER BY sort_order')->fetchAll();
$mainSlugs = ['kitchen', 'cooking', 'cooling', 'laundry', 'student', 'power'];
$mainCats = [];
foreach ($catCounts as $c) { if (in_array($c['slug'], $mainSlugs, true)) { $mainCats[] = $c; } }
usort($mainCats, function ($a, $b) use ($mainSlugs) { return array_search($a['slug'], $mainSlugs, true) <=> array_search($b['slug'], $mainSlugs, true); });
// One real product photo per category (the newest active product that has a photo).
$catThumbs = [];
foreach (q('SELECT id, category_id, name, slug, image FROM products WHERE is_active = 1 ORDER BY id DESC')->fetchAll() as $tp) {
    $tcid = (int)$tp['category_id'];
    if (isset($catThumbs[$tcid])) { continue; }
    $tu = product_image_url($tp);
    if (!str_ends_with($tu, '/assets/images/product-image-unavailable.svg')) { $catThumbs[$tcid] = $tu; }
}
// These four tiles always show a photo that matches the category name.
$fixedCatPhotos = [
    'kitchen' => 'air-fryer-4l-philips.webp',
    'cooling' => 'double-door-fridge-200l.webp',
    'laundry' => 'fully-automatic-washing-machine-8kg.webp',
    'power'   => 'solar-led-lamp-panel-kit.webp',
];
foreach ($mainCats as $mc) {
    $file = $fixedCatPhotos[$mc['slug']] ?? '';
    if ($file !== '' && is_file(__DIR__ . '/assets/products/' . $file)) {
        $catThumbs[(int)$mc['id']] = url('assets/products/' . $file);
    }
}
// New arrivals: the newest active products that have a real photo (no duplicate photos).
$newArrivals = [];
$newArrivalImages = [];
foreach (q('SELECT p.*, c.name AS category_name FROM products p JOIN categories c ON c.id = p.category_id
            WHERE p.is_active = 1 ORDER BY p.created_at DESC, p.id DESC LIMIT 60')->fetchAll() as $np) {
    $nu = product_image_url($np);
    if (str_ends_with($nu, '/assets/images/product-image-unavailable.svg') || isset($newArrivalImages[$nu])) { continue; }
    $newArrivalImages[$nu] = true;
    $np['_img'] = $nu;
    $newArrivals[] = $np;
    if (count($newArrivals) === 8) { break; }
}
// Customer reviews for the home page (real reviews only; same visibility rule as the product pages).
$reviewStats = ['avg' => 0.0, 'n' => 0];
$homeReviews = [];
if (table_exists('reviews')) {
    $rs = q("SELECT AVG(rating) AS a, COUNT(*) AS n FROM reviews WHERE status <> 'rejected'")->fetch();
    $reviewStats = ['avg' => (float)($rs['a'] ?? 0), 'n' => (int)($rs['n'] ?? 0)];
    $homeReviews = q("SELECT r.rating, r.title, r.body, r.created_at, u.first_name, u.last_name, p.name AS product_name, p.slug
                      FROM reviews r JOIN users u ON u.id = r.user_id JOIN products p ON p.id = r.product_id
                      WHERE r.status <> 'rejected' ORDER BY r.created_at DESC, r.id DESC LIMIT 3")->fetchAll();
}
require __DIR__ . '/includes/header.php';
?>
<section class="home-hero" aria-label="HomeEase featured collections">
  <div class="hero-slides" id="home-hero-slides" aria-live="off">
    <article class="hero-slide is-active" role="group" aria-roledescription="slide" aria-label="1 of 4" aria-hidden="false">
      <div class="hero-copy">
        <p class="hero-kicker">Your home, made better</p>
        <h1>Everything Your Home Needs</h1>
        <p class="hero-description">Discover quality home appliances and everyday essentials designed to make life easier, more comfortable, and more convenient.</p>
        <div class="hero-actions">
          <a class="hero-button hero-button-primary" href="<?= e(url('products.php')) ?>">Shop Now</a>
          <a class="hero-button hero-button-secondary" href="<?= e(url('categories.php')) ?>">Explore Categories</a>
        </div>
      </div>
      <div class="hero-visual">
        <img src="<?= e(url('assets/images/hero/home-interior.jpg')) ?>" alt="Bright contemporary home interior with comfortable living and dining spaces" fetchpriority="high">
      </div>
    </article>
    <article class="hero-slide" role="group" aria-roledescription="slide" aria-label="2 of 4" aria-hidden="true" inert>
      <div class="hero-copy">
        <p class="hero-kicker">Kitchen essentials</p>
        <h2>Make Every Kitchen Moment Better</h2>
        <p class="hero-description">Explore modern kitchen appliances that combine convenience, performance, and style.</p>
        <div class="hero-actions">
          <a class="hero-button hero-button-primary" href="<?= e(url('products.php?cat=kitchen')) ?>">Shop Kitchen Appliances</a>
          <a class="hero-button hero-button-secondary" href="<?= e(url('products.php')) ?>">View Products</a>
        </div>
      </div>
      <div class="hero-visual">
        <img src="<?= e(url('assets/images/hero/modern-kitchen.jpg')) ?>" alt="Modern kitchen with bright counters and fitted appliances" loading="lazy">
      </div>
    </article>
    <article class="hero-slide" role="group" aria-roledescription="slide" aria-label="3 of 4" aria-hidden="true" inert>
      <div class="hero-copy">
        <p class="hero-kicker">More time for what matters</p>
        <h2>Less Work. More Living.</h2>
        <p class="hero-description">Discover practical laundry and cleaning appliances that help simplify your daily household tasks.</p>
        <div class="hero-actions">
          <a class="hero-button hero-button-primary" href="<?= e(url('products.php?cat=cleaning')) ?>">Explore Cleaning Appliances</a>
          <a class="hero-button hero-button-secondary" href="<?= e(url('products.php')) ?>">Shop Now</a>
        </div>
      </div>
      <div class="hero-visual">
        <img src="<?= e(url('assets/images/hero/laundry-room.jpg')) ?>" alt="Bright laundry room with a front-loading washing machine" loading="lazy">
      </div>
    </article>
    <article class="hero-slide" role="group" aria-roledescription="slide" aria-label="4 of 4" aria-hidden="true" inert>
      <div class="hero-copy">
        <p class="hero-kicker">Your home, connected</p>
        <h2>Comfort, Technology and Convenience</h2>
        <p class="hero-description">Find electronics and household essentials that make your home more enjoyable and comfortable.</p>
        <div class="hero-actions">
          <a class="hero-button hero-button-primary" href="<?= e(url('categories.php')) ?>">Discover More</a>
          <a class="hero-button hero-button-secondary" href="<?= e(url('products.php')) ?>">Browse Products</a>
        </div>
      </div>
      <div class="hero-visual">
        <img src="<?= e(url('assets/images/hero/smart-living-room.jpg')) ?>" alt="Elegant modern living room with contemporary furnishings and home technology" loading="lazy">
      </div>
    </article>
  </div>
  <div class="hero-controls" aria-label="Featured collection controls">
    <div class="hero-indicators" role="group" aria-label="Choose a featured collection">
      <button class="hero-indicator is-active" type="button" aria-label="Show slide 1: Everything Your Home Needs" aria-current="true"></button>
      <button class="hero-indicator" type="button" aria-label="Show slide 2: Make Every Kitchen Moment Better" aria-current="false"></button>
      <button class="hero-indicator" type="button" aria-label="Show slide 3: Less Work. More Living." aria-current="false"></button>
      <button class="hero-indicator" type="button" aria-label="Show slide 4: Comfort, Technology and Convenience" aria-current="false"></button>
    </div>
    <div class="hero-arrows">
      <button class="hero-arrow" type="button" data-hero-prev aria-label="Previous featured collection">
        <svg viewBox="0 0 24 24" aria-hidden="true"><path d="m15 18-6-6 6-6"/></svg>
      </button>
      <button class="hero-arrow" type="button" data-hero-next aria-label="Next featured collection">
        <svg viewBox="0 0 24 24" aria-hidden="true"><path d="m9 18 6-6-6-6"/></svg>
      </button>
    </div>
  </div>
</section>
<?php render_promotions(); ?>
<section>
  <h2>Shop by main category</h2>
  <div class="cat-grid">
    <?php foreach ($mainCats as $c): ?>
      <a class="cat" href="<?= e(url('products.php?cat=' . $c['slug'])) ?>">
        <?php if (isset($catThumbs[(int)$c['id']])): ?>
          <span class="cat-product"><img src="<?= e($catThumbs[(int)$c['id']]) ?>" alt="" width="84" height="84" loading="lazy"></span>
        <?php else: ?>
          <span class="ico"><?= e($c['icon']) ?></span>
        <?php endif; ?>
        <b><?= e($c['name']) ?></b>
      </a>
    <?php endforeach; ?>
  </div>
</section>



<?php
$perkItems = [
    ['<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><path d="m9 12 2 2 4-4"/>', 'Genuine &amp; warranted', '12 to 24 months on every appliance'],
    ['<rect x="1" y="3" width="15" height="13"/><path d="M16 8h4l3 3v5h-7V8z"/><circle cx="5.5" cy="18.5" r="2.5"/><circle cx="18.5" cy="18.5" r="2.5"/>', 'Fast delivery', '1 to 2 days within Masaka'],
    ['<rect x="1" y="4" width="22" height="16" rx="2"/><path d="M1 10h22"/>', 'Pay your way', 'MTN, Airtel, card or cash on delivery'],
    ['<path d="M1 4v6h6"/><path d="M3.51 15a9 9 0 1 0 2.13-9.36L1 10"/>', '7-day returns', 'If it arrives faulty, we fix it'],
];
?>
<section class="perks-marquee" aria-label="Why shop with us">
  <div class="perks-track">
    <?php for ($copy = 0; $copy < 4; $copy++): ?>
      <ul class="perks-set"<?= $copy > 0 ? ' aria-hidden="true"' : '' ?>>
        <?php foreach ($perkItems as $perk): ?>
          <li class="perk">
            <b><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><?= $perk[0] ?></svg> <?= $perk[1] ?></b>
            <span><?= $perk[2] ?></span>
          </li>
        <?php endforeach; ?>
      </ul>
    <?php endfor; ?>
  </div>
</section>

<?php if ($newArrivals): ?>
<section class="new-arrivals" aria-labelledby="new-arrivals-heading">
  <div class="na-head">
    <div class="na-title">
      <span class="na-kicker"><i aria-hidden="true"></i> Just landed</span>
      <h2 id="new-arrivals-heading">New Arrivals</h2>
      <p>Fresh additions to our range of home appliances and everyday essentials.</p>
    </div>
    <a class="na-all" href="<?= e(url('products.php?sort=newest')) ?>">View all new arrivals
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg>
    </a>
  </div>
  <div class="na-grid">
    <?php foreach ($newArrivals as $i => $p): $off = discount_pct($p); $out = (int)$p['stock'] < 1; ?>
      <a class="na-card" href="<?= e(url('product.php?slug=' . $p['slug'])) ?>">
        <span class="na-media">
          <img src="<?= e($p['_img']) ?>" alt="<?= e($p['name']) ?>" loading="lazy" onerror="this.onerror=null;this.src='<?= e(url('assets/images/product-image-unavailable.svg')) ?>'">
          <span class="na-badge">New</span>
          <?php if ($off): ?><span class="na-off">-<?= $off ?>%</span><?php endif; ?>
        </span>
        <span class="na-body">
          <span class="na-cat"><?= e($p['category_name']) ?></span>
          <span class="na-name"><?= e($p['name']) ?></span>
          <span class="na-foot">
            <span class="na-price"><strong><?= e(money($p['price'])) ?></strong><?php if ($off): ?><s><?= e(money($p['old_price'])) ?></s><?php endif; ?></span>
            <span class="na-go<?= $out ? ' is-out' : '' ?>"><?= $out ? 'Sold out' : 'View' ?>
              <?php if (!$out): ?><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg><?php endif; ?>
            </span>
          </span>
        </span>
      </a>
    <?php endforeach; ?>
  </div>
</section>
<?php endif; ?>

<?php
$bundleUrl = url('product.php?slug=student-starter-bundle');
?>
<section class="promo-ticker" aria-label="Student offer">
  <div class="promo-track">
    <?php for ($copy = 0; $copy < 4; $copy++): ?>
      <div class="promo-set"<?= $copy > 0 ? ' aria-hidden="true"' : '' ?>>
        <span class="promo-item promo-lead"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M22 10 12 5 2 10l10 5 10-5z"/><path d="M6 12v5c0 1.5 2.7 3 6 3s6-1.5 6-3v-5"/></svg> Student? Save 10% today.</span>
        <span class="promo-item">Enter <strong>STUDENT10</strong> in your cart.</span>
        <span class="promo-item">Our Student Starter Bundle covers a whole hostel kitchen for one low price.</span>
        <a class="promo-item promo-link" href="<?= e($bundleUrl) ?>"<?= $copy > 0 ? ' tabindex="-1"' : '' ?>>See the bundle <span aria-hidden="true">→</span></a>
      </div>
    <?php endfor; ?>
  </div>
</section>

<section>
  <div class="section-head"><h2>Popular picks</h2><a href="<?= e(url('products.php')) ?>">View all →</a></div>
  <div class="grid"><?php foreach ($featured as $p) product_card($p); ?></div>
</section>

<?php if ($deals): ?>
<section>
  <div class="section-head"><h2>Best deals</h2></div>
  <div class="grid"><?php foreach ($deals as $p) product_card($p); ?></div>
</section>
<?php endif; ?>

<section class="featured-products-section" aria-labelledby="featured-products-heading">
  <div class="featured-heading">
    <span class="featured-accent" aria-hidden="true"></span>
    <div>
      <h2 id="featured-products-heading">Featured Products</h2>
      <p>Discover our handpicked home essentials for everyday comfort.</p>
    </div>
  </div>
  <?php if ($featuredProducts): ?>
    <div class="grid featured-products-grid">
      <?php foreach ($featuredProducts as $p) product_card($p, true); ?>
    </div>
  <?php else: ?>
    <div class="empty featured-empty">
      <p>We’re refreshing our featured selection. Explore all our home appliances in the meantime.</p>
      <a class="btn small" href="<?= e(url('products.php')) ?>">Browse all products</a>
    </div>
  <?php endif; ?>
</section>

<section class="why-section" aria-labelledby="why-heading">
  <div class="why-head">
    <span class="na-kicker"><i aria-hidden="true"></i> The HomeEase difference</span>
    <h2 id="why-heading">Why shop with <?= e(SITE_NAME) ?></h2>
    <p>Buying appliances should not mean guessing about quality, warranty or delivery. Here is what you can count on with us.</p>
  </div>
  <ul class="why-grid">
      <li class="why-card">
        <span class="why-ico"><svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><path d="m9 12 2 2 4-4"/></svg></span>
        <h3>Genuine, warranty-backed</h3>
        <p>Every product page states its warranty, from 12 to 24 months, so you know what you are covered for before you buy.</p>
      </li>
      <li class="why-card">
        <span class="why-ico"><svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><rect x="1" y="3" width="15" height="13"/><path d="M16 8h4l3 3v5h-7V8z"/><circle cx="5.5" cy="18.5" r="2.5"/><circle cx="18.5" cy="18.5" r="2.5"/></svg></span>
        <h3>Delivery across Uganda</h3>
        <p>Our own riders and vans in Masaka, courier or bus to the rest of the country, and free delivery in Masaka on qualifying orders.</p>
      </li>
      <li class="why-card">
        <span class="why-ico"><svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><rect x="1" y="4" width="22" height="16" rx="2"/><path d="M1 10h22"/></svg></span>
        <h3>Pay the way you prefer</h3>
        <p>MTN or Airtel mobile money, card, or cash on delivery in and around Masaka. No need to pay before you see the order.</p>
      </li>
      <li class="why-card">
        <span class="why-ico"><svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M1 4v6h6"/><path d="M3.51 15a9 9 0 1 0 2.13-9.36L1 10"/></svg></span>
        <h3>Simple 7-day returns</h3>
        <p>Faulty, damaged or wrong item? Tell us within 7 days and we repair, replace or refund it, and we cover the return delivery.</p>
      </li>
      <li class="why-card">
        <span class="why-ico"><svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M22 10 12 5 2 10l10 5 10-5z"/><path d="M6 12v5c0 1.5 2.7 3 6 3s6-1.5 6-3v-5"/></svg></span>
        <h3>Made for students and young families</h3>
        <p>Use code STUDENT10 for 10% off, or grab the Student Starter Bundle that covers a whole hostel kitchen in one go.</p>
      </li>
      <li class="why-card">
        <span class="why-ico"><svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg></span>
        <h3>Real people, quick replies</h3>
        <p>Call or WhatsApp us and talk to a person. For returns and warranty claims we reply within one working day.</p>
      </li>
  </ul>

  <div class="why-cta">
    <div>
      <b>Not sure which appliance is right for you?</b>
      <span>Talk to us and we will help you choose.</span>
    </div>
    <div class="why-cta-actions">
      <a class="hero-button hero-button-primary" href="https://wa.me/<?= e(SITE_WHATSAPP) ?>" rel="noopener">Chat on WhatsApp</a>
      <a class="hero-button why-call" href="tel:<?= e(SITE_PHONE) ?>">Call <?= e(SITE_PHONE) ?></a>
    </div>
  </div>
</section>

<?php
$avgRounded = (int)round($reviewStats['avg']);
$starRow = static function (int $rating): string {
    $rating = max(0, min(5, $rating));
    return '<span class="rv-stars" role="img" aria-label="' . $rating . ' out of 5 stars">'
        . str_repeat('<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2.5l2.9 6.1 6.6.9-4.8 4.6 1.2 6.6L12 17.5l-5.9 3.2 1.2-6.6L2.5 9.5l6.6-.9z"/></svg>', $rating)
        . str_repeat('<svg class="off" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2.5l2.9 6.1 6.6.9-4.8 4.6 1.2 6.6L12 17.5l-5.9 3.2 1.2-6.6L2.5 9.5l6.6-.9z"/></svg>', 5 - $rating)
        . '</span>';
};
?>
<section class="reviews-home" aria-labelledby="reviews-home-heading">
  <div class="rv-head">
    <h2 id="reviews-home-heading">What Our Customers Say</h2>
    <p>Hear directly from our shoppers about their <?= e(SITE_NAME) ?> experience.</p>
    <?php if ($reviewStats['n'] > 0): ?>
      <div class="rv-summary">
        <?= $starRow($avgRounded) ?>
        <strong><?= e(number_format($reviewStats['avg'], 1)) ?></strong>
        <span>(<?= (int)$reviewStats['n'] ?> review<?= $reviewStats['n'] === 1 ? '' : 's' ?>)</span>
      </div>
    <?php endif; ?>
  </div>

  <?php if ($homeReviews): ?>
    <div class="rv-grid">
      <?php foreach ($homeReviews as $rv):
        $first = trim((string)$rv['first_name']);
        $last = trim((string)$rv['last_name']);
        $who = $first . ($last !== '' ? ' ' . strtoupper(function_exists('mb_substr') ? mb_substr($last, 0, 1) : substr($last, 0, 1)) . '.' : '');
        $initial = strtoupper(function_exists('mb_substr') ? mb_substr($first !== '' ? $first : '?', 0, 1) : substr($first !== '' ? $first : '?', 0, 1));
        $body = (string)$rv['body'];
        if (function_exists('mb_strimwidth')) { $body = mb_strimwidth($body, 0, 170, '…'); }
        elseif (strlen($body) > 170) { $body = substr($body, 0, 167) . '…'; }
      ?>
        <article class="rv-card">
          <?= $starRow((int)$rv['rating']) ?>
          <h3><?= e(($rv['title'] ?? '') !== '' ? $rv['title'] : $rv['product_name']) ?></h3>
          <p class="rv-body"><?= e($body) ?></p>
          <a class="rv-product" href="<?= e(url('product.php?slug=' . $rv['slug'])) ?>"><?= e($rv['product_name']) ?></a>
          <div class="rv-by">
            <span class="rv-avatar" aria-hidden="true"><?= e($initial) ?></span>
            <span><b><?= e($who) ?></b><small><?= e(date('F j, Y', strtotime((string)$rv['created_at']))) ?></small></span>
          </div>
        </article>
      <?php endforeach; ?>
    </div>
  <?php else: ?>
    <p class="rv-empty">No reviews yet. Be the first to share your experience after your order arrives.</p>
  <?php endif; ?>

  <div class="rv-actions">
    <a class="rv-btn rv-btn-primary" href="<?= e(url('customer/reviews.php')) ?>">Write a Review</a>
    <a class="rv-btn rv-btn-ghost" href="<?= e(url('reviews.php')) ?>">View All Reviews</a>
  </div>
</section>

<?php require __DIR__ . '/includes/footer.php'; ?>

<?php
// TEMPORARY diagnostic v2. Upload next to register.php, open it, refresh 3 times, then DELETE it.
// Use:  /session-test2.php?mode=custom   (default: your current setup, name homeease_sid)
//       /session-test2.php?mode=default  (plain PHPSESSID, no custom cookie params)
//       /session-test2.php?mode=nolax    (homeease_sid, no SameSite/HttpOnly)
$mode = $_GET['mode'] ?? 'custom';
header('Content-Type: text/plain'); header('Cache-Control: no-store');

// Plain cookies, set without sessions, to see if ANY server cookie survives
setcookie('t_plain', '1', 0, '/');
setcookie('t_lax', '1', ['path' => '/', 'httponly' => true, 'samesite' => 'Lax']);

if ($mode === 'default') {
    // nothing custom
} elseif ($mode === 'nolax') {
    session_name('homeease_sid');
    session_set_cookie_params(0, '/');
} else {
    session_name('homeease_sid');
    session_set_cookie_params(['lifetime' => 0, 'path' => '/', 'secure' => false, 'httponly' => true, 'samesite' => 'Lax']);
}
$ok = session_start();
$_SESSION['hits'] = ($_SESSION['hits'] ?? 0) + 1;

echo "mode               : $mode\n";
echo "session name      : " . session_name() . "\n";
echo "session id        : " . session_id() . "\n";
echo "session_start ok  : " . var_export($ok, true) . "\n";
echo "hits              : " . $_SESSION['hits'] . "  (must be 1,2,3 on refresh)\n";
echo "session cookie in : " . (isset($_COOKIE[session_name()]) ? 'YES' : 'NO') . "\n";
echo "t_plain in        : " . (isset($_COOKIE['t_plain']) ? 'YES' : 'NO') . "  (plain server cookie)\n";
echo "t_lax in          : " . (isset($_COOKIE['t_lax']) ? 'YES' : 'NO') . "  (HttpOnly+Lax cookie)\n";
echo "headers sent early: " . (headers_sent($f, $l) ? "YES at $f:$l" : 'no') . "\n";
echo "PHP version       : " . PHP_VERSION . "\n";
echo "save path         : " . session_save_path() . "\n";
echo "gc/cookie ini     : lifetime=" . ini_get('session.cookie_lifetime') . " domain='" . ini_get('session.cookie_domain') . "' secure=" . ini_get('session.cookie_secure') . "\n";
echo "\nSet-Cookie headers PHP is sending:\n";
foreach (headers_list() as $h) { if (stripos($h, 'Set-Cookie') === 0) echo "  $h\n"; }
echo "\nCookies the browser sent: " . implode(', ', array_keys($_COOKIE)) . "\n";

<?php
$adminTitle = 'Move product photos into the database';
require __DIR__ . '/_top.php';

// Finds products whose photo is a plain file in assets/uploads/ on THIS server and copies it
// into the database, so the photo shows on every copy of the site that shares the database.
$rows = q("SELECT id, name, image FROM products WHERE image <> '' AND image NOT LIKE 'db:%' ORDER BY id")->fetchAll();
$candidates = [];
foreach ($rows as $r) {
    $file = __DIR__ . '/../assets/uploads/' . basename((string)$r['image']);
    if (basename((string)$r['image']) === $r['image'] && is_file($file)) {
        $candidates[] = $r + ['path' => $file];
    }
}
$done = 0;
$failed = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    foreach ($candidates as $c) {
        $ref = product_image_store($c['path']);
        if ($ref === null) { $failed[] = $c['name']; continue; }
        q('UPDATE products SET image = ? WHERE id = ?', [$ref, (int)$c['id']]);
        $done++;
    }
    $candidates = array_values(array_filter($candidates, static fn($c) => in_array($c['name'], $failed, true)));
}
?>
<h1>Move product photos into the database</h1>
<?php if ($_SERVER['REQUEST_METHOD'] === 'POST'): ?>
  <div class="alert success" role="status"><?= (int)$done ?> photo(s) moved.<?= $failed ? ' Could not move: ' . e(implode(', ', $failed)) . '.' : '' ?></div>
<?php endif; ?>
<div class="panel">
  <?php if (!$candidates): ?>
    <p>Nothing to move: no product on this server has a photo stored only as a file in <code>assets/uploads</code>.</p>
  <?php else: ?>
    <p>These products have photos stored only as files on this server:</p>
    <ul><?php foreach ($candidates as $c): ?><li><?= e($c['name']) ?> <span class="muted">(<?= e($c['image']) ?>)</span></li><?php endforeach; ?></ul>
    <form method="post"><?= csrf_field() ?><button class="btn" type="submit">Move them into the database</button></form>
  <?php endif; ?>
</div>
<?php require __DIR__ . '/_bottom.php'; ?>

</main>
</div>
<script src="<?= e(url('assets/js/admin-notifications.js?v=' . filemtime(__DIR__ . '/../assets/js/admin-notifications.js'))) ?>"></script>
<script src="<?= e(url('assets/js/app.js?v=' . filemtime(__DIR__ . '/../assets/js/app.js'))) ?>"></script>
</body>
</html>
<?php ob_end_flush(); ?>

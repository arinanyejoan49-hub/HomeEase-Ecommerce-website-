<?php
$adminTitle = 'Promotions';
require __DIR__ . '/_top.php';
require_once __DIR__ . '/../includes/promotions.php';

if (!promotions_ensure_table()) {
    echo '<h1>Promotions</h1><div class="alert error">The promotions table could not be created. Please run database/migrations/add_promotions.sql.</div>';
    require __DIR__ . '/_bottom.php';
    return;
}

$themes = promotions_themes();
$def = $themes['orange'];
$tz = promotions_tz();
$nowDt = new DateTimeImmutable('now', $tz);

// Form values (defaults for a new promotion)
$f = [
    'id' => 0, 'badge' => '', 'title' => '', 'button_text' => 'Shop the offer', 'link_url' => 'products.php',
    'starts_at' => $nowDt->format('Y-m-d 00:00:00'), 'ends_at' => $nowDt->modify('+14 days')->format('Y-m-d 23:59:59'),
    'color_from' => $def['from'], 'color_to' => $def['to'], 'color_accent' => $def['accent'], 'color_text' => $def['text'],
    'sort_order' => 0, 'is_active' => 1,
];
$editId = (int)($_GET['edit'] ?? 0);
if ($editId) {
    $row = q('SELECT * FROM promotions WHERE id = ?', [$editId])->fetch();
    if ($row) { $f = array_merge($f, $row); } else { $editId = 0; }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $action = post('action', 20);
    $id = (int)($_POST['id'] ?? 0);

    if ($action === 'delete') {
        q('DELETE FROM promotions WHERE id = ?', [$id]);
        flash('success', 'Promotion deleted.');
        redirect('admin/promotions.php');
    }
    if ($action === 'toggle') {
        q('UPDATE promotions SET is_active = 1 - is_active, updated_at = ? WHERE id = ?', [$nowDt->format('Y-m-d H:i:s'), $id]);
        redirect('admin/promotions.php');
    }
    if ($action === 'duplicate') {
        $src = q('SELECT * FROM promotions WHERE id = ?', [$id])->fetch();
        if ($src) {
            q('INSERT INTO promotions (badge, title, button_text, link_url, starts_at, ends_at, color_from, color_to, color_accent, color_text, sort_order, is_active)
               VALUES (?,?,?,?,?,?,?,?,?,?,?,0)',
              [$src['badge'], mb_substr($src['title'] . ' (copy)', 0, 120), $src['button_text'], $src['link_url'], $src['starts_at'], $src['ends_at'],
               $src['color_from'], $src['color_to'], $src['color_accent'], $src['color_text'], $src['sort_order']]);
            flash('success', 'Promotion duplicated and hidden. Edit its dates, then publish it.');
        }
        redirect('admin/promotions.php');
    }

    // Save (create or update)
    $f['id'] = $id;
    $f['badge'] = post('badge', 60);
    $f['title'] = post('title', 120);
    $f['button_text'] = post('button_text', 40) ?: 'Shop the offer';
    $rawLink = post('link_url', 255);
    $resolved = promo_resolve_link($rawLink);
    $f['link_url'] = $resolved ?? $rawLink;
    $f['color_from'] = promo_color($_POST['color_from'] ?? '', $def['from']);
    $f['color_to'] = promo_color($_POST['color_to'] ?? '', $def['to']);
    $f['color_accent'] = promo_color($_POST['color_accent'] ?? '', $def['accent']);
    $f['color_text'] = promo_color($_POST['color_text'] ?? '', $def['text']);
    $f['sort_order'] = (int)($_POST['sort_order'] ?? 0);
    $f['is_active'] = isset($_POST['is_active']) ? 1 : 0;

    $errs = [];
    $parse = function (string $key) use ($tz): ?DateTimeImmutable {
        $v = post($key, 16);
        $d = DateTimeImmutable::createFromFormat('!Y-m-d\TH:i', $v, $tz);
        return $d ?: null;
    };
    $start = $parse('starts_at');
    $end = $parse('ends_at');
    if ($f['title'] === '') { $errs[] = 'Title is required.'; }
    if ($resolved === null) { $errs[] = 'The button link was not recognised. Pick a page, category or product from the list, or type a full https:// address.'; }
    if (!$start || !$end) {
        $errs[] = 'Please enter valid start and end dates.';
    } else {
        $end = $end->setTime((int)$end->format('H'), (int)$end->format('i'), 59); // ends at the end of that minute
        $f['starts_at'] = $start->format('Y-m-d H:i:s');
        $f['ends_at'] = $end->format('Y-m-d H:i:s');
        if ($end <= $start) { $errs[] = 'The end date must be after the start date.'; }
    }

    if (!$errs) {
        $vals = [$f['badge'], $f['title'], $f['button_text'], $f['link_url'], $f['starts_at'], $f['ends_at'],
                 $f['color_from'], $f['color_to'], $f['color_accent'], $f['color_text'], $f['sort_order'], $f['is_active']];
        if ($id > 0) {
            q('UPDATE promotions SET badge=?, title=?, button_text=?, link_url=?, starts_at=?, ends_at=?, color_from=?, color_to=?, color_accent=?, color_text=?, sort_order=?, is_active=?, updated_at=? WHERE id=?',
              array_merge($vals, [$nowDt->format('Y-m-d H:i:s'), $id]));
            flash('success', 'Promotion updated.');
        } else {
            q('INSERT INTO promotions (badge, title, button_text, link_url, starts_at, ends_at, color_from, color_to, color_accent, color_text, sort_order, is_active) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)', $vals);
            flash('success', 'Promotion added.');
        }
        redirect('admin/promotions.php');
    }
    $editId = $id;
    $formErrors = $errs;
}
$formErrors = $formErrors ?? [];
$linkOpts = promo_link_options();

$promos = q('SELECT * FROM promotions ORDER BY sort_order, id')->fetchAll();
$statusMeta = [
    'live' => ['Live now', 'delivered'], 'scheduled' => ['Scheduled', 'confirmed'],
    'ended' => ['Ended', 'cancelled'], 'hidden' => ['Hidden', 'pending'],
];
$dtLocal = fn(string $v) => promo_dt($v)->format('Y-m-d\TH:i');
?>
<h1>Promotions</h1>
<p>Offers shown in the <b>Promotion of the month</b> section on the home page. Each card counts down to its end date and removes itself automatically when the offer expires.</p>

<div class="panel pm-admin" id="promo-form">
  <h2><?= $editId ? 'Edit promotion' : 'Add promotion' ?></h2>
  <?php foreach ($formErrors as $er): ?><div class="alert error" role="alert" data-form-error><?= e($er) ?> <b>Nothing was saved.</b></div><?php endforeach; ?>
  <div class="pm-admin-cols">
    <form method="post" class="form-grid" id="promo-editor">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="save">
      <input type="hidden" name="id" value="<?= (int)$editId ?>">
      <label>Badge text <input type="text" name="badge" maxlength="60" placeholder="e.g. November offer" value="<?= e($f['badge']) ?>"></label>
      <label>Title <input type="text" name="title" maxlength="120" required placeholder="e.g. Black Friday" value="<?= e($f['title']) ?>"></label>
      <label>Button text <input type="text" name="button_text" maxlength="40" value="<?= e($f['button_text']) ?>"></label>
      <div class="full">
        <label for="link_pick">Button goes to</label>
        <select id="link_pick" aria-label="Choose where the button goes">
          <option value="">Custom link (type below)</option>
          <optgroup label="Pages">
            <?php foreach ($linkOpts['pages'] as $n => $l): ?><option value="<?= e($l) ?>"<?= $f['link_url'] === $l ? ' selected' : '' ?>><?= e($n) ?></option><?php endforeach; ?>
          </optgroup>
          <?php if ($linkOpts['categories']): ?><optgroup label="Categories">
            <?php foreach ($linkOpts['categories'] as $n => $l): ?><option value="<?= e($l) ?>"<?= $f['link_url'] === $l ? ' selected' : '' ?>><?= e($n) ?></option><?php endforeach; ?>
          </optgroup><?php endif; ?>
          <?php if ($linkOpts['products']): ?><optgroup label="Products">
            <?php foreach ($linkOpts['products'] as $n => $l): ?><option value="<?= e($l) ?>"<?= $f['link_url'] === $l ? ' selected' : '' ?>><?= e($n) ?></option><?php endforeach; ?>
          </optgroup><?php endif; ?>
        </select>
        <input type="text" name="link_url" maxlength="255" value="<?= e($f['link_url']) ?>" placeholder="e.g. products.php?cat=kitchen or https://..." style="margin-top:6px;">
        <small class="muted">Choose from the list, or type a page address. Typing an exact product or category name also works.</small>
      </div>
      <label>Starts (Uganda time) <input type="datetime-local" name="starts_at" required value="<?= e($dtLocal($f['starts_at'])) ?>"></label>
      <label>Ends (Uganda time) <input type="datetime-local" name="ends_at" required value="<?= e($dtLocal($f['ends_at'])) ?>"></label>
      <label>Display order <input type="number" name="sort_order" value="<?= (int)$f['sort_order'] ?>"></label>
      <label class="check"><input type="checkbox" name="is_active" <?= $f['is_active'] ? 'checked' : '' ?>> Show on the home page</label>

      <div class="full pm-colors">
        <b>Colours</b>
        <div class="pm-presets" role="group" aria-label="Colour presets from the store palette">
          <?php foreach ($themes as $key => $t): ?>
            <button type="button" class="pm-preset" data-from="<?= e($t['from']) ?>" data-to="<?= e($t['to']) ?>" data-accent="<?= e($t['accent']) ?>" data-text="<?= e($t['text']) ?>">
              <span class="pm-swatch" style="background:linear-gradient(135deg,<?= e($t['from']) ?>,<?= e($t['to']) ?>);border-color:<?= e($t['accent']) ?>"></span><?= e($t['label']) ?>
            </button>
          <?php endforeach; ?>
        </div>
        <div class="pm-pickers">
          <label>Background start <input type="color" name="color_from" value="<?= e(strtolower($f['color_from'])) ?>"></label>
          <label>Background end <input type="color" name="color_to" value="<?= e(strtolower($f['color_to'])) ?>"></label>
          <label>Button &amp; highlights <input type="color" name="color_accent" value="<?= e(strtolower($f['color_accent'])) ?>"></label>
          <label>Text <input type="color" name="color_text" value="<?= e(strtolower($f['color_text'])) ?>"></label>
        </div>
      </div>

      <div class="full">
        <button class="btn" type="submit"><?= $editId ? 'Update promotion' : 'Add promotion' ?></button>
        <?php if ($editId): ?><a class="btn ghost" href="<?= e(url('admin/promotions.php')) ?>">Cancel</a><?php endif; ?>
      </div>
    </form>

    <div class="pm-preview" aria-label="Live preview">
      <small class="muted">Live preview</small>
      <?php render_promo_card($f, true); ?>
    </div>
  </div>
</div>

<?php if (!$promos): ?>
  <p class="empty">No promotions yet. Add one above.</p>
<?php else: ?>
<div class="table-wrap">
<table class="data">
  <thead><tr><th>Order</th><th>Promotion</th><th>Schedule (Uganda time)</th><th>Status</th><th>Actions</th></tr></thead>
  <tbody>
  <?php foreach ($promos as $p): $st = promo_status($p, $nowDt); [$stLabel, $stClass] = $statusMeta[$st]; ?>
    <tr>
      <td><?= (int)$p['sort_order'] ?></td>
      <td>
        <span class="pm-swatch" style="background:linear-gradient(135deg,<?= e($p['color_from']) ?>,<?= e($p['color_to']) ?>);border-color:<?= e($p['color_accent']) ?>"></span>
        <b><?= e($p['title']) ?></b><?= $p['badge'] !== '' ? '<br><small class="muted">' . e($p['badge']) . '</small>' : '' ?>
      </td>
      <td><small><?= e(promo_dt($p['starts_at'])->format('j M Y, H:i')) ?><br>to <?= e(promo_dt($p['ends_at'])->format('j M Y, H:i')) ?></small></td>
      <td><span class="pill <?= e($stClass) ?>"><?= e($stLabel) ?></span></td>
      <td>
        <a class="btn small" href="<?= e(url('admin/promotions.php?edit=' . (int)$p['id'])) ?>#promo-form">Edit</a>
        <form method="post" style="display:inline;"><?= csrf_field() ?><input type="hidden" name="action" value="toggle"><input type="hidden" name="id" value="<?= (int)$p['id'] ?>">
          <button class="btn small ghost" type="submit"><?= $p['is_active'] ? 'Hide' : 'Show' ?></button></form>
        <form method="post" style="display:inline;"><?= csrf_field() ?><input type="hidden" name="action" value="duplicate"><input type="hidden" name="id" value="<?= (int)$p['id'] ?>">
          <button class="btn small ghost" type="submit">Duplicate</button></form>
        <form method="post" style="display:inline;" onsubmit="return confirm('Delete this promotion?')"><?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int)$p['id'] ?>">
          <button class="btn small danger" type="submit">Delete</button></form>
      </td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>
</div>
<?php endif; ?>

<script>
(function () {
  var form = document.getElementById('promo-editor');
  var card = document.querySelector('[data-promo-preview]');
  if (!form || !card) { return; }
  var el = form.elements;
  function lin(c) { c /= 255; return c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4); }
  function rgb(h) { return [parseInt(h.substr(1, 2), 16), parseInt(h.substr(3, 2), 16), parseInt(h.substr(5, 2), 16)]; }
  function ink(h) {
    var c = rgb(h), l = 0.2126 * lin(c[0]) + 0.7152 * lin(c[1]) + 0.0722 * lin(c[2]);
    return (l + 0.05) / 0.0556 >= 1.05 / (l + 0.05) ? '#111111' : '#FFFFFF';
  }
  function setText(k, v) { var n = card.querySelector('[data-pv="' + k + '"]'); if (n) { n.textContent = v; } }
  function refresh() {
    var from = el.color_from.value, to = el.color_to.value, acc = el.color_accent.value, txt = el.color_text.value;
    card.style.setProperty('--pm-from', from); card.style.setProperty('--pm-to', to);
    card.style.setProperty('--pm-accent', acc); card.style.setProperty('--pm-ink', ink(acc));
    card.style.setProperty('--pm-text', txt);
    card.style.setProperty('--pm-from-rgb', rgb(from).join(',')); card.style.setProperty('--pm-accent-rgb', rgb(acc).join(','));
    card.style.setProperty('--pm-text-rgb', rgb(txt).join(','));
    setText('badge', el.badge.value); setText('title', el.title.value || 'Promotion title');
    setText('button_text', el.button_text.value || 'Shop the offer');
    var m = /^(\d{4})-(\d{2})-(\d{2})/.exec(el.ends_at.value);
    if (m) {
      var d = new Date(+m[1], +m[2] - 1, +m[3]);
      var wd = d.toLocaleDateString('en-GB', { weekday: 'long' }), mo = d.toLocaleDateString('en-GB', { month: 'long' });
      setText('valid', wd + ' ' + d.getDate() + ' ' + mo + ' ' + d.getFullYear());
    }
  }
  form.addEventListener('input', refresh);
  var pick = document.getElementById('link_pick');
  if (pick) {
    pick.addEventListener('change', function () { if (pick.value) { el.link_url.value = pick.value; } });
    el.link_url.addEventListener('input', function () {
      var match = Array.prototype.some.call(pick.options, function (o) { return o.value && o.value === el.link_url.value; });
      if (!match) { pick.value = ''; }
    });
  }
  var err = document.querySelector('[data-form-error]');
  if (err) { err.scrollIntoView({ block: 'center' }); }
  document.querySelectorAll('.pm-preset').forEach(function (b) {
    b.addEventListener('click', function () {
      el.color_from.value = b.dataset.from.toLowerCase(); el.color_to.value = b.dataset.to.toLowerCase();
      el.color_accent.value = b.dataset.accent.toLowerCase(); el.color_text.value = b.dataset.text.toLowerCase();
      refresh();
    });
  });
  refresh();
})();
</script>
<?php require __DIR__ . '/_bottom.php'; ?>

<?php
$adminTitle = 'Compose email';
require __DIR__ . '/_top.php';
require_once __DIR__ . '/../includes/email.php';
$smtpStatus = email_smtp_status();

$values = ['recipient' => '', 'customer_id' => '', 'subject' => '', 'body' => ''];
$contactMessageId = null;
$customerId = null;
$hasCustomerEmailLink = table_exists('email_messages') && column_exists('email_messages', 'customer_id');
$inReplyTo = null;
$replySourceForForm = '';
$replyMessageIdForForm = null;
$errors = [];
$replySource = is_string($_GET['reply_source'] ?? null) ? $_GET['reply_source'] : '';
$replyId = filter_var($_GET['reply_id'] ?? null, FILTER_VALIDATE_INT);
$forwardSource = is_string($_GET['forward_source'] ?? null) ? $_GET['forward_source'] : '';
$forwardId = filter_var($_GET['forward_id'] ?? null, FILTER_VALIDATE_INT);

if (in_array($replySource, ['website', 'email'], true) && $replyId) {
    $replySourceForForm = $replySource;
    $replyMessageIdForForm = (int)$replyId;
    if ($replySource === 'website') {
        $original = q('SELECT id, name, email, subject'
            . (column_exists('messages', 'customer_id') ? ', customer_id' : '')
            . ' FROM messages WHERE id = ?', [$replyId])->fetch();
        if ($original) {
            $values['recipient'] = $original['email'];
            $values['subject'] = 'Re: ' . preg_replace('/^(Re:\s*)+/i', '', $original['subject']);
            $contactMessageId = (int)$original['id'];
            $customerId = isset($original['customer_id']) ? (int)$original['customer_id'] : null;
        }
    } else {
        $original = q("SELECT id, sender_name, sender_email, subject, rfc_message_id, provider_message_id"
                       . ($hasCustomerEmailLink ? ', customer_id' : '') . "
                       FROM email_messages WHERE id = ? AND direction = 'incoming'", [$replyId])->fetch();
        if ($original) {
            $values['recipient'] = $original['sender_email'];
            $values['subject'] = 'Re: ' . preg_replace('/^(Re:\s*)+/i', '', $original['subject']);
            $inReplyTo = $original['rfc_message_id'] ?: $original['provider_message_id'];
            $customerId = isset($original['customer_id']) ? (int)$original['customer_id'] : null;
        }
    }
    if (!$original) {
        flash('error', 'The message you are replying to could not be found.');
        redirect('admin/email-inbox.php');
    }
} elseif (in_array($forwardSource, ['website', 'email'], true) && $forwardId) {
    $original = $forwardSource === 'website'
        ? q('SELECT subject, message AS body FROM messages WHERE id = ?', [$forwardId])->fetch()
        : q("SELECT subject, body FROM email_messages WHERE id = ? AND direction = 'incoming'", [$forwardId])->fetch();
    if (!$original) {
        flash('error', 'The message you are forwarding could not be found.');
        redirect('admin/email-inbox.php');
    }
    $values['subject'] = 'Fwd: ' . preg_replace('/^(Fwd:\s*)+/i', '', $original['subject']);
    $values['body'] = "\n\n---------- Forwarded message ----------\nSubject: {$original['subject']}\n\n{$original['body']}";
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $values['recipient'] = post('recipient', 160);
    $values['customer_id'] = post('customer_id', 12);
    $values['subject'] = post('subject', 255);
    $values['body'] = post('body', 10000);
    if ($values['customer_id'] !== '') {
        $customerId = filter_var($values['customer_id'], FILTER_VALIDATE_INT);
        $customer = $customerId
            ? q("SELECT id, first_name, last_name, email FROM users WHERE id = ? AND status = 'active'", [$customerId])->fetch()
            : false;
        if (!$customer) {
            $errors[] = 'Choose a valid active customer.';
        } else {
            $values['recipient'] = $customer['email'];
        }
    }
    if (!filter_var($values['recipient'], FILTER_VALIDATE_EMAIL)) { $errors[] = 'Enter a valid recipient email address.'; }
    if ($values['subject'] === '' || preg_match('/[\r\n]/', $values['subject'])) { $errors[] = 'Enter a valid subject.'; }
    if (mb_strlen($values['body']) < 1) { $errors[] = 'Write a message before sending.'; }
    if (!$errors && $replySourceForForm !== '' && $replyMessageIdForForm !== null) {
        $postedSource = post('reply_source', 12);
        $postedId = filter_var($_POST['reply_id'] ?? null, FILTER_VALIDATE_INT);
        if ($postedSource === $replySourceForForm && $postedId === $replyMessageIdForForm && $postedSource === 'website') {
            $validReply = q('SELECT id FROM messages WHERE id = ? AND email = ?', [$postedId, $values['recipient']])->fetch();
            if ($validReply) { $contactMessageId = (int)$postedId; }
            else { $errors[] = 'The reply recipient no longer matches the original enquiry.'; }
        } elseif ($postedSource === $replySourceForForm && $postedId === $replyMessageIdForForm && $postedSource === 'email') {
            $validReply = q("SELECT rfc_message_id, provider_message_id"
                . ($hasCustomerEmailLink ? ', customer_id' : '')
                . " FROM email_messages WHERE id = ? AND direction = 'incoming' AND sender_email = ?",
                [$postedId, $values['recipient']])->fetch();
            if ($validReply) {
                $inReplyTo = $validReply['rfc_message_id'] ?: $validReply['provider_message_id'];
                $customerId = isset($validReply['customer_id']) ? (int)$validReply['customer_id'] : null;
            }
            else { $errors[] = 'The reply recipient no longer matches the original email.'; }
        } else {
            $errors[] = 'The original reply message could not be verified.';
        }
    }
    if (!$errors) {
        if ($hasCustomerEmailLink) {
            q('INSERT INTO email_messages
                (direction, sender_email, sender_name, recipient_email, subject, body, status, contact_message_id, customer_id, admin_id, provider_message_id, in_reply_to)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?)',
                [
                    'outgoing', EMAIL_FROM_ADDRESS, EMAIL_FROM_NAME, $values['recipient'], $values['subject'], $values['body'],
                    'queued', $contactMessageId, $customerId, (int)$_SESSION['admin_id'], null,
                    $inReplyTo,
                ]);
        } else {
            q('INSERT INTO email_messages
                (direction, sender_email, sender_name, recipient_email, subject, body, status, contact_message_id, admin_id, provider_message_id, in_reply_to)
                VALUES (?,?,?,?,?,?,?,?,?,?,?)',
                [
                    'outgoing', EMAIL_FROM_ADDRESS, EMAIL_FROM_NAME, $values['recipient'], $values['subject'], $values['body'],
                    'queued', $contactMessageId, (int)$_SESSION['admin_id'], null,
                    $inReplyTo,
                ]);
        }
        $sentId = (int)db()->lastInsertId();
        $result = send_store_email($values['recipient'], '', $values['subject'], $values['body'], EMAIL_FROM_ADDRESS, $inReplyTo);
        $status = $result['success'] ? 'sent_to_server' : $result['state'];
        q('UPDATE email_messages SET status = ?, provider_message_id = ?, rfc_message_id = ? WHERE id = ?', [
            $status,
            $result['success'] ? ($result['message_id'] ?: null) : null,
            $result['success'] ? ($result['message_id'] ?: null) : null,
            $sentId,
        ]);
        email_audit($result['success'] ? 'send' : 'send_failed', $contactMessageId ? 'website' : 'email', $contactMessageId ?: $sentId);
        if ($result['success']) {
            if ($contactMessageId) {
                q("UPDATE messages SET status = 'read' WHERE id = ?", [$contactMessageId]);
            }
            flash('success', 'Email accepted by the configured mail server. Delivery is not confirmed.');
            redirect('admin/email-sent.php');
        }
        $errors[] = $result['error'];
    }
}
$customers = q("SELECT id, first_name, last_name, email FROM users WHERE status = 'active' ORDER BY first_name, last_name LIMIT 500")->fetchAll();
?>
<div class="section-head"><div><h1>Compose email</h1><p class="muted">Messages send from the configured business email address.</p></div><a class="btn ghost" href="<?= e(url('admin/email.php')) ?>">Email overview</a></div>
<?php if ($errors): ?><div class="alert error" role="alert"><ul><?php foreach ($errors as $error): ?><li><?= e($error) ?></li><?php endforeach; ?></ul></div><?php endif; ?>
<?php if ($smtpStatus['state'] !== 'ready'): ?><div class="alert error" role="status">
  <?php if ($smtpStatus['state'] === 'missing_settings'): ?>SMTP settings are incomplete. Add your Gmail app password to <code>config.local.php</code>.
  <?php elseif ($smtpStatus['state'] === 'mailer_unavailable'): ?>PHPMailer is unavailable. Run Composer install in the project directory.
  <?php else: ?>SMTP settings are invalid. Check the sender address, host, port, and encryption mode.
  <?php endif; ?>
  <a href="<?= e(url('admin/email-settings.php')) ?>">View email settings</a>.
</div><?php endif; ?>
<form method="post" class="panel email-compose-form">
  <?= csrf_field() ?>
  <?php if ($replySourceForForm !== '' && $replyMessageIdForForm !== null): ?><input type="hidden" name="reply_source" value="<?= e($replySourceForForm) ?>"><input type="hidden" name="reply_id" value="<?= $replyMessageIdForForm ?>"><?php endif; ?>
  <label>Registered customer <select name="customer_id"><option value="">Enter an email address</option><?php foreach ($customers as $customer): ?><option value="<?= (int)$customer['id'] ?>" <?= (string)$customer['id'] === $values['customer_id'] ? 'selected' : '' ?>><?= e($customer['first_name'] . ' ' . $customer['last_name'] . ' · ' . $customer['email']) ?></option><?php endforeach; ?></select></label>
  <label>Recipient email <input type="email" name="recipient" maxlength="160" required value="<?= e($values['recipient']) ?>"></label>
  <label>Subject <input name="subject" maxlength="255" required value="<?= e($values['subject']) ?>"></label>
  <label>Message <textarea name="body" rows="12" maxlength="10000" required><?= e($values['body']) ?></textarea></label>
  <button class="btn" type="submit">Send email</button>
</form>
<?php require __DIR__ . '/_bottom.php'; ?>

<?php
$adminTitle = 'Support tickets';
require __DIR__ . '/_top.php';

if (!table_exists('support_tickets')) {
    echo '<h1>Support tickets</h1><p class="alert error">The support-ticket tables are not installed. Apply the customer dashboard database migration.</p>';
    require __DIR__ . '/_bottom.php';
    exit;
}

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $id = (int)($_POST['id'] ?? 0);
    $status = post('status', 12);
    $reply = post('admin_reply', 5000);
    if ($id < 1) $errors[] = 'Select a valid support ticket.';
    if (!in_array($status, ['open', 'answered', 'closed'], true)) $errors[] = 'Select a valid ticket status.';
    if (!$errors && !q('SELECT id FROM support_tickets WHERE id = ?', [$id])->fetch()) {
        $errors[] = 'Support ticket not found.';
    }

    if (!$errors) {
        q('UPDATE support_tickets SET admin_reply = ?, status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?', [
            $reply !== '' ? $reply : null,
            $status,
            $id,
        ]);
        flash('success', 'Support ticket updated.');
        redirect('admin/support.php');
    }
}

$tickets = q(
    'SELECT t.*, u.first_name, u.last_name, u.email AS customer_email, o.id AS linked_order_id
     FROM support_tickets t
     LEFT JOIN users u ON u.id = t.user_id
     LEFT JOIN orders o ON o.order_no = t.order_no AND o.user_id = t.user_id
     ORDER BY CASE WHEN t.status = \'open\' THEN 0 ELSE 1 END, t.updated_at DESC
     LIMIT 200'
)->fetchAll();
?>
<h1>Customer support tickets</h1>
<?php if ($errors): ?><div class="alert error" role="alert"><ul><?php foreach ($errors as $error): ?><li><?= e($error) ?></li><?php endforeach; ?></ul></div><?php endif; ?>
<?php if (!$tickets): ?>
  <p class="empty">No support tickets yet.</p>
<?php else: ?>
  <?php foreach ($tickets as $ticket): ?>
    <article class="panel msg <?= $ticket['status'] === 'open' ? 'unread' : '' ?>">
      <header>
        <h2><?= e($ticket['subject']) ?></h2>
        <p class="muted">
          <?= e(trim(($ticket['first_name'] ?? '') . ' ' . ($ticket['last_name'] ?? '')) ?: 'Customer account unavailable') ?>
          <?php if (!empty($ticket['customer_email'])): ?> · <a href="mailto:<?= e($ticket['customer_email']) ?>"><?= e($ticket['customer_email']) ?></a><?php endif; ?>
          · <?= e(date('j M Y, H:i', strtotime($ticket['created_at']))) ?>
        </p>
      </header>
      <?php if ($ticket['order_no']): ?>
        <p><b>Order:</b>
          <?php if ($ticket['linked_order_id']): ?>
            <a href="<?= e(url('admin/order.php?id=' . (int)$ticket['linked_order_id'])) ?>"><?= e($ticket['order_no']) ?></a>
          <?php else: ?>
            <?= e($ticket['order_no']) ?> <span class="muted">(not linked to this account)</span>
          <?php endif; ?>
        </p>
      <?php endif; ?>
      <p><?= nl2br(e($ticket['message'])) ?></p>
      <form method="post" class="form-grid">
        <?= csrf_field() ?>
        <input type="hidden" name="id" value="<?= (int)$ticket['id'] ?>">
        <label class="full">Administrator response
          <textarea name="admin_reply" rows="3" maxlength="5000"><?= e($ticket['admin_reply'] ?? '') ?></textarea>
        </label>
        <label>Status
          <select name="status">
            <?php foreach (['open' => 'Open', 'answered' => 'Answered', 'closed' => 'Closed'] as $value => $label): ?>
              <option value="<?= e($value) ?>" <?= $ticket['status'] === $value ? 'selected' : '' ?>><?= e($label) ?></option>
            <?php endforeach; ?>
          </select>
        </label>
        <div><button class="btn small" type="submit">Save response</button></div>
      </form>
    </article>
  <?php endforeach; ?>
<?php endif; ?>
<?php require __DIR__ . '/_bottom.php'; ?>

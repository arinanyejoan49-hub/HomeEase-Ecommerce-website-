<?php
$adminTitle = 'Messages';
require __DIR__ . '/_top.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $id = (int)($_POST['id'] ?? 0);
    $act = post('action', 10);
    if ($act === 'read') { q("UPDATE messages SET status = 'read' WHERE id = ?", [$id]); }
    if ($act === 'delete') { q('DELETE FROM messages WHERE id = ?', [$id]); flash('success', 'Message deleted.'); }
    redirect('admin/messages.php');
}
$msgs = q('SELECT * FROM messages ORDER BY id DESC LIMIT 200')->fetchAll();
?>
<h1>Customer messages</h1>
<?php if (!$msgs): ?><p class="empty">No messages yet.</p><?php endif; ?>
<?php foreach ($msgs as $m): ?>
  <article class="panel msg <?= $m['status'] === 'new' ? 'unread' : '' ?>">
    <header>
      <b><?= e($m['subject']) ?></b>
      <small class="muted"><?= e($m['name']) ?> · <a href="mailto:<?= e($m['email']) ?>"><?= e($m['email']) ?></a> · <?= e(date('j M Y, H:i', strtotime($m['created_at']))) ?></small>
    </header>
    <p><?= nl2br(e($m['message'])) ?></p>
    <a class="btn small" href="<?= e(url('admin/email-compose.php?reply_source=website&reply_id=' . (int)$m['id'])) ?>">Reply to customer</a>
    <form method="post" class="inline">
      <?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$m['id'] ?>">
      <?php if ($m['status'] === 'new'): ?><button class="btn small ghost" name="action" value="read" type="submit">Mark as read</button><?php endif; ?>
      <button class="btn small danger" name="action" value="delete" type="submit" onclick="return confirm('Delete this message?')">Delete</button>
    </form>
  </article>
<?php endforeach; ?>
<?php require __DIR__ . '/_bottom.php'; ?>

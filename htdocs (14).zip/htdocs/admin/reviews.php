<?php
$adminTitle = 'Customer reviews';
require __DIR__ . '/_top.php';

if (!table_exists('reviews')) {
    echo '<h1>Customer reviews</h1><p class="alert error">The reviews table does not exist yet.</p>';
    require __DIR__ . '/_bottom.php';
    exit;
}

$statuses = ['pending' => 'Pending', 'approved' => 'Approved', 'rejected' => 'Rejected'];
$filter = (string)($_GET['status'] ?? 'all');
if ($filter !== 'all' && !isset($statuses[$filter])) { $filter = 'all'; }
$search = trim((string)($_GET['q'] ?? ''));
$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = 20;

// Keep the current filter, search and page when going back after an action.
$returnQuery = static function () use ($filter, $search, $page): string {
    $params = [];
    if ($filter !== 'all') { $params['status'] = $filter; }
    if ($search !== '') { $params['q'] = $search; }
    if ($page > 1) { $params['page'] = $page; }
    return $params ? '?' . http_build_query($params) : '';
};

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $id = (int)($_POST['id'] ?? 0);
    $action = post('action', 12);
    $review = $id > 0
        ? q('SELECT r.id, r.user_id, r.rating, p.name AS product_name FROM reviews r JOIN products p ON p.id = r.product_id WHERE r.id = ?', [$id])->fetch()
        : false;

    if (!$review) {
        flash('error', 'Review not found. It may already have been deleted.');
    } elseif ($action === 'approve' || $action === 'reject') {
        $new = $action === 'approve' ? 'approved' : 'rejected';
        q('UPDATE reviews SET status = ? WHERE id = ?', [$new, $id]);
        if ($action === 'approve') {
            customer_notify((int)$review['user_id'], 'Your review is live', 'Thank you! Your review of ' . $review['product_name'] . ' has been approved.', 'customer/reviews.php');
            flash('success', 'Review approved and the customer was notified.');
        } else {
            customer_notify((int)$review['user_id'], 'Review not published', 'Your review of ' . $review['product_name'] . ' was not published because it did not meet our review guidelines.', 'customer/reviews.php');
            flash('success', 'Review rejected. It is now hidden from the website.');
        }
    } elseif ($action === 'delete') {
        q('DELETE FROM reviews WHERE id = ?', [$id]);
        flash('success', 'Review deleted permanently.');
    } else {
        flash('error', 'Unknown action.');
    }
    redirect('admin/reviews.php' . $returnQuery());
}

// Counts for the tabs
$counts = ['all' => 0, 'pending' => 0, 'approved' => 0, 'rejected' => 0];
foreach (q('SELECT status, COUNT(*) AS n FROM reviews GROUP BY status')->fetchAll() as $row) {
    $counts['all'] += (int)$row['n'];
    if (isset($counts[$row['status']])) { $counts[$row['status']] = (int)$row['n']; }
}

$where = [];
$params = [];
if ($filter !== 'all') { $where[] = 'r.status = ?'; $params[] = $filter; }
if ($search !== '') {
    $where[] = '(p.name LIKE ? OR r.title LIKE ? OR r.body LIKE ? OR u.first_name LIKE ? OR u.last_name LIKE ? OR u.email LIKE ?)';
    $like = '%' . $search . '%';
    array_push($params, $like, $like, $like, $like, $like, $like);
}
$whereSql = $where ? ' WHERE ' . implode(' AND ', $where) : '';
$from = ' FROM reviews r JOIN products p ON p.id = r.product_id JOIN users u ON u.id = r.user_id' . $whereSql;
$total = (int)q('SELECT COUNT(*)' . $from, $params)->fetchColumn();
$pages = max(1, (int)ceil($total / $perPage));
$page = min($page, $pages);
$rows = q('SELECT r.*, p.name AS product_name, p.slug, u.first_name, u.last_name, u.email' . $from
    . " ORDER BY CASE WHEN r.status = 'pending' THEN 0 ELSE 1 END, r.created_at DESC, r.id DESC LIMIT " . (int)$perPage . ' OFFSET ' . (int)(($page - 1) * $perPage), $params)->fetchAll();

$starText = static function (int $n): string {
    $n = max(0, min(5, $n));
    return '<span class="adm-stars" role="img" aria-label="' . $n . ' out of 5 stars">' . str_repeat('★', $n) . '<span class="off">' . str_repeat('★', 5 - $n) . '</span></span>';
};
$tabUrl = static function (string $status) use ($search): string {
    $params = [];
    if ($status !== 'all') { $params['status'] = $status; }
    if ($search !== '') { $params['q'] = $search; }
    return url('admin/reviews.php') . ($params ? '?' . http_build_query($params) : '');
};
?>
<h1>Customer reviews</h1>
<p class="muted">Reviews customers submit from their account arrive here. Approve or reject them, or delete them for good. Customers are notified when you approve or reject their review.</p>

<nav class="adm-tabs" aria-label="Filter reviews">
  <?php foreach (['all' => 'All'] + $statuses as $key => $label): ?>
    <a href="<?= e($tabUrl($key)) ?>" class="<?= $filter === $key ? 'on' : '' ?>"<?= $filter === $key ? ' aria-current="page"' : '' ?>><?= e($label) ?> <span><?= (int)$counts[$key] ?></span></a>
  <?php endforeach; ?>
</nav>

<form method="get" class="filters adm-search">
  <?php if ($filter !== 'all'): ?><input type="hidden" name="status" value="<?= e($filter) ?>"><?php endif; ?>
  <label>Search reviews
    <input type="search" name="q" value="<?= e($search) ?>" placeholder="Product, customer, email or review text">
  </label>
  <button class="btn small" type="submit">Search</button>
  <?php if ($search !== ''): ?><a class="btn small ghost" href="<?= e($tabUrl($filter)) ?>">Clear</a><?php endif; ?>
</form>

<?php if (!$rows): ?>
  <p class="empty"><?= $search !== '' || $filter !== 'all' ? 'No reviews match this filter.' : 'No reviews yet. New customer reviews will appear here and in your notifications.' ?></p>
<?php else: ?>
  <?php foreach ($rows as $r):
    $name = trim($r['first_name'] . ' ' . $r['last_name']);
    $status = in_array($r['status'], ['pending', 'approved', 'rejected'], true) ? $r['status'] : 'pending';
  ?>
    <article class="panel adm-review <?= e($status) ?>">
      <div class="adm-review-top">
        <div>
          <?= $starText((int)$r['rating']) ?>
          <span class="adm-pill <?= e($status) ?>"><?= e($statuses[$status]) ?></span>
        </div>
        <span class="muted"><?= e(date('j M Y, H:i', strtotime((string)$r['created_at']))) ?></span>
      </div>
      <h2><?= e(($r['title'] ?? '') !== '' ? $r['title'] : 'Untitled review') ?></h2>
      <p class="adm-review-body"><?= nl2br(e($r['body'])) ?></p>
      <p class="muted adm-review-meta">
        <b><?= e($name !== '' ? $name : 'Customer') ?></b> · <?= e($r['email']) ?> ·
        <a href="<?= e(url('product.php?slug=' . $r['slug'])) ?>" target="_blank" rel="noopener"><?= e($r['product_name']) ?> ↗</a>
        <?php if (!empty($r['order_id'])): ?> · <a href="<?= e(url('admin/order.php?id=' . (int)$r['order_id'])) ?>">View order</a><?php endif; ?>
      </p>
      <div class="adm-review-actions">
        <?php foreach (['approve' => ['Approve', ''], 'reject' => ['Reject', 'ghost']] as $act => [$label, $cls]):
          if (($act === 'approve' && $status === 'approved') || ($act === 'reject' && $status === 'rejected')) { continue; } ?>
          <form method="post">
            <?= csrf_field() ?>
            <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
            <input type="hidden" name="action" value="<?= e($act) ?>">
            <button class="btn small <?= e($cls) ?>" type="submit"><?= e($label) ?></button>
          </form>
        <?php endforeach; ?>
        <form method="post" onsubmit="return confirm('Delete this review permanently? This cannot be undone.');">
          <?= csrf_field() ?>
          <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
          <input type="hidden" name="action" value="delete">
          <button class="btn small danger" type="submit">Delete</button>
        </form>
      </div>
    </article>
  <?php endforeach; ?>

  <?php if ($pages > 1): ?>
    <nav class="rv-pager" aria-label="Review pages">
      <?php for ($i = 1; $i <= $pages; $i++):
        $pp = array_filter(['status' => $filter !== 'all' ? $filter : null, 'q' => $search !== '' ? $search : null, 'page' => $i > 1 ? $i : null]); ?>
        <?php if ($i === $page): ?><span class="is-current" aria-current="page"><?= $i ?></span>
        <?php else: ?><a href="<?= e(url('admin/reviews.php') . ($pp ? '?' . http_build_query($pp) : '')) ?>"><?= $i ?></a><?php endif; ?>
      <?php endfor; ?>
    </nav>
  <?php endif; ?>
<?php endif; ?>
<?php require __DIR__ . '/_bottom.php'; ?>

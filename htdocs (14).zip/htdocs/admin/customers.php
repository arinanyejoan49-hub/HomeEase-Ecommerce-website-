<?php
$adminTitle = 'Manage Customers';
require __DIR__ . '/_top.php';

if (!table_exists('users')) {
    ?>
    <h1>Manage Customers</h1>
    <div class="alert error" role="alert">
      Customer accounts are not set up in this database yet. In phpMyAdmin, select the <code>homeease</code> database and import <code>database.sql</code>, then reload this page.
    </div>
    <?php
    require __DIR__ . '/_bottom.php';
    exit;
}

$search = trim($_GET['q'] ?? '');
$status = $_GET['status'] ?? '';
$page   = max(1, (int)($_GET['page'] ?? 1));
$perPage = 25;
$offset  = ($page - 1) * $perPage;

$where = ['role = "customer"'];
$params = [];
if ($search !== '') {
    $where[] = '(first_name LIKE ? OR last_name LIKE ? OR email LIKE ? OR username LIKE ?)';
    $like = '%' . $search . '%';
    $params = array_merge($params, [$like, $like, $like, $like]);
}
if ($status !== '') {
    $where[] = 'status = ?';
    $params[] = $status;
}
$whereSQL = $where ? 'WHERE ' . implode(' AND ', $where) : '';

$total = (int)q('SELECT COUNT(*) FROM users ' . $whereSQL, $params)->fetchColumn();
$totalPages = max(1, ceil($total / $perPage));

$users = q('SELECT id, first_name, last_name, username, email, phone, role, status, created_at, updated_at FROM users ' . $whereSQL . ' ORDER BY created_at DESC LIMIT ? OFFSET ?', array_merge($params, [$perPage, $offset]))->fetchAll();
?>
<div class="panel-head">
  <div>
    <h1>Manage Customers</h1>
    <p>View, add, and update customer accounts.</p>
  </div>
  <a class="btn" href="<?= e(url('admin/customer-form.php')) ?>">Add customer</a>
</div>

<div class="section-head" style="margin-bottom:14px; display:flex; gap:10px; flex-wrap:wrap; align-items:center;">
  <form method="get" class="inline" style="display:flex; gap:8px; align-items:center;">
    <input type="text" name="q" value="<?= e($search) ?>" placeholder="Search by name, email or username">
    <select name="status">
      <option value="" <?= $status === '' ? 'selected' : '' ?>>All accounts</option>
      <option value="active" <?= $status === 'active' ? 'selected' : '' ?>>Active</option>
      <option value="suspended" <?= $status === 'suspended' ? 'selected' : '' ?>>Suspended</option>
    </select>
    <button class="btn small" type="submit">Search</button>
  </form>
  <span class="muted"><?= $total ?> customer<?= $total !== 1 ? 's' : '' ?></span>
</div>

<?php if (!$users): ?>
  <p class="empty">No customers found.</p>
<?php else: ?>
<div class="table-wrap">
<table class="data">
  <thead><tr><th>Name</th><th>Username</th><th>Email</th><th>Phone</th><th>Status</th><th>Joined</th><th>Actions</th></tr></thead>
  <tbody>
  <?php foreach ($users as $u): ?>
    <tr>
      <td><?= e($u['first_name'] . ' ' . $u['last_name']) ?></td>
      <td><?= e($u['username']) ?></td>
      <td><?= e($u['email']) ?></td>
      <td><?= e($u['phone']) ?></td>
      <td><span class="pill <?= $u['status'] ?>"><?= ucfirst($u['status']) ?></span></td>
      <td><?= e(date('j M Y', strtotime($u['created_at']))) ?></td>
      <td class="actions">
        <a class="btn small ghost" href="<?= e(url('admin/customer-details.php?id=' . (int)$u['id'])) ?>">Details</a>
        <a class="btn small" href="<?= e(url('admin/customer-form.php?id=' . (int)$u['id'])) ?>">Edit</a>
        <?php if ($u['status'] === 'active'): ?>
          <form method="post" action="<?= e(url('admin/toggle-customer.php')) ?>" class="inline" data-confirm="Suspend this account?">
            <?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$u['id'] ?>"><input type="hidden" name="status" value="suspended">
            <button class="btn small danger" type="submit" style="font-size:.78rem; padding:4px 8px;">Suspend</button>
          </form>
        <?php else: ?>
          <form method="post" action="<?= e(url('admin/toggle-customer.php')) ?>" class="inline" data-confirm="Reactivate this account?">
            <?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$u['id'] ?>"><input type="hidden" name="status" value="active">
            <button class="btn small ghost" type="submit" style="font-size:.78rem; padding:4px 8px;">Activate</button>
          </form>
        <?php endif; ?>
      </td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>
</div>

<?php if ($totalPages > 1): ?>
<div class="pagination" style="margin-top:14px; display:flex; gap:6px; justify-content:center; flex-wrap:wrap;">
  <?php for ($p = 1; $p <= $totalPages; $p++): ?>
    <a class="chip <?= $p === $page ? 'on' : '' ?>" href="?q=<?= e(urlencode($search)) ?>&status=<?= e($status) ?>&page=<?= $p ?>"><?= $p ?></a>
  <?php endfor; ?>
</div>
<?php endif; ?>

<?php endif; ?>

<?php require __DIR__ . '/_bottom.php'; ?>
<?php
$adminTitle = 'Profile';
require __DIR__ . '/_top.php';

$me = q('SELECT * FROM admins WHERE id = ?', [$_SESSION['admin_id']])->fetch();
?>
<h1>Profile</h1>
<p>Your administrator account details.</p>
<section class="panel narrow">
  <h2>Account</h2>
  <table class="data">
    <tbody>
      <tr><td style="width:35%"><b>Name</b></td><td><?= e($me['name'] ?? '-') ?></td></tr>
      <tr><td><b>Email</b></td><td><?= e($me['email'] ?? '-') ?></td></tr>
      <tr><td><b>Member since</b></td><td><?= e(date('j M Y', strtotime($me['created_at'] ?? ''))) ?></td></tr>
      <tr><td><b>Role</b></td><td><span class="pill">Administrator</span></td></tr>
    </tbody>
  </table>
  <p class="muted small">To change your password, go to <a href="<?= e(url('admin/account.php')) ?>">Account Settings</a>.</p>
</section>
<?php require __DIR__ . '/_bottom.php'; ?>

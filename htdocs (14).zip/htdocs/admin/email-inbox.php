<?php
$adminTitle = 'Email inbox';
require __DIR__ . '/_top.php';
require_once __DIR__ . '/../includes/email.php';

if (!table_exists('email_messages')) {
    flash('error', 'Install the email management migration before opening the mailbox.');
    redirect('admin/email.php');
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $id = filter_var($_POST['id'] ?? null, FILTER_VALIDATE_INT);
    $source = post('source', 12);
    $action = post('action', 16);
    if (!$id || !in_array($source, ['website', 'email'], true)
        || !in_array($action, ['read', 'unread', 'archive', 'restore', 'delete'], true)) {
        flash('error', 'That inbox action is not valid.');
        redirect('admin/email-inbox.php');
    }

    $table = $source === 'website' ? 'messages' : 'email_messages';
    $message = $source === 'website'
        ? q('SELECT id FROM messages WHERE id = ?', [$id])->fetch()
        : q("SELECT id FROM email_messages WHERE id = ? AND direction = 'incoming'", [$id])->fetch();
    if (!$message) {
        flash('error', 'Message not found.');
        redirect('admin/email-inbox.php');
    }
    if ($action === 'delete') {
        email_audit('delete', $source, $id);
        q("DELETE FROM $table WHERE id = ?", [$id]);
        flash('success', 'Message deleted.');
    } elseif ($source === 'website') {
        if ($action === 'read') { q("UPDATE messages SET status = 'read' WHERE id = ?", [$id]); }
        if ($action === 'unread') { q("UPDATE messages SET status = 'new' WHERE id = ?", [$id]); }
        if ($action === 'archive') { q("UPDATE messages SET status = 'archived' WHERE id = ?", [$id]); }
        if ($action === 'restore') { q("UPDATE messages SET status = 'read' WHERE id = ?", [$id]); }
        email_audit($action, $source, $id);
        flash('success', 'Message updated.');
    } else {
        if ($action === 'read') { q('UPDATE email_messages SET is_read = 1 WHERE id = ?', [$id]); }
        if ($action === 'unread') { q('UPDATE email_messages SET is_read = 0 WHERE id = ?', [$id]); }
        if ($action === 'archive') { q("UPDATE email_messages SET status = 'archived' WHERE id = ?", [$id]); }
        if ($action === 'restore') { q("UPDATE email_messages SET status = 'received' WHERE id = ?", [$id]); }
        email_audit($action, $source, $id);
        flash('success', 'Message updated.');
    }
    redirect('admin/email-inbox.php');
}

$search = is_string($_GET['q'] ?? null) ? trim(mb_substr($_GET['q'], 0, 120)) : '';
$status = is_string($_GET['status'] ?? null) ? $_GET['status'] : 'all';
$sourceFilter = is_string($_GET['source'] ?? null) ? $_GET['source'] : 'all';
$from = is_string($_GET['from'] ?? null) && preg_match('/^\d{4}-\d{2}-\d{2}$/', $_GET['from']) ? $_GET['from'] : '';
$to = is_string($_GET['to'] ?? null) && preg_match('/^\d{4}-\d{2}-\d{2}$/', $_GET['to']) ? $_GET['to'] : '';
$page = max(1, min(100000, (int)($_GET['page'] ?? 1)));
$perPage = 25;
$where = [];
$params = [];
if ($search !== '') {
    $where[] = '(sender_name LIKE ? OR sender_email LIKE ? OR subject LIKE ? OR body LIKE ?)';
    $like = '%' . $search . '%';
    array_push($params, $like, $like, $like, $like);
}
if (in_array($sourceFilter, ['website', 'email'], true)) {
    $where[] = 'source = ?';
    $params[] = $sourceFilter;
}
if ($status === 'unread') { $where[] = 'is_read = 0 AND is_archived = 0'; }
if ($status === 'read') { $where[] = 'is_read = 1 AND is_archived = 0'; }
if ($status === 'archived') { $where[] = 'is_archived = 1'; }
if ($from !== '') { $where[] = 'DATE(created_at) >= ?'; $params[] = $from; }
if ($to !== '') { $where[] = 'DATE(created_at) <= ?'; $params[] = $to; }
$whereSql = $where ? ' WHERE ' . implode(' AND ', $where) : '';
$union = "(
    SELECT 'website' AS source, id, name AS sender_name, email AS sender_email,
           '" . str_replace("'", "''", EMAIL_FROM_ADDRESS) . "' AS recipient_email,
           subject, message AS body, status, CASE WHEN status = 'new' THEN 0 ELSE 1 END AS is_read,
           CASE WHEN status = 'archived' THEN 1 ELSE 0 END AS is_archived,
           0 AS has_attachments, created_at
    FROM messages
    UNION ALL
    SELECT 'email' AS source, id, sender_name, sender_email, recipient_email,
           subject, body, status, is_read,
           CASE WHEN status = 'archived' THEN 1 ELSE 0 END AS is_archived,
           has_attachments, created_at
    FROM email_messages WHERE direction = 'incoming'
) inbox";
$total = (int)q('SELECT COUNT(*) FROM ' . $union . $whereSql, $params)->fetchColumn();
$lastPage = max(1, (int)ceil($total / $perPage));
$page = min($page, $lastPage);
$messages = q('SELECT * FROM ' . $union . $whereSql . ' ORDER BY created_at DESC LIMIT ' . $perPage . ' OFFSET ' . (($page - 1) * $perPage), $params)->fetchAll();
$baseQuery = $_GET;
unset($baseQuery['page']);
$pageUrl = static function (int $number) use ($baseQuery): string {
    return url('admin/email-inbox.php?' . http_build_query($baseQuery + ['page' => $number]));
};
?>
<div class="section-head"><div><h1>Inbox</h1><p class="muted"><?= $total ?> message<?= $total === 1 ? '' : 's' ?> found</p></div><a class="btn" href="<?= e(url('admin/email-compose.php')) ?>">Compose email</a></div>
<nav class="email-folders" aria-label="Email folders">
  <a href="<?= e(url('admin/email.php')) ?>">Overview</a>
  <a class="on" href="<?= e(url('admin/email-inbox.php')) ?>">Inbox</a>
  <a href="<?= e(url('admin/messages.php')) ?>">Website enquiries</a>
  <a href="<?= e(url('admin/email-sent.php')) ?>">Sent emails</a>
  <a href="<?= e(url('admin/email-settings.php')) ?>">Email settings</a>
</nav>
<form class="filters email-filters" method="get">
  <label>Search <input type="search" name="q" value="<?= e($search) ?>" placeholder="Sender, subject or message"></label>
  <label>Status <select name="status"><?php foreach (['all'=>'All messages','unread'=>'Unread','read'=>'Read','archived'=>'Archived'] as $value=>$label): ?><option value="<?= e($value) ?>" <?= $status === $value ? 'selected' : '' ?>><?= e($label) ?></option><?php endforeach; ?></select></label>
  <label>Source <select name="source"><?php foreach (['all'=>'All sources','website'=>'Website enquiry','email'=>'Mailbox email'] as $value=>$label): ?><option value="<?= e($value) ?>" <?= $sourceFilter === $value ? 'selected' : '' ?>><?= e($label) ?></option><?php endforeach; ?></select></label>
  <label>From <input type="date" name="from" value="<?= e($from) ?>"></label>
  <label>To <input type="date" name="to" value="<?= e($to) ?>"></label>
  <button class="btn small" type="submit">Filter</button>
  <a class="btn small ghost" href="<?= e(url('admin/email-inbox.php')) ?>">Reset</a>
</form>
<?php if (!$messages): ?>
  <p class="empty">No messages match these filters.</p>
<?php else: ?>
  <div class="email-list panel">
    <?php foreach ($messages as $message): $unread = !(bool)$message['is_read'] && !(bool)$message['is_archived']; ?>
      <article class="email-list-row <?= $unread ? 'unread' : '' ?>">
        <a class="email-list-main" href="<?= e(url('admin/email-view.php?source=' . $message['source'] . '&id=' . (int)$message['id'])) ?>">
          <strong><?= e($message['sender_name'] ?: $message['sender_email']) ?></strong>
          <span><?= e($message['subject']) ?></span>
          <small><?= e(mb_substr(trim((string)$message['body']), 0, 180)) ?></small>
        </a>
        <div class="email-row-meta">
          <span class="email-source"><?= $message['source'] === 'website' ? 'Website enquiry' : 'Mailbox' ?><?= $message['has_attachments'] ? ' · Attachment' : '' ?></span>
          <time datetime="<?= e(date(DATE_ATOM, strtotime($message['created_at']))) ?>"><?= e(date('j M Y, H:i', strtotime($message['created_at']))) ?></time>
          <div class="email-actions">
            <a class="btn small" href="<?= e(url('admin/email-compose.php?reply_source=' . $message['source'] . '&reply_id=' . (int)$message['id'])) ?>">Reply</a>
            <form method="post" class="email-actions">
              <?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$message['id'] ?>"><input type="hidden" name="source" value="<?= e($message['source']) ?>">
              <button class="btn small ghost" name="action" value="<?= $unread ? 'read' : 'unread' ?>" type="submit">Mark <?= $unread ? 'read' : 'unread' ?></button>
              <button class="btn small ghost" name="action" value="<?= $message['is_archived'] ? 'restore' : 'archive' ?>" type="submit"><?= $message['is_archived'] ? 'Restore' : 'Archive' ?></button>
              <button class="btn small danger" name="action" value="delete" type="submit" data-confirm="Delete this message permanently?">Delete</button>
            </form>
          </div>
        </div>
      </article>
    <?php endforeach; ?>
  </div>
  <?php if ($lastPage > 1): ?><nav class="email-pagination" aria-label="Inbox pages">
    <?php if ($page > 1): ?><a class="btn small ghost" href="<?= e($pageUrl($page - 1)) ?>">Previous</a><?php endif; ?>
    <span>Page <?= $page ?> of <?= $lastPage ?></span>
    <?php if ($page < $lastPage): ?><a class="btn small ghost" href="<?= e($pageUrl($page + 1)) ?>">Next</a><?php endif; ?>
  </nav><?php endif; ?>
<?php endif; ?>
<?php require __DIR__ . '/_bottom.php'; ?>

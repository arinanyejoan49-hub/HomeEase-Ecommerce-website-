<?php
$adminTitle = 'Return requests';
require __DIR__ . '/_top.php';

if (!table_exists('return_requests') || !column_exists('return_requests', 'refund_status')) {
    echo '<h1>Return requests</h1><p class="alert error">Install the return-refund status migration before managing requests.</p>';
    require __DIR__ . '/_bottom.php';
    exit;
}

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $id = (int)($_POST['id'] ?? 0);
    $status = post('status', 20);
    $refundStatus = post('refund_status', 24);
    $note = post('admin_note', 500);
    $reply = post('admin_reply', 2000);

    if ($id < 1) $errors[] = 'Select a valid return request.';
    if (!in_array($status, ['requested', 'approved', 'rejected', 'received'], true)) $errors[] = 'Select a valid return status.';
    if (!in_array($refundStatus, ['not_applicable', 'pending', 'awaiting_verification'], true)) $errors[] = 'Select a valid refund status.';
    if ($status !== 'approved' && $refundStatus !== 'not_applicable') {
        $errors[] = 'Refund follow-up can only be recorded for an approved return.';
    }
    $request = !$errors ? q(
        'SELECT rr.id, rr.user_id, rr.admin_reply, o.order_no
         FROM return_requests rr
         JOIN orders o ON o.id = rr.order_id
         WHERE rr.id = ?',
        [$id]
    )->fetch() : false;
    if (!$errors && !$request) {
        $errors[] = 'Return request not found.';
    }

    if (!$errors) {
        db()->beginTransaction();
        try {
            q('UPDATE return_requests SET status = ?, refund_status = ?, admin_note = ?, admin_reply = ? WHERE id = ?', [
                $status,
                $refundStatus,
                $note !== '' ? $note : null,
                $reply !== '' ? $reply : null,
                $id,
            ]);
            if ($reply !== '' && $reply !== (string)($request['admin_reply'] ?? '')) {
                q('INSERT INTO notifications (user_id, title, message, link) VALUES (?, ?, ?, ?)', [
                    (int)$request['user_id'],
                    'Return request reply',
                    'The administrator replied to your return request for order ' . $request['order_no'] . '.',
                    'customer/returns.php',
                ]);
            }
            db()->commit();
        } catch (Throwable $e) {
            if (db()->inTransaction()) {
                db()->rollBack();
            }
            throw $e;
        }
        flash('success', 'Return request updated. Refund status is not a payment confirmation.');
        redirect('admin/returns.php');
    }
}

$requests = q(
    'SELECT rr.*, o.order_no, o.customer_name, o.email, o.total, o.payment_status,
            u.first_name, u.last_name
     FROM return_requests rr
     JOIN orders o ON o.id = rr.order_id
     LEFT JOIN users u ON u.id = rr.user_id
     ORDER BY CASE WHEN rr.status = \'requested\' THEN 0 ELSE 1 END, rr.created_at DESC
     LIMIT 200'
)->fetchAll();
?>
<h1>Return requests</h1>
<?php if ($errors): ?><div class="alert error" role="alert"><ul><?php foreach ($errors as $error): ?><li><?= e($error) ?></li><?php endforeach; ?></ul></div><?php endif; ?>
<?php if (!$requests): ?>
  <p class="empty">No return requests yet.</p>
<?php else: ?>
  <?php foreach ($requests as $request): ?>
    <article class="panel msg">
      <h2>Order <?= e($request['order_no']) ?></h2>
      <p class="muted">
        <?= e(trim(($request['first_name'] ?? '') . ' ' . ($request['last_name'] ?? '')) ?: $request['customer_name']) ?>
        · <?= e($request['email']) ?> · <?= e(date('j M Y, H:i', strtotime($request['created_at']))) ?>
      </p>
      <p><b>Order total:</b> <?= e(money($request['total'])) ?> · <b>Payment:</b> <?= e(payment_status_label($request['payment_status'])) ?></p>
      <p><b>Customer reason:</b><br><?= nl2br(e($request['reason'])) ?></p>
      <form method="post" class="form-grid">
        <?= csrf_field() ?>
        <input type="hidden" name="id" value="<?= (int)$request['id'] ?>">
        <label>Return status
          <select name="status">
            <?php foreach (['requested' => 'Requested', 'approved' => 'Approved', 'rejected' => 'Rejected', 'received' => 'Item received'] as $value => $label): ?>
              <option value="<?= e($value) ?>" <?= $request['status'] === $value ? 'selected' : '' ?>><?= e($label) ?></option>
            <?php endforeach; ?>
          </select>
        </label>
        <label>Refund follow-up
          <select name="refund_status">
            <?php foreach (['not_applicable' => 'Not applicable', 'pending' => 'Pending', 'awaiting_verification' => 'Awaiting transaction verification'] as $value => $label): ?>
              <option value="<?= e($value) ?>" <?= $request['refund_status'] === $value ? 'selected' : '' ?>><?= e($label) ?></option>
            <?php endforeach; ?>
          </select>
        </label>
        <label class="full">Administrator note
          <textarea name="admin_note" rows="2" maxlength="500"><?= e($request['admin_note'] ?? '') ?></textarea>
        </label>
        <label class="full">Reply to customer
          <textarea name="admin_reply" rows="3" maxlength="2000"><?= e($request['admin_reply'] ?? '') ?></textarea>
        </label>
        <div><button class="btn small" type="submit">Save decision and reply</button></div>
      </form>
    </article>
  <?php endforeach; ?>
<?php endif; ?>
<?php require __DIR__ . '/_bottom.php'; ?>

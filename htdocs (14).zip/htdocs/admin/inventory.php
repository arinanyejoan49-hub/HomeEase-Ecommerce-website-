<?php
$adminTitle = 'Inventory';
require __DIR__ . '/_top.php';

if (!table_exists('inventory_adjustments')) {
    q("CREATE TABLE IF NOT EXISTS inventory_adjustments (
      id INT AUTO_INCREMENT PRIMARY KEY,
      product_id INT NOT NULL,
      admin_id INT NULL,
      change_qty INT NOT NULL,
      reason VARCHAR(255) NOT NULL,
      created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $pid = (int)($_POST['product_id'] ?? 0);
    $change = (int)($_POST['change'] ?? 0);
    $reason = post('reason', 255);
    $p = q('SELECT id, stock FROM products WHERE id = ?', [$pid])->fetch();
    if (!$p) {
        flash('error', 'Product not found.');
    } elseif ($change === 0) {
        flash('error', 'Change quantity cannot be zero.');
    } elseif ($reason === '') {
        flash('error', 'Reason is required.');
    } else {
        $newStock = (int)$p['stock'] + $change;
        if ($newStock < 0) {
            flash('error', 'Stock cannot go below zero.');
        } else {
            q('UPDATE products SET stock = ? WHERE id = ?', [$newStock, $pid]);
            if (table_exists('inventory_adjustments')) {
                q('INSERT INTO inventory_adjustments (product_id, admin_id, change_qty, reason) VALUES (?,?,?,?)', [$pid, $_SESSION['admin_id'] ?? null, $change, $reason]);
            }
            flash('success', 'Stock updated to ' . $newStock . '.');
        }
    }
    redirect('admin/inventory.php');
}

$products = q('SELECT p.id, p.name, p.stock, c.name AS cat FROM products p LEFT JOIN categories c ON c.id = p.category_id ORDER BY p.stock ASC, p.name')->fetchAll();
$adjustments = [];
if (table_exists('inventory_adjustments')) {
    $adjustments = q('SELECT ia.*, p.name FROM inventory_adjustments ia JOIN products p ON p.id = ia.product_id ORDER BY ia.id DESC LIMIT 50')->fetchAll();
}
?>
<h1>Inventory management</h1>
<p>Adjust stock levels. All changes are recorded.</p>

<div class="panel" style="margin-bottom:18px;">
  <h2>Adjust stock</h2>
  <form method="post" class="form-grid">
    <?= csrf_field() ?>
    <label>Product
      <select name="product_id" required>
        <?php foreach ($products as $p): ?>
          <option value="<?= (int)$p['id'] ?>"><?= e($p['name']) ?> (current: <?= (int)$p['stock'] ?>)</option>
        <?php endforeach; ?>
      </select>
    </label>
    <label>Change (use negative to reduce) <input type="number" name="change" required value="0"></label>
    <label class="full">Reason <input type="text" name="reason" required maxlength="255" placeholder="e.g. Restock delivery"></label>
    <div class="full"><button class="btn" type="submit">Apply adjustment</button></div>
  </form>
</div>

<h2>Current stock</h2>
<?php if (!$products): ?><p class="empty">No products.</p><?php else: ?>
<div class="table-wrap">
<table class="data">
  <thead><tr><th>Product</th><th>Category</th><th>Stock</th><th>Status</th></tr></thead>
  <tbody>
  <?php foreach ($products as $p): ?>
    <tr>
      <td><?= e($p['name']) ?></td>
      <td><?= e($p['cat']) ?></td>
      <td><b class="<?= $p['stock'] < 1 ? 'bad' : ($p['stock'] <= 5 ? 'warn' : '') ?>"><?= (int)$p['stock'] ?></b></td>
      <td><?php if ($p['stock'] < 1): ?><span class="pill cancelled">Out of stock</span><?php elseif ($p['stock'] <= 5): ?><span class="pill pending">Low</span><?php else: ?><span class="pill delivered">OK</span><?php endif; ?></td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>
</div>
<?php endif; ?>

<h2 style="margin-top:24px;">Recent adjustments</h2>
<?php if (!$adjustments): ?><p class="muted">No adjustments recorded yet.</p><?php else: ?>
<div class="table-wrap">
<table class="data">
  <thead><tr><th>Date</th><th>Product</th><th>Change</th><th>Reason</th></tr></thead>
  <tbody>
  <?php foreach ($adjustments as $a): ?>
    <tr>
      <td><?= e(date('j M Y, H:i', strtotime($a['created_at']))) ?></td>
      <td><?= e($a['name']) ?></td>
      <td><?= $a['change_qty'] > 0 ? '+' : '' ?><?= (int)$a['change_qty'] ?></td>
      <td><?= e($a['reason']) ?></td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>
</div>
<?php endif; ?>

<?php require __DIR__ . '/_bottom.php'; ?>
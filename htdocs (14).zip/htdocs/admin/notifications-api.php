<?php
// JSON endpoint behind the admin notification bell (polled every ~20s by assets/js/admin-notifications.js).
require __DIR__ . '/../includes/bootstrap.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

function notif_json(array $data, int $status = 200): void
{
    http_response_code($status);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

if (!is_admin()) {
    notif_json(['error' => 'unauthorised'], 401);
}
require_admin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $sent = $_POST['csrf'] ?? '';
    $known = $_SESSION['csrf'] ?? '';
    if (!is_string($sent) || $known === '' || !hash_equals($known, $sent)) {
        notif_json(['error' => 'bad_csrf'], 400);
    }
    if (admin_notif_ready()) {
        $action = post('action', 12);
        if ($action === 'read') {
            q('UPDATE admin_notifications SET is_read = 1 WHERE id = ?', [(int)($_POST['id'] ?? 0)]);
        } elseif ($action === 'readall') {
            q('UPDATE admin_notifications SET is_read = 1 WHERE is_read = 0');
        }
    }
    notif_json(['ok' => true, 'unread' => admin_notif_unread_count()]);
}

// GET: don't hold the session lock while polling.
if (session_status() === PHP_SESSION_ACTIVE) {
    session_write_close();
}

$since = max(0, (int)($_GET['since'] ?? 0));
$items = array_map('admin_notif_item', admin_notif_recent(8));

$fresh = [];
$latest = 0;
if (admin_notif_ready()) {
    $latest = (int)q('SELECT COALESCE(MAX(id), 0) FROM admin_notifications')->fetchColumn();
    if ($latest > $since) {
        $rows = q('SELECT * FROM admin_notifications WHERE id > ? AND is_read = 0 ORDER BY id ASC LIMIT 5', [$since])->fetchAll();
        $fresh = array_map('admin_notif_item', $rows);
    }
}

notif_json([
    'unread' => admin_notif_unread_count(),
    'latest' => $latest,
    'items'  => $items,
    'fresh'  => $fresh,
]);

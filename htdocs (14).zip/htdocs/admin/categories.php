<?php
$adminTitle = 'Categories';
require __DIR__ . '/_top.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $id = (int)($_POST['id'] ?? 0);
    $act = post('action', 12);
    if ($act === 'add') {
        $name = post('name', 80);
        if ($name === '') { flash('error', 'Category name is required.'); }
        elseif (!q('SELECT 1 FROM categories WHERE name = ?', [$name])->fetch()) {
            $slug = slugify($name);
            $base = $slug;
            $suffix = 2;
            while (q('SELECT 1 FROM categories WHERE slug = ?', [$slug])->fetch()) {
                $slug = $base . '-' . $suffix++;
            }
            q('INSERT INTO categories (name, slug, sort_order) VALUES (?, ?, 0)', [$name, $slug]);
            flash('success', 'Category added.');
        } else {
            flash('error', 'That category already exists.');
        }
    } elseif ($act === 'delete') {
        $used = q('SELECT 1 FROM products WHERE category_id = ? LIMIT 1', [$id])->fetch();
        if ($used) { flash('error', 'Cannot delete a category that has products.'); }
        else { q('DELETE FROM categories WHERE id = ?', [$id]); flash('success', 'Category deleted.'); }
    }
    redirect('admin/categories.php');
}
$cats = q('SELECT c.*, COUNT(p.id) AS product_count FROM categories c
           LEFT JOIN products p ON p.category_id = c.id
           GROUP BY c.id ORDER BY c.sort_order, c.name')->fetchAll();
?>
<h1>Categories</h1>
<p>Organise your appliances into groups. Each product belongs to one category.</p>
<form method="post" class="panel narrow" style="max-width:420px;">
  <?= csrf_field() ?>
  <h2>Add category</h2>
  <label>Name <input name="name" required maxlength="80" placeholder="e.g. Kitchen Appliances"></label>
  <input type="hidden" name="action" value="add">
  <button class="btn" type="submit">Add category</button>
</form>
<?php if ($cats): ?>
<div class="table-wrap">
<table class="data">
  <thead><tr><th>Category</th><th>Products</th><th>Actions</th></tr></thead>
  <tbody>
  <?php foreach ($cats as $c): ?>
    <tr>
      <td><?= e($c['name']) ?></td>
      <td class="<?= (int)$c['product_count'] ? '' : 'muted' ?>"><?= (int)$c['product_count'] ?></td>
      <td class="actions">
        <form method="post" class="inline" data-confirm="Delete this category? Products using it will block deletion.">
          <?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$c['id'] ?>"><input type="hidden" name="action" value="delete"><button class="btn small danger" type="submit">Delete</button>
        </form>
      </td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>
</div>
<?php else: ?>
<p class="empty">No categories yet.</p>
<?php endif; ?>
<?php require __DIR__ . '/_bottom.php'; ?>

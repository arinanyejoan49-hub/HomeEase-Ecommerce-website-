<?php
$adminTitle = 'Payments';
require __DIR__ . '/_top.php';

$method = is_string($_GET['method'] ?? '') ? ($_GET['method'] ?? '') : '';
$status = is_string($_GET['status'] ?? '') ? ($_GET['status'] ?? '') : '';
$sql = 'SELECT * FROM orders';
$params = [];
$conds = [];
if ($method !== '') { $conds[] = 'payment_method = ?'; $params[] = $method; }
if ($status !== '') { $conds[] = 'payment_status = ?'; $params[] = $status; }
if ($conds) { $sql .= ' WHERE ' . implode(' AND ', $conds); }
$orders = q($sql . ' ORDER BY id DESC LIMIT 200', $params)->fetchAll();

$totals = q("SELECT payment_method, payment_status, COUNT(*) AS c, COALESCE(SUM(total),0) AS s FROM orders GROUP BY payment_method, payment_status")->fetchAll();
?>
<h1>Payment management</h1>
<p>Overview of payment methods and statuses. Simulated payments are clearly labelled.</p>

<div class="panel" style="margin-bottom:18px;">
  <h2>Summary</h2>
  <div class="table-wrap">
  <table class="data">
    <thead><tr><th>Method</th><th>Status</th><th>Orders</th><th>Amount</th></tr></thead>
    <tbody>
    <?php foreach ($totals as $t): ?>
      <tr>
        <td><?= e($t['payment_method']) ?></td>
        <td><?= e(payment_status_label($t['payment_status'])) ?></td>
        <td><?= (int)$t['c'] ?></td>
        <td><?= e(money($t['s'])) ?></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
  </div>
</div>

<p class="chips">
  <a class="chip <?= $method === '' ? 'on' : '' ?>" href="<?= e(url('admin/payments.php' . ($status ? '?status=' . urlencode($status) : ''))) ?>">All methods</a>
  <?php foreach (['cod','momo','card'] as $m): ?>
    <a class="chip <?= $method === $m ? 'on' : '' ?>" href="<?= e(url('admin/payments.php?method=' . $m . ($status ? '&status=' . urlencode($status) : ''))) ?>"><?= e($m) ?></a>
  <?php endforeach; ?>
</p>

<?php if (!$orders): ?><p class="empty">No payments found.</p><?php else: ?>
<div class="table-wrap">
<table class="data">
  <thead><tr><th>Order</th><th>Date</th><th>Customer</th><th>Method</th><th>Status</th><th>Ref</th><th>Total</th></tr></thead>
  <tbody>
  <?php foreach ($orders as $o): ?>
    <tr>
      <td><a href="<?= e(url('admin/order.php?id=' . $o['id'])) ?>"><?= e($o['order_no']) ?></a></td>
      <td><?= e(date('j M, H:i', strtotime($o['created_at']))) ?></td>
      <td><?= e($o['customer_name']) ?></td>
      <td><?= e($o['payment_method']) ?></td>
      <td><?= e(payment_status_label($o['payment_status'])) ?></td>
      <td><?= e(payment_reference_label($o['payment_ref'] ?: '-')) ?><?= $o['card_last4'] ? ' · ' . e($o['card_last4']) : '' ?></td>
      <td><?= e(money($o['total'])) ?></td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>
</div>
<?php endif; ?>

<?php require __DIR__ . '/_bottom.php'; ?>
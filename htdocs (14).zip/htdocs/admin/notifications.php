<?php
$adminTitle = 'Notifications';
require __DIR__ . '/_top.php';

$types = admin_notif_types();
$filter = is_string($_GET['filter'] ?? '') ? (string)($_GET['filter'] ?? '') : '';
if ($filter !== 'unread' && !isset($types[$filter])) {
    $filter = '';
}
$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = 20;

// Open a notification: mark it read, then jump to the page it points at.
if (isset($_GET['go'])) {
    $id = (int)$_GET['go'];
    $row = admin_notif_ready() ? q('SELECT link FROM admin_notifications WHERE id = ?', [$id])->fetch() : false;
    if ($row) {
        q('UPDATE admin_notifications SET is_read = 1 WHERE id = ?', [$id]);
        redirect($row['link'] ?: 'admin/notifications.php');
    }
    redirect('admin/notifications.php');
}

$back = 'admin/notifications.php' . ($filter !== '' || $page > 1
    ? '?' . http_build_query(array_filter(['filter' => $filter, 'page' => $page > 1 ? $page : null]))
    : '');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && admin_notif_ready()) {
    csrf_verify();
    $act = post('action', 12);
    $id = (int)($_POST['id'] ?? 0);
    if ($act === 'read') {
        q('UPDATE admin_notifications SET is_read = 1 WHERE id = ?', [$id]);
    } elseif ($act === 'readall') {
        q('UPDATE admin_notifications SET is_read = 1 WHERE is_read = 0');
        flash('success', 'All notifications marked as read.');
    } elseif ($act === 'delete') {
        q('DELETE FROM admin_notifications WHERE id = ?', [$id]);
    } elseif ($act === 'clearread') {
        q('DELETE FROM admin_notifications WHERE is_read = 1');
        flash('success', 'Read notifications cleared.');
    }
    redirect($back);
}

$where = '1=1';
$params = [];
if ($filter === 'unread') {
    $where = 'is_read = 0';
} elseif ($filter !== '') {
    $where = 'type = ?';
    $params[] = $filter;
}

$total = 0;
$rows = [];
if (admin_notif_ready()) {
    $total = (int)q('SELECT COUNT(*) FROM admin_notifications WHERE ' . $where, $params)->fetchColumn();
    $pages = max(1, (int)ceil($total / $perPage));
    $page = min($page, $pages);
    $rows = q('SELECT * FROM admin_notifications WHERE ' . $where . ' ORDER BY id DESC LIMIT ' . $perPage . ' OFFSET ' . (($page - 1) * $perPage), $params)->fetchAll();
}
$pages = max(1, (int)ceil($total / $perPage));
$unreadAll = admin_notif_unread_count();

function notif_filter_url(string $f, int $p = 1): string
{
    $qs = array_filter(['filter' => $f, 'page' => $p > 1 ? $p : null]);
    return url('admin/notifications.php' . ($qs ? '?' . http_build_query($qs) : ''));
}
?>
<h1>Notifications</h1>
<p class="muted"><?= $unreadAll ?> unread. New orders, payments, enquiries, support tickets, returns, sign-ups and low-stock alerts appear here.</p>

<div class="notif-toolbar">
  <div class="notif-filters">
    <a class="btn small <?= $filter === '' ? '' : 'ghost' ?>" href="<?= e(notif_filter_url('')) ?>">All</a>
    <a class="btn small <?= $filter === 'unread' ? '' : 'ghost' ?>" href="<?= e(notif_filter_url('unread')) ?>">Unread<?= $unreadAll ? ' (' . $unreadAll . ')' : '' ?></a>
    <?php foreach ($types as $key => $meta): ?>
      <a class="btn small <?= $filter === $key ? '' : 'ghost' ?>" href="<?= e(notif_filter_url($key)) ?>"><?= e($meta['label']) ?></a>
    <?php endforeach; ?>
  </div>
  <form method="post" class="inline notif-bulk">
    <?= csrf_field() ?>
    <button class="btn small ghost" name="action" value="readall" type="submit">Mark all as read</button>
    <button class="btn small danger" name="action" value="clearread" type="submit" onclick="return confirm('Delete all read notifications?')">Clear read</button>
  </form>
</div>

<?php if (!$rows): ?>
  <p class="empty">No notifications<?= $filter !== '' ? ' in this view' : ' yet' ?>.</p>
<?php else: ?>
  <div class="panel notif-history">
  <?php foreach ($rows as $n):
      $meta = $types[$n['type']] ?? $types['order']; ?>
    <article class="msg notif-row <?= $n['is_read'] ? '' : 'unread' ?>">
      <span class="notif-ico" style="--notif-color: <?= e($meta['color']) ?>"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" aria-hidden="true"><?= $meta['icon'] ?></svg></span>
      <div class="notif-body">
        <header>
          <b><?= e($n['title']) ?></b>
          <small class="muted"><?= e($meta['label']) ?> · <?= e(date('j M Y, H:i', strtotime($n['created_at']))) ?> (<?= e(admin_notif_time_ago($n['created_at'])) ?>)</small>
        </header>
        <p><?= e($n['message']) ?></p>
        <div class="notif-actions">
          <?php if ($n['link']): ?><a class="btn small" href="<?= e(url('admin/notifications.php?go=' . (int)$n['id'])) ?>">View</a><?php endif; ?>
          <form method="post" class="inline">
            <?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$n['id'] ?>">
            <?php if (!$n['is_read']): ?><button class="btn small ghost" name="action" value="read" type="submit">Mark as read</button><?php endif; ?>
            <button class="btn small danger" name="action" value="delete" type="submit">Delete</button>
          </form>
        </div>
      </div>
    </article>
  <?php endforeach; ?>
  </div>

  <?php if ($pages > 1): ?>
    <nav class="notif-pager" aria-label="Pagination">
      <?php if ($page > 1): ?><a class="btn small ghost" href="<?= e(notif_filter_url($filter, $page - 1)) ?>">&larr; Newer</a><?php endif; ?>
      <span class="muted">Page <?= $page ?> of <?= $pages ?></span>
      <?php if ($page < $pages): ?><a class="btn small ghost" href="<?= e(notif_filter_url($filter, $page + 1)) ?>">Older &rarr;</a><?php endif; ?>
    </nav>
  <?php endif; ?>
<?php endif; ?>
<?php require __DIR__ . '/_bottom.php'; ?>

<?php
require __DIR__ . '/includes/bootstrap.php';

header('Cache-Control: no-store');
header('X-Robots-Tag: noindex, nofollow');

$no = is_string($_GET['no'] ?? '') ? trim((string)($_GET['no'] ?? '')) : '';
$token = is_string($_GET['t'] ?? '') ? (string)($_GET['t'] ?? '') : '';
$o = $no !== '' ? q('SELECT * FROM orders WHERE order_no = ?', [$no])->fetch() : false;

// Who may open a receipt: an admin, the customer who owns the order, someone holding the signed link from
// the receipt email, or the browser session that has just placed the order.
$allowed = false;
if ($o) {
    if (is_admin()) {
        $allowed = true;
    } elseif (is_customer() && !empty($o['user_id']) && (int)$o['user_id'] === (int)($_SESSION['customer_id'] ?? 0)) {
        $allowed = true;
    } elseif ($token !== '' && hash_equals(receipt_token($o), $token)) {
        $allowed = true;
    } elseif (($_SESSION['last_order'] ?? '') === $o['order_no']) {
        $allowed = true;
    }
}

$message = '';
$rec = null;
$items = [];
if (!$allowed) {
    http_response_code(404);
    $message = 'We could not find that receipt. Please use the link in your receipt email, or open it from your account.';
} elseif (!receipt_is_paid($o)) {
    $message = 'A receipt is issued as soon as payment for this order is received.';
} else {
    $rec = receipt_issue($o);
    if (!$rec) {
        $message = 'This receipt is not available right now. Please try again shortly.';
    } else {
        $items = q('SELECT * FROM order_items WHERE order_id = ? ORDER BY id', [(int)$o['id']])->fetchAll();
    }
}
$backUrl = is_admin() ? url('admin/order.php?id=' . (int)($o['id'] ?? 0)) : (is_customer() ? url('customer/orders.php') : url('track.php'));
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow">
<title><?= $rec ? e(receipt_number($o)) . ' | ' : '' ?>Receipt | <?= e(SITE_NAME) ?></title>
<style>
  body { margin: 0; background: #FFF9F3; font-family: Arial, Helvetica, sans-serif; color: #333333; }
  .receipt-wrap { max-width: 680px; margin: 0 auto; padding: 24px 16px 48px; }
  .receipt-bar { display: flex; flex-wrap: wrap; gap: 8px; justify-content: space-between; align-items: center; margin-bottom: 16px; }
  .receipt-bar a, .receipt-bar button {
    font: inherit; font-size: 14px; font-weight: 700; padding: 9px 16px; border-radius: 8px; cursor: pointer; text-decoration: none;
    border: 1px solid #FF7900; background: #FF7900; color: #111111;
  }
  .receipt-bar a.ghost { background: #FFFFFF; color: #E65C00; }
  .receipt-msg { background: #FFFFFF; border: 1px solid #E5E5E5; border-radius: 12px; padding: 28px; text-align: center; }
  .receipt-msg h1 { margin: 0 0 8px; color: #111111; font-size: 1.3rem; }
  @media print {
    body { background: #FFFFFF; }
    .receipt-bar { display: none; }
    .receipt-wrap { padding: 0; max-width: none; }
    table { border: 0 !important; }
  }
</style>
</head>
<body>
<div class="receipt-wrap">
  <div class="receipt-bar">
    <a class="ghost" href="<?= e($backUrl) ?>">&larr; Back</a>
    <?php if ($rec): ?><button type="button" onclick="window.print()">Print / Save as PDF</button><?php endif; ?>
  </div>
  <?php if ($rec): ?>
    <?= receipt_html($o, $items, (string)$rec['issued_at']) ?>
  <?php else: ?>
    <div class="receipt-msg">
      <h1>Receipt</h1>
      <p><?= e($message) ?></p>
    </div>
  <?php endif; ?>
</div>
</body>
</html>

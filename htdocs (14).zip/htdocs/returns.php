<?php
require __DIR__ . '/includes/bootstrap.php';
$title = 'Returns & warranty';
require __DIR__ . '/includes/header.php';
?>
<h1>Returns, refunds &amp; warranty</h1>
<h2>Faulty or wrong items</h2>
<p>If an item arrives damaged, faulty or is not what you ordered, tell us within <strong>7 days of delivery</strong>. We will repair, replace or refund it, and we cover the return delivery cost.</p>
<h2>Changed your mind</h2>
<p>Unused items in original packaging with all accessories can be returned within <strong>7 days</strong> of delivery for a refund or exchange. The original delivery fee and return transport are not refunded. Items that were used, installed or damaged by the customer cannot be returned.</p>
<h2>Warranty</h2>
<p>Each product page shows its warranty period (12 to 24 months). The warranty covers manufacturing defects under normal use. It does not cover damage from power surges, water, misuse, unauthorised repair or normal wear. Keep your order number as proof of purchase.</p>
<h2>How to start a return or claim</h2>
<ol class="steps">
  <li>Send your order number and a short description, ideally with a photo, through the <a href="<?= e(url('contact.php')) ?>">contact form</a> or WhatsApp.</li>
  <li>We reply within one working day with the next step.</li>
  <li>We collect or you drop off the item. Refunds are made to the original payment method (mobile money or cash) within 7 working days of us receiving the item.</li>
</ol>
<p class="muted">This policy is meant to be read together with our <a href="<?= e(url('terms.php')) ?>">terms and conditions</a> and your rights under Ugandan consumer and sale of goods law.</p>
<?php require __DIR__ . '/includes/footer.php'; ?>

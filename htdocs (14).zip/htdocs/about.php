<?php
require __DIR__ . '/includes/bootstrap.php';
$title = 'About us';
require __DIR__ . '/includes/header.php';
?>
<h1>About <?= e(SITE_NAME) ?></h1>
<p class="lead"><?= e(SITE_NAME) ?> helps students and young families in Uganda set up a comfortable home without overspending.</p>
<p>Moving into a hostel or your first rented room means buying a kettle, a cooker, a fan, a fridge, and more, often on a tight budget. Shops can be far, prices unclear and quality uncertain. We bring genuine, warranty-backed appliances together in one place, with honest prices, student discounts, mobile money and cash on delivery.</p>
<h2>Our promise</h2>
<ul class="ticks">
  <li><svg width="16" height="16" viewBox="0 0 24 24" aria-hidden="true" style="vertical-align:-1px;"><path d="M9 16.17l-1.41-1.41L5 14.17l6 6 14-14 1.41 1.41L9 19l-7-7z"/></svg> Genuine products with a stated warranty</li>
  <li><svg width="16" height="16" viewBox="0 0 24 24" aria-hidden="true" style="vertical-align:-1px;"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 17.93c-3.95-.49-7-3.85-7-7.93 0-.62.08-1.21.21-1.79L9 15v1c0 1.1.9 2 2 2v1c0 1.1.9 2 2 2s2-.9 2-2v-1c0-1.1.9-2 2-2v-1c0-1.1.9-2 2-2v-6.54l.21.79c.13.58.21 1.17.21 1.79 0 4.08-3.05 7.44-7 7.93z"/></svg> Affordable prices and a 10% student code</li>
  <li><svg width="16" height="16" viewBox="0 0 24 24" aria-hidden="true" style="vertical-align:-1px;"><path d="M21 10V5c0-1.1-.9-2-2-2H5c-1.1 0-2 .9-2 2v14l7-3.73 7 3.73V10c0-1.1.9-2 2-2z"/></svg> Fast, tracked delivery in Masaka and beyond</li>
  <li><svg width="16" height="16" viewBox="0 0 24 24" aria-hidden="true" style="vertical-align:-1px;"><path d="M16 11c-1.1 0-1.99.9-1.99 2S14.9 15 16 15s2-.9 2-2-.9-2-2-2zM12 7c-4.42 0-8 3.58-8 8s3.58 8 8 8 8-3.58 8-8-3.58-8-8-8zm0 2c3.31 0 6 2.69 6 6s-2.69 6-6 6-6-2.69-6-6 2.69-6 6-6zm0 12c-3.31 0-6-2.69-6-6s2.69-6 6-6 6 2.69 6 6-2.69 6-6 6z"/></svg> Real people on the phone and WhatsApp</li>
</ul>
<p><a class="btn" href="<?= e(url('contact.php')) ?>">Get in touch</a></p>
<?php require __DIR__ . '/includes/footer.php'; ?>

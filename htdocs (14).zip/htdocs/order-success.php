<?php
require __DIR__ . '/includes/bootstrap.php';

$no = is_string($_GET['no'] ?? '') ? ($_GET['no'] ?? '') : '';
// Only the browser session that placed the order may view this page; others use Track order.
if ($no === '' || ($_SESSION['last_order'] ?? '') !== $no) {
    redirect('track.php');
}
$o = q('SELECT * FROM orders WHERE order_no = ?', [$no])->fetch();
if (!$o) { redirect('track.php'); }
$items = q('SELECT oi.*, p.slug, p.image FROM order_items oi LEFT JOIN products p ON p.id = oi.product_id WHERE oi.order_id = ? ORDER BY oi.id', [$o['id']])->fetchAll();
$zone = ZONES[$o['zone']] ?? ['Delivery', 0, ''];
$title = 'Order confirmed';
require __DIR__ . '/includes/header.php';
?>
<?php $awaiting = $o['payment_status'] === 'awaiting payment'; $payFailed = in_array($o['payment_status'], ['payment failed', 'payment expired'], true); ?>
<section class="confirm">
  <p class="big-ico" id="pay-ico"><?= $awaiting ? '📱' : ($payFailed ? '⚠️' : '✅') ?></p>
  <h1 id="pay-heading"><?php if ($awaiting): ?>Approve the payment on your phone<?php elseif ($payFailed): ?>Your payment was not completed<?php else: ?>Thank you, <?= e(explode(' ', $o['customer_name'])[0]) ?>! Your order is in.<?php endif; ?></h1>
  <div class="alert" id="pay-wait" role="status" <?= $awaiting ? '' : 'hidden' ?>>We sent a mobile money prompt to the number you entered. Enter your PIN to pay <?= e(money($o['total'])) ?>. This page updates automatically.</div>
  <div class="alert error" id="pay-failed" role="alert" <?= $payFailed ? '' : 'hidden' ?>>The payment was declined, cancelled or timed out, and no money was taken. Your items were returned to stock; please <a href="<?= e(url('products.php')) ?>">add them to your cart again</a> to retry.</div>
  <p class="lead">Order number <strong><?= e($o['order_no']) ?></strong>. Keep it to track your order.</p>
  <div class="two-col">
    <div class="panel">
      <h2>Order details</h2>
      <ul class="mini-items">
        <?php foreach ($items as $i): ?>
        <li class="order-item">
          <span class="order-item-product"><?= product_media($i, 'order-item-image') ?><span><?= e($i['name']) ?> × <?= (int)$i['qty'] ?></span></span>
          <b class="order-item-price"><?= e(money($i['price'] * $i['qty'])) ?></b>
        </li>
        <?php endforeach; ?>
      </ul>
      <dl class="totals">
        <div><dt>Subtotal</dt><dd><?= e(money($o['subtotal'])) ?></dd></div>
        <?php if ($o['discount']): ?><div class="good"><dt>Discount (<?= e($o['coupon']) ?>)</dt><dd>-<?= e(money($o['discount'])) ?></dd></div><?php endif; ?>
        <div><dt>Delivery</dt><dd><?= $o['delivery_fee'] ? e(money($o['delivery_fee'])) : 'Free' ?></dd></div>
        <div class="grand"><dt>Total</dt><dd><?= e(money($o['total'])) ?></dd></div>
      </dl>
    </div>
    <div class="panel">
      <h2>What happens next</h2>
      <p><b>Payment:</b> <?= e(ucfirst(payment_status_label($o['payment_status']))) ?><?= $o['payment_ref'] ? ' · ref ' . e(payment_reference_label($o['payment_ref'])) : '' ?><?= $o['card_last4'] ? ' · card ending ' . e($o['card_last4']) : '' ?></p>
      <p><b>Delivery:</b> <?= e($zone[0]) ?>, <?= e($zone[2]) ?></p>
      <p><b>To:</b> <?= e($o['address']) ?></p>
      <p>We will call <strong><?= e($o['phone']) ?></strong> to confirm delivery time. Questions? <a href="<?= e(url('contact.php')) ?>">Contact support</a>.</p>
      <?php if (receipt_is_paid($o)): $rcp = receipt_record((int)$o['id']); ?>
      <p>Your payment receipt <?= !empty($rcp['emailed_at']) ? 'has been emailed to <strong>' . e($o['email']) . '</strong>.' : 'is ready.' ?></p>
      <p><a class="btn" href="<?= e(receipt_url($o)) ?>">View / print receipt</a></p>
      <?php endif; ?>
      <p><a class="btn" href="<?= e(url('track.php')) ?>">Track order</a> <a class="btn ghost" href="<?= e(url('products.php')) ?>">Keep shopping</a></p>
    </div>
  </div>
</section>
<?php if ($awaiting): ?>
<script>
(function () {
  var url = <?= json_encode(url('payment-status.php') . '?no=' . urlencode($o['order_no'])) ?>;
  var tries = 0;
  function show(id, on) { var n = document.getElementById(id); if (n) { n.hidden = !on; } }
  function tick() {
    tries++;
    fetch(url, {credentials: 'same-origin', cache: 'no-store'}).then(function (r) { return r.json(); }).then(function (d) {
      if (d.state === 'paid') {
        document.getElementById('pay-ico').textContent = '✅';
        document.getElementById('pay-heading').textContent = 'Payment received. Your order is confirmed!';
        show('pay-wait', false);
        setTimeout(function () { location.reload(); }, 1200);
      } else if (d.state === 'failed') {
        location.reload();
      } else if (tries < 75) {
        setTimeout(tick, 4000);
      }
    }).catch(function () { if (tries < 75) { setTimeout(tick, 6000); } });
  }
  setTimeout(tick, 3000);
})();
</script>
<?php endif; ?>
<?php require __DIR__ . '/includes/footer.php'; ?>

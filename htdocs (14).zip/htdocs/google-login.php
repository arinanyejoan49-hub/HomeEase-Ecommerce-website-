<?php
// Step 1: send the visitor to Google's sign-in screen.
require __DIR__ . '/includes/bootstrap.php';
require __DIR__ . '/includes/google_auth.php';
header('Cache-Control: no-store');

if (is_admin()) {
    redirect('admin/index.php');
}
if (is_customer()) {
    redirect('customer/dashboard.php');
}
$problem = google_login_problem();
if ($problem !== '') {
    flash('error', $problem . ' Please use your email and password for now.');
    redirect('login.php');
}
redirect(google_auth_url());

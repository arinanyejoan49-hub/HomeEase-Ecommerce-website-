<?php
declare(strict_types=1);
// Serves a product photo stored in the product_images table: /product-image.php?t=<32 hex chars>
require __DIR__ . '/includes/bootstrap.php';
session_write_close();

$token = is_string($_GET['t'] ?? null) ? strtolower($_GET['t']) : '';
$row = false;
if (preg_match('/^[a-f0-9]{32}$/', $token)) {
    try {
        $st = db()->prepare('SELECT mime, data FROM product_images WHERE token = ?');
        $st->execute([$token]);
        $row = $st->fetch();
    } catch (Throwable $e) {
        $row = false;
    }
}
if (!$row || !in_array($row['mime'], ['image/jpeg', 'image/png', 'image/webp'], true)) {
    http_response_code(404);
    exit;
}
$data = $row['data'];
if (is_resource($data)) {
    $data = stream_get_contents($data);
}
$data = (string)$data;
$etag = '"' . $token . '"';

header_remove('Pragma');
header_remove('Expires');
header('Cache-Control: public, max-age=31536000, immutable');
header('ETag: ' . $etag);
if (($_SERVER['HTTP_IF_NONE_MATCH'] ?? '') === $etag) {
    http_response_code(304);
    exit;
}
header('Content-Type: ' . $row['mime']);
header('Content-Length: ' . strlen($data));
echo $data;

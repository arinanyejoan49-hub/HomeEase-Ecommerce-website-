(function () {
  'use strict';

  var root = document.querySelector('[data-notif]');
  if (!root) {
    return;
  }

  var endpoint = root.getAttribute('data-endpoint');
  var csrf = root.getAttribute('data-csrf');
  var bell = root.querySelector('.notif-bell');
  var badge = root.querySelector('.notif-count');
  var panel = root.querySelector('.notif-panel');
  var list = root.querySelector('.notif-list');
  var markAll = root.querySelector('.notif-markall');
  var sideBadge = document.querySelector('[data-notif-side-badge]');
  var baseTitle = document.title.replace(/^\(\d+\)\s*/, '');
  var lastId = parseInt(root.getAttribute('data-latest') || '0', 10) || 0;
  var timer = null;
  var INTERVAL = 20000;

  var toasts = document.createElement('div');
  toasts.className = 'notif-toasts';
  toasts.setAttribute('aria-live', 'polite');
  document.body.appendChild(toasts);

  var SVG_NS = 'http://www.w3.org/2000/svg';

  function icon(item) {
    var wrap = document.createElement('span');
    wrap.className = 'notif-ico';
    wrap.style.setProperty('--notif-color', item.color || '#FF7900');
    var svg = document.createElementNS(SVG_NS, 'svg');
    svg.setAttribute('width', '18');
    svg.setAttribute('height', '18');
    svg.setAttribute('viewBox', '0 0 24 24');
    svg.setAttribute('fill', 'none');
    svg.setAttribute('stroke', 'currentColor');
    svg.setAttribute('stroke-width', '1.8');
    svg.setAttribute('stroke-linecap', 'round');
    svg.setAttribute('stroke-linejoin', 'round');
    svg.setAttribute('aria-hidden', 'true');
    // icon markup comes from our own server-side table (admin_notif_types), never from user input
    svg.innerHTML = item.icon || '';
    wrap.appendChild(svg);
    return wrap;
  }

  function row(item) {
    var a = document.createElement('a');
    a.className = 'notif-item' + (item.read ? '' : ' unread');
    a.href = item.url;
    a.appendChild(icon(item));
    var body = document.createElement('span');
    body.className = 'notif-text';
    var t = document.createElement('b');
    t.textContent = item.title;
    var m = document.createElement('span');
    m.className = 'notif-msg';
    m.textContent = item.message;
    var time = document.createElement('small');
    time.textContent = item.time;
    body.appendChild(t);
    body.appendChild(m);
    body.appendChild(time);
    a.appendChild(body);
    return a;
  }

  function render(items) {
    list.textContent = '';
    if (!items.length) {
      var empty = document.createElement('p');
      empty.className = 'notif-empty';
      empty.textContent = 'No notifications yet.';
      list.appendChild(empty);
      return;
    }
    items.forEach(function (item) {
      list.appendChild(row(item));
    });
  }

  function setUnread(n) {
    if (badge) {
      badge.textContent = n > 99 ? '99+' : String(n);
      badge.hidden = n < 1;
    }
    if (sideBadge) {
      sideBadge.textContent = String(n);
      sideBadge.hidden = n < 1;
    }
    if (markAll) {
      markAll.disabled = n < 1;
    }
    bell.setAttribute('aria-label', n > 0 ? 'Notifications, ' + n + ' unread' : 'Notifications');
    document.title = n > 0 ? '(' + n + ') ' + baseTitle : baseTitle;
  }

  function toast(item) {
    var el = row(item);
    el.className += ' notif-toast';
    var close = document.createElement('button');
    close.type = 'button';
    close.className = 'notif-toast-close';
    close.setAttribute('aria-label', 'Dismiss');
    close.textContent = '\u00d7';
    close.addEventListener('click', function (ev) {
      ev.preventDefault();
      ev.stopPropagation();
      el.remove();
    });
    el.appendChild(close);
    toasts.appendChild(el);
    window.setTimeout(function () {
      if (el.parentNode) {
        el.remove();
      }
    }, 8000);
  }

  function poll() {
    if (document.hidden) {
      return;
    }
    fetch(endpoint + '?since=' + lastId, { credentials: 'same-origin', headers: { Accept: 'application/json' } })
      .then(function (res) {
        var type = res.headers.get('content-type') || '';
        if (!res.ok || type.indexOf('application/json') === -1) {
          throw new Error('bad response');
        }
        return res.json();
      })
      .then(function (data) {
        setUnread(data.unread || 0);
        render(data.items || []);
        (data.fresh || []).forEach(toast);
        if (data.latest > lastId) {
          lastId = data.latest;
        }
      })
      .catch(function () {
        /* offline or session expired: try again next tick */
      });
  }

  function post(action, id) {
    var body = new URLSearchParams();
    body.set('csrf', csrf);
    body.set('action', action);
    if (id) {
      body.set('id', String(id));
    }
    return fetch(endpoint, { method: 'POST', credentials: 'same-origin', body: body });
  }

  function open(state) {
    panel.hidden = !state;
    bell.setAttribute('aria-expanded', state ? 'true' : 'false');
    if (state) {
      poll();
    }
  }

  bell.addEventListener('click', function (ev) {
    ev.stopPropagation();
    open(panel.hidden);
  });
  document.addEventListener('click', function (ev) {
    if (!panel.hidden && !root.contains(ev.target)) {
      open(false);
    }
  });
  document.addEventListener('keydown', function (ev) {
    if (ev.key === 'Escape' && !panel.hidden) {
      open(false);
      bell.focus();
    }
  });

  if (markAll) {
    markAll.addEventListener('click', function () {
      post('readall').then(poll);
    });
  }

  function start() {
    window.clearInterval(timer);
    timer = window.setInterval(poll, INTERVAL);
  }
  document.addEventListener('visibilitychange', function () {
    if (!document.hidden) {
      poll();
    }
  });

  setUnread(parseInt(root.getAttribute('data-unread') || '0', 10) || 0);
  start();
})();

(function () {
  'use strict';

  document.querySelectorAll('.toggle-password').forEach(function (button) {
    var input = document.getElementById(button.getAttribute('aria-controls'));
    if (!input) {
      return;
    }
    button.addEventListener('click', function () {
      var isVisible = input.type === 'text';
      input.type = isVisible ? 'password' : 'text';
      button.textContent = isVisible ? 'Show' : 'Hide';
      button.setAttribute('aria-label', isVisible ? 'Show password' : 'Hide password');
      button.setAttribute('aria-pressed', isVisible ? 'false' : 'true');
    });
  });

  // ---- Homepage hero carousel ----
  var hero = document.querySelector('.home-hero');
  if (hero) {
    var slides = Array.prototype.slice.call(hero.querySelectorAll('.hero-slide'));
    var indicators = Array.prototype.slice.call(hero.querySelectorAll('.hero-indicator'));
    var currentSlide = 0;
    var rotationTimer = null;
    var touchStartX = null;
    var reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');

    function stopRotation() {
      if (rotationTimer !== null) {
        window.clearTimeout(rotationTimer);
        rotationTimer = null;
      }
    }

    function scheduleRotation() {
      stopRotation();
      if (reducedMotion.matches || document.hidden || slides.length < 2) {
        return;
      }
      rotationTimer = window.setTimeout(function () {
        showSlide(currentSlide + 1);
      }, 3000);
    }

    function showSlide(index) {
      currentSlide = (index + slides.length) % slides.length;
      slides.forEach(function (slide, position) {
        var active = position === currentSlide;
        slide.classList.toggle('is-active', active);
        slide.setAttribute('aria-hidden', active ? 'false' : 'true');
        slide.inert = !active;
      });
      indicators.forEach(function (indicator, position) {
        var active = position === currentSlide;
        indicator.classList.toggle('is-active', active);
        indicator.setAttribute('aria-current', active ? 'true' : 'false');
      });
      scheduleRotation();
    }

    hero.addEventListener('keydown', function (event) {
      if (event.key === 'ArrowLeft') {
        event.preventDefault();
        showSlide(currentSlide - 1);
      } else if (event.key === 'ArrowRight') {
        event.preventDefault();
        showSlide(currentSlide + 1);
      }
    });
    hero.addEventListener('pointerdown', function (event) {
      if (event.pointerType === 'touch') {
        touchStartX = event.clientX;
      }
    });
    hero.addEventListener('pointerup', function (event) {
      if (touchStartX === null) {
        return;
      }
      var swipeDistance = event.clientX - touchStartX;
      touchStartX = null;
      if (Math.abs(swipeDistance) > 50) {
        showSlide(currentSlide + (swipeDistance < 0 ? 1 : -1));
      }
    });
    hero.addEventListener('pointercancel', function () {
      touchStartX = null;
    });
    hero.querySelector('[data-hero-prev]').addEventListener('click', function () {
      showSlide(currentSlide - 1);
    });
    hero.querySelector('[data-hero-next]').addEventListener('click', function () {
      showSlide(currentSlide + 1);
    });
    indicators.forEach(function (indicator, index) {
      indicator.addEventListener('click', function () {
        showSlide(index);
      });
    });
    document.addEventListener('visibilitychange', scheduleRotation);
    if (reducedMotion.addEventListener) {
      reducedMotion.addEventListener('change', scheduleRotation);
    } else if (reducedMotion.addListener) {
      reducedMotion.addListener(scheduleRotation);
    }
    scheduleRotation();
  }
  var btn = document.querySelector('.menu-btn');
  var nav = document.getElementById('nav');
  if (btn && nav) {
    btn.addEventListener('click', function () {
      var open = nav.classList.toggle('open');
      btn.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
  }

  // ---- Reveal public page content as it enters the viewport ----
  var revealMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
  if (!revealMotion.matches) {
    var revealTargets = document.querySelectorAll(
      'body:not(.admin) main.wrap > section:not(.home-hero), ' +
      'body:not(.admin) main.wrap .grid > .card, ' +
      'body:not(.admin) main.wrap .cat-grid > .cat, ' +
      'body:not(.admin) main.wrap > .panel, ' +
      'body:not(.admin) main.wrap > .empty'
    );

    if (revealTargets.length) {
      var pendingRevealTargets = Array.prototype.slice.call(revealTargets);
      var revealTimer = null;

      function revealContentInView() {
        revealTimer = null;
        var viewportBottom = window.innerHeight;
        pendingRevealTargets = pendingRevealTargets.filter(function (target) {
          if (target.getBoundingClientRect().top < viewportBottom - 32) {
            target.classList.add('is-visible');
            return false;
          }
          return true;
        });
        if (!pendingRevealTargets.length) {
          window.removeEventListener('scroll', scheduleRevealCheck);
          window.removeEventListener('resize', scheduleRevealCheck);
        }
      }

      revealTargets.forEach(function (target) {
        target.setAttribute('data-scroll-reveal', '');
        if (target.matches('.grid > .card, .cat-grid > .cat')) {
          var revealGroup = Array.prototype.filter.call(target.parentElement.children, function (sibling) {
            return sibling.matches('.card, .cat');
          });
          var revealIndex = revealGroup.indexOf(target);
          target.style.transitionDelay = Math.min(revealIndex, 5) * 55 + 'ms';
        }
      });
      document.documentElement.classList.add('scroll-reveal-enabled');

      function scheduleRevealCheck() {
        if (revealTimer === null) {
          revealTimer = window.setTimeout(revealContentInView, 60);
        }
      }

      window.addEventListener('scroll', scheduleRevealCheck, { passive: true });
      window.addEventListener('resize', scheduleRevealCheck);
      scheduleRevealCheck();
    }
  }

  // ---- Product listing back-to-top control ----
  var backToTop = document.querySelector('.back-to-top');
  if (backToTop) {
    function updateBackToTop() {
      backToTop.hidden = window.scrollY < 400;
    }

    window.addEventListener('scroll', updateBackToTop, { passive: true });
    backToTop.addEventListener('click', function () {
      window.scrollTo({
        top: 0,
        behavior: window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth'
      });
    });
    updateBackToTop();
  }

  // ---- Confirm dialogs for destructive forms ----
  document.querySelectorAll('form[data-confirm]').forEach(function (f) {
    f.addEventListener('submit', function (e) {
      if (!window.confirm(f.getAttribute('data-confirm'))) { e.preventDefault(); }
    });
  });

  // ---- Auto-submit selects (cart delivery estimate) ----
  document.querySelectorAll('select[data-autosubmit]').forEach(function (s) {
    s.addEventListener('change', function () { s.form.submit(); });
  });

  // ---- Checkout: payment panels + delivery address toggle + card formatting ----
  var radios = document.querySelectorAll('input[name="method"]');
  var panels = document.querySelectorAll('.pay-panel');
  function showPanel() {
    var chosen = document.querySelector('input[name="method"]:checked');
    panels.forEach(function (p) {
      p.hidden = !chosen || p.getAttribute('data-panel') !== chosen.value;
    });
  }
  if (radios.length) {
    radios.forEach(function (r) { r.addEventListener('change', showPanel); });
    showPanel();
  }
  var zone = document.getElementById('zone');
  var addr = document.getElementById('addr-wrap');
  if (zone && addr) {
    var toggleAddr = function () { addr.style.display = zone.value === 'pickup' ? 'none' : ''; };
    zone.addEventListener('change', toggleAddr);
    toggleAddr();
  }
  var card = document.querySelector('input[name="card_number"]');
  if (card) {
    card.addEventListener('input', function () {
      var v = card.value.replace(/\D/g, '').slice(0, 19);
      card.value = v.replace(/(.{4})/g, '$1 ').trim();
    });
  }
  var exp = document.querySelector('input[name="card_exp"]');
  if (exp) {
    exp.addEventListener('input', function () {
      var v = exp.value.replace(/\D/g, '').slice(0, 4);
      exp.value = v.length > 2 ? v.slice(0, 2) + '/' + v.slice(2) : v;
    });
  }

  // ---- Cookie consent + Google Analytics (loaded only after the visitor accepts) ----
  function getConsent() {
    try { return window.localStorage.getItem('he_consent'); } catch (e) { return null; }
  }
  function setConsent(v) {
    try { window.localStorage.setItem('he_consent', v); } catch (e) { /* ignore */ }
  }
  function loadGA() {
    var id = document.body.getAttribute('data-ga');
    if (!id || window.__gaLoaded) { return; }
    window.__gaLoaded = true;
    var s = document.createElement('script');
    s.async = true;
    s.src = 'https://www.googletagmanager.com/gtag/js?id=' + encodeURIComponent(id);
    document.head.appendChild(s);
    window.dataLayer = window.dataLayer || [];
    window.gtag = function () { window.dataLayer.push(arguments); };
    window.gtag('js', new Date());
    window.gtag('config', id, { anonymize_ip: true });
  }
  var box = document.getElementById('consent');
  if (box) {
    var c = getConsent();
    if (c === 'yes') { loadGA(); }
    else if (c === null) { box.hidden = false; }
    box.querySelectorAll('[data-consent]').forEach(function (b) {
      b.addEventListener('click', function () {
        var v = b.getAttribute('data-consent');
        setConsent(v);
        box.hidden = true;
        if (v === 'yes') { loadGA(); }
      });
    });
  }
  // ---- Homepage promotion countdowns ----
  var promoSection = document.querySelector('[data-promo-section]');
  if (promoSection) {
    var promoCards = Array.prototype.slice.call(promoSection.querySelectorAll('[data-promo-card]'));
    // Use the server's clock as the reference so a wrong device clock can't skew the countdown.
    var promoOffset = (parseInt(promoSection.getAttribute('data-server-now'), 10) * 1000) - Date.now();
    var pad2 = function (n) { return (n < 10 ? '0' : '') + n; };
    var daysLeftText = function (d) { return d >= 2 ? d + ' days left' : (d === 1 ? '1 day left' : 'Ends today'); };

    var tickPromos = function () {
      var now = Date.now() + promoOffset;
      var visible = 0;
      promoCards.forEach(function (card) {
        if (card.hidden) { return; }
        var left = Math.floor((parseInt(card.getAttribute('data-promo-end'), 10) * 1000 - now) / 1000);
        if (left <= 0) { card.hidden = true; return; }
        visible++;
        var d = Math.floor(left / 86400), h = Math.floor((left % 86400) / 3600),
            m = Math.floor((left % 3600) / 60), s = left % 60;
        var set = function (unit, val) {
          var el = card.querySelector('[data-unit="' + unit + '"]');
          if (el && el.textContent !== val) { el.textContent = val; return el; }
          return null;
        };
        set('days', pad2(d)); set('hours', pad2(h)); set('mins', pad2(m));
        var secEl = set('secs', pad2(s));
        if (secEl) { secEl.classList.remove('is-tick'); void secEl.offsetWidth; secEl.classList.add('is-tick'); }
        var label = card.querySelector('[data-promo-left]');
        if (label) { label.textContent = daysLeftText(d); }
      });
      if (!visible) { promoSection.hidden = true; clearInterval(promoTimer); }
    };
    var promoTimer = setInterval(tickPromos, 1000);
    tickPromos();
  }
})();

// Contact links (email, phone, WhatsApp). On a computer with no mail, phone or WhatsApp app set up,
// Windows asks "How do you want to open this?". So on desktop these links open web versions instead.
// Phones and tablets keep the normal mailto:, tel: and wa.me behaviour.
(function () {
  'use strict';

  var ua = navigator.userAgent || '';
  var isTouchDevice = /Android|iPhone|iPad|iPod|Mobile|Windows Phone/i.test(ua) ||
    (/Macintosh/.test(ua) && navigator.maxTouchPoints > 1);
  if (isTouchDevice) { return; }

  var toastTimer;
  function showToast(message) {
    var toast = document.getElementById('contact-toast');
    if (!toast) {
      toast = document.createElement('div');
      toast.id = 'contact-toast';
      toast.className = 'contact-toast';
      toast.setAttribute('role', 'status');
      document.body.appendChild(toast);
    }
    toast.textContent = message;
    toast.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { toast.classList.remove('show'); }, 3500);
  }

  function copyText(text) {
    if (navigator.clipboard && window.isSecureContext) {
      return navigator.clipboard.writeText(text);
    }
    return new Promise(function (resolve, reject) {
      var box = document.createElement('textarea');
      box.value = text;
      box.setAttribute('readonly', '');
      box.style.position = 'fixed';
      box.style.opacity = '0';
      document.body.appendChild(box);
      box.select();
      try { document.execCommand('copy') ? resolve() : reject(); } catch (err) { reject(err); }
      document.body.removeChild(box);
    });
  }

  document.addEventListener('click', function (event) {
    if (event.defaultPrevented || event.button !== 0 || event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) { return; }
    var link = event.target.closest ? event.target.closest('a[href]') : null;
    if (!link) { return; }
    var href = link.getAttribute('href') || '';

    if (/^mailto:/i.test(href)) {
      // Email: open Gmail's compose window in a new tab.
      event.preventDefault();
      var mail = new URL(href);
      var gmail = 'https://mail.google.com/mail/?view=cm&fs=1&to=' + encodeURIComponent(decodeURIComponent(mail.pathname));
      if (mail.searchParams.get('subject')) { gmail += '&su=' + encodeURIComponent(mail.searchParams.get('subject')); }
      if (mail.searchParams.get('body')) { gmail += '&body=' + encodeURIComponent(mail.searchParams.get('body')); }
      window.open(gmail, '_blank', 'noopener');
    } else if (/^tel:/i.test(href)) {
      // Phone: a computer cannot place a call, so copy the number and say so.
      event.preventDefault();
      var number = decodeURIComponent(href.replace(/^tel:/i, ''));
      copyText(number).then(function () {
        showToast('Phone number copied: ' + number);
      }, function () {
        showToast('Call us on ' + number);
      });
    } else if (/^https?:\/\/wa\.me\//i.test(href)) {
      // WhatsApp: open WhatsApp Web directly instead of asking for an app.
      event.preventDefault();
      var wa = new URL(href);
      var web = 'https://web.whatsapp.com/send?phone=' + encodeURIComponent(wa.pathname.replace(/\D/g, ''));
      if (wa.searchParams.get('text')) { web += '&text=' + encodeURIComponent(wa.searchParams.get('text')); }
      window.open(web, '_blank', 'noopener');
    }
  });
})();

<?php
require __DIR__ . '/includes/bootstrap.php';
require_once __DIR__ . '/includes/email.php';
header('Cache-Control: no-store');

$title = 'Forgot password';
$desc = 'Reset your account password.';
$here = 'forgot-password.php';

$resetTableAvailable = table_exists('password_resets');
$customerResetAvailable = table_exists('users') && $resetTableAvailable;
$adminResetAvailable = table_exists('admins')
    && $resetTableAvailable
    && column_exists('password_resets', 'admin_id');
$resetAvailable = $customerResetAvailable || $adminResetAvailable;

$errors = [];
$values = ['email' => ''];
$devLink = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();

    if (!$resetAvailable) {
        $errors['_general'] = 'Password reset is unavailable until account and reset-token tables are installed.';
    } else {
        $emailInput = $_POST['email'] ?? '';
        $email = is_string($emailInput) ? strtolower(trim($emailInput)) : '';
        $values['email'] = $email;
        if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors['email'] = 'Please enter a valid email address.';
        }

        $identifier = 'reset:' . hash('sha256', $_SERVER['REMOTE_ADDR'] ?? 'unknown');
        if (empty($errors) && is_rate_limited($identifier)) {
            $errors['_general'] = 'Too many requests. Please try again later.';
        }

        if (empty($errors)) {
            record_login_attempt($identifier, true);
            $admin = $adminResetAvailable
                ? q('SELECT id, name, email FROM admins WHERE email = ?', [$email])->fetch()
                : false;
            $user = !$admin && $customerResetAvailable
                ? q('SELECT id, first_name, last_name, email FROM users WHERE email = ? AND role = "customer" AND status = "active"', [$email])->fetch()
                : false;
            $account = $admin ?: $user;

            if ($account) {
                if ($admin) {
                    $userId = null;
                    $adminId = (int)$admin['id'];
                    $recipientName = $admin['name'];
                } else {
                    $userId = (int)$user['id'];
                    $adminId = null;
                    $recipientName = $user['first_name'] . ' ' . $user['last_name'];
                }

                $raw = bin2hex(random_bytes(32));
                $hash = hash('sha256', $raw);
                $expires = date('Y-m-d H:i:s', time() + 3600);
                $pdo = db();
                try {
                    $pdo->beginTransaction();
                    if ($admin) {
                        q('UPDATE password_resets SET used = 1 WHERE admin_id = ? AND used = 0', [$adminId]);
                    } else {
                        q('UPDATE password_resets SET used = 1 WHERE user_id = ? AND used = 0', [$userId]);
                    }
                    if ($adminResetAvailable) {
                        q(
                            'INSERT INTO password_resets (user_id, admin_id, token, expires_at) VALUES (?,?,?,?)',
                            [$userId, $adminId, $hash, $expires]
                        );
                    } else {
                        q(
                            'INSERT INTO password_resets (user_id, token, expires_at) VALUES (?,?,?)',
                            [$userId, $hash, $expires]
                        );
                    }
                    $pdo->commit();
                } catch (Throwable $e) {
                    if ($pdo->inTransaction()) {
                        $pdo->rollBack();
                    }
                    error_log('Password reset token creation failed: ' . $e->getMessage());
                    $errors['_general'] = 'Could not create a reset link. Please try again later.';
                }
                if (empty($errors)) {
                    $link = rtrim(SITE_URL, '/') . url('reset-password.php?token=' . $raw);
                    $subject = 'Reset your ' . SITE_NAME . ' password';
                    $body = "Hello " . $recipientName . ",\n\nWe received a request to reset your password. Use the link below within 1 hour:\n\n" . $link . "\n\nIf you did not request this, ignore this email.\n";
                    $delivery = send_store_email($account['email'], $recipientName, $subject, $body);
                    if (!$delivery['success']) {
                        error_log('Password reset email delivery failed (' . $delivery['state'] . ').');
                        if (APP_ENV === 'development' && !FORCE_HTTPS && !request_is_https()) {
                            $devLink = $link;
                        }
                    }
                }
            }

            if (empty($errors)) {
                flash('success', 'If an account exists for that email, a password reset link has been sent.');
            }
            if ($devLink === null) {
                if (empty($errors)) {
                    redirect('forgot-password.php');
                }
            }
        }
    }
}

require __DIR__ . '/includes/header.php';
?>
<h1>Forgot your password?</h1>
<p class="lead">Enter your email address and, if an account exists, we will send a secure reset link.</p>

<?php if (!empty($errors['_general'])): ?>
  <div class="alert error" role="alert"><?= e($errors['_general']) ?></div>
<?php endif; ?>

<?php if ($devLink): ?>
  <div class="alert" role="status">
    <strong>Local development only:</strong> email delivery is not configured. Use this reset link and do not share it:
    <br><a href="<?= e($devLink) ?>"><?= e($devLink) ?></a>
  </div>
<?php endif; ?>

<?php if ($resetAvailable): ?>
<form method="post" action="<?= e(url('forgot-password.php')) ?>" class="auth-form" novalidate>
  <?= csrf_field() ?>
  <div class="form-field">
    <label for="email">Email address <span class="required">*</span></label>
    <input type="email" id="email" name="email" maxlength="150" value="<?= e($values['email']) ?>"
           autocomplete="email" required
           <?= isset($errors['email']) ? 'aria-invalid="true"' : '' ?>>
    <?php if (isset($errors['email'])): ?><span class="field-error"><?= e($errors['email']) ?></span><?php endif; ?>
  </div>
  <div class="form-actions">
    <button type="submit" class="btn">Send reset link</button>
    <a class="btn small ghost" href="<?= e(url('login.php')) ?>">Back to login</a>
  </div>
</form>
<?php else: ?>
  <div class="alert error" role="alert">Account recovery is not set up yet. The site administrator must install the account tables and apply the password-reset migration.</div>
<?php endif; ?>

<?php require __DIR__ . '/includes/footer.php'; ?>

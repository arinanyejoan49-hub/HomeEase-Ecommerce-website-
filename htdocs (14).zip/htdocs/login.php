<?php
require __DIR__ . '/includes/bootstrap.php';
require __DIR__ . '/includes/google_auth.php';
header('Cache-Control: no-store');

if (is_admin()) {
    redirect('admin/index.php');
}
if (is_customer()) {
    redirect('customer/dashboard.php');
}

$title = 'Log In';
$desc = 'Sign in to your HomeEase account.';
$here = 'login.php';
$adminAccountsAvailable = table_exists('admins');
$customerAccountsAvailable = table_exists('users');
$accountsAvailable = $adminAccountsAvailable || $customerAccountsAvailable;
$setupMessage = !$accountsAvailable
    ? 'Account sign-in is unavailable until the site administrator installs the account tables.'
    : '';
$customerSchemaNotice = $adminAccountsAvailable && !$customerAccountsAvailable
    ? 'Customer sign-in is unavailable until the site administrator imports database.sql. Administrator sign-in remains available.'
    : '';
$errors = [];
$values = ['email' => '', 'remember' => false];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    if ($setupMessage !== '') {
        $errors['_general'] = $setupMessage;
    } else {
        $identifierInput = $_POST['email'] ?? '';
        $identifier = is_string($identifierInput) ? mb_strtolower(trim($identifierInput)) : '';
        $identifier = mb_substr($identifier, 0, 150);
        $values['email'] = $identifier;
        $passwordInput = $_POST['password'] ?? '';
        $password = is_string($passwordInput) ? $passwordInput : '';
        $remember = isset($_POST['remember']) && $_POST['remember'] === '1';
        $values['remember'] = $remember;
        $rateKey = hash('sha256', $identifier . "\0" . ($_SERVER['REMOTE_ADDR'] ?? 'unknown'));

        if ($identifier === '' || $password === '') {
            $errors['_general'] = 'Enter your email address or username and password.';
        } elseif (is_rate_limited($rateKey)) {
            $errors['_general'] = 'Too many sign-in attempts. Please wait a few minutes and try again.';
        } else {
            $admin = $adminAccountsAvailable
                ? q('SELECT id, name, email, password_hash FROM admins WHERE email = ?', [$identifier])->fetch()
                : false;
            $user = !$admin && $customerAccountsAvailable
                ? q('SELECT * FROM users WHERE (email = ? OR username = ?) AND role = "customer"', [$identifier, $identifier])->fetch()
                : false;
            $account = $admin ?: $user;
            $dummyHash = '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2uheWG/igi.';
            $passwordMatches = password_verify($password, $account['password_hash'] ?? $dummyHash);

            if ($admin && $passwordMatches) {
                record_login_attempt($rateKey, true);
                admin_login($admin);
                setcookie('he_remember', '', [
                    'expires' => time() - 3600,
                    'path' => '/',
                    'secure' => request_is_https(),
                    'httponly' => true,
                    'samesite' => 'Lax',
                ]);
                unset($_COOKIE['he_remember']);
                flash('success', 'Welcome back, ' . $admin['name'] . '.');
                redirect('admin/index.php');
            }

            if ($user && $passwordMatches && $user['status'] !== 'active') {
                record_login_attempt($rateKey, false);
                $errors['_general'] = 'This account is currently disabled. Please contact HomeEase support.';
            } elseif ($user && $passwordMatches) {
                record_login_attempt($rateKey, true);
                customer_login($user);

                if ($remember) {
                    $token = bin2hex(random_bytes(32));
                    $cookieHash = hash('sha256', $token);
                    setcookie('he_remember', $token, [
                        'expires' => time() + (30 * 24 * 60 * 60),
                        'path' => '/',
                        'secure' => request_is_https(),
                        'httponly' => true,
                        'samesite' => 'Lax',
                    ]);
                    $expires = date('Y-m-d H:i:s', time() + (30 * 24 * 60 * 60));
                    q('UPDATE users SET remember_token = ?, remember_expires = ? WHERE id = ?', [$cookieHash, $expires, (int)$user['id']]);
                } else {
                    q('UPDATE users SET remember_token = NULL, remember_expires = NULL WHERE id = ?', [(int)$user['id']]);
                    setcookie('he_remember', '', [
                        'expires' => time() - 3600,
                        'path' => '/',
                        'secure' => request_is_https(),
                        'httponly' => true,
                        'samesite' => 'Lax',
                    ]);
                    unset($_COOKIE['he_remember']);
                }

                flash('success', 'Welcome back, ' . $user['first_name'] . '!');
                redirect('customer/dashboard.php');
            } else {
                record_login_attempt($rateKey, false);
                $errors['_general'] = 'Email/username or password is incorrect.';
            }
        }
    }
}

require __DIR__ . '/includes/header.php';
?>
<section class="auth-page" aria-labelledby="login-heading">
  <div class="auth-form login-form">
    <a class="auth-brand" href="<?= e(url('index.php')) ?>" aria-label="<?= e(SITE_NAME) ?> homepage">
      <span class="logo"><svg width="24" height="24" viewBox="0 0 24 24" aria-hidden="true"><path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z"/></svg></span>
      <span><?= e(SITE_NAME) ?></span>
    </a>
    <h1 id="login-heading">Welcome Back to HomeEase</h1>
    <p class="lead">Your home, your comfort, our priority.</p>

    <?php if ($setupMessage !== ''): ?>
      <div class="alert error" role="alert"><?= e($setupMessage) ?>
        <?php if (!$customerAccountsAvailable): ?> The site administrator must import <code>database.sql</code> in phpMyAdmin.<?php endif; ?>
      </div>
    <?php endif; ?>
    <?php if ($customerSchemaNotice !== ''): ?>
      <div class="alert error" role="alert"><?= e($customerSchemaNotice) ?></div>
    <?php endif; ?>
    <?php if (!empty($errors['_general'])): ?>
      <div class="alert error" role="alert"><?= e($errors['_general']) ?></div>
    <?php endif; ?>

    <form method="post" action="<?= e(url('login.php')) ?>" novalidate>
      <?= csrf_field() ?>
      <div class="form-field">
        <label for="email">Email address or username <span class="required">*</span></label>
        <input type="text" id="email" name="email" maxlength="150" required
               value="<?= e($values['email']) ?>" placeholder="Email address or username"
               autocomplete="username" autocapitalize="none" spellcheck="false">
      </div>
      <div class="form-field">
        <label for="password">Password <span class="required">*</span></label>
        <div class="password-input">
          <input type="password" id="password" name="password" required
                 autocomplete="current-password">
          <button type="button" class="toggle-password" aria-label="Show password"
                  aria-controls="password" aria-pressed="false">Show</button>
        </div>
      </div>
      <div class="form-field checkbox-field">
        <label class="checkbox-label">
          <input type="checkbox" name="remember" value="1" <?= $values['remember'] ? 'checked' : '' ?>>
          Keep customer accounts signed in on this device
        </label>
      </div>
      <button type="submit" class="btn block" <?= $setupMessage !== '' ? 'disabled' : '' ?>>Log In</button>
    </form>

    <?php render_google_signin(); ?>

    <p class="auth-links">
      <a href="<?= e(url('forgot-password.php')) ?>">Forgot password?</a>
      <span aria-hidden="true">·</span>
      <a href="<?= e(url('index.php')) ?>">Back to Home</a>
    </p>
    <p class="auth-switch">Don't have an account? <a href="<?= e(url('register.php')) ?>">Create an account</a></p>
  </div>
</section>
<?php require __DIR__ . '/includes/footer.php'; ?>

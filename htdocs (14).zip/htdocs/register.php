<?php
require __DIR__ . '/includes/bootstrap.php';
require __DIR__ . '/includes/google_auth.php';

// Redirect already-logged-in customers
if (is_admin()) {
    redirect('admin/index.php');
}
if (is_customer()) {
    redirect('customer/dashboard.php');
}

// Never cache this page: a cached form carries an old security token.
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');

$title = 'Create Your Account';
$desc = 'Join our home appliances store to discover quality products and enjoy convenient shopping.';
$here = 'register.php';
$customerAccountsAvailable = table_exists('users');

// ---------- Form state ----------
$errors = [];
$values = [
    'first_name' => '',
    'last_name' => '',
    'username' => '',
    'email' => '',
    'phone' => '',
    'gender' => '',
    'date_of_birth' => '',
    'country' => 'Uganda',
    'district' => '',
    'address' => '',
    'terms' => false,
    'privacy' => false,
];

// ---------- Process registration ----------
$isPost = $_SERVER['REQUEST_METHOD'] === 'POST';
$csrfOk = $isPost
    && is_string($_POST['csrf'] ?? null)
    && ($_SESSION['csrf'] ?? '') !== ''
    && hash_equals($_SESSION['csrf'], $_POST['csrf']);

if ($isPost && !$csrfOk) {
    // Soft failure: show the form again with a fresh token instead of a dead-end page.
    $errors['_general'] = 'Your session expired before the form was sent. Please fill it in and submit again. If this keeps happening, enable cookies for this site.';
} elseif ($isPost && !$customerAccountsAvailable) {
    $errors['_general'] = 'Customer accounts are not set up yet. Please ask the site administrator to import database.sql.';
} elseif ($isPost) {

    // Collect and trim inputs
    $values['first_name'] = trim($_POST['first_name'] ?? '');
    $values['last_name']  = trim($_POST['last_name'] ?? '');
    $values['email']      = strtolower(trim($_POST['email'] ?? ''));
    $values['phone']      = trim($_POST['phone'] ?? '');
    $values['terms']      = !empty($_POST['terms']);
    $values['privacy']    = $values['terms']; // one combined consent checkbox

    $password = $_POST['password'] ?? '';
    $confirm  = $_POST['confirm_password'] ?? '';

    // ---- Server-side validation ----
    if ($values['first_name'] === '') { $errors['first_name'] = 'First name is required.'; }
    elseif (mb_strlen($values['first_name']) < 2) { $errors['first_name'] = 'First name must be at least 2 characters.'; }
    elseif (mb_strlen($values['first_name']) > 100) { $errors['first_name'] = 'First name is too long.'; }

    if ($values['last_name'] === '') { $errors['last_name'] = 'Last name is required.'; }
    elseif (mb_strlen($values['last_name']) < 2) { $errors['last_name'] = 'Last name must be at least 2 characters.'; }
    elseif (mb_strlen($values['last_name']) > 100) { $errors['last_name'] = 'Last name is too long.'; }

    if ($values['email'] === '') { $errors['email'] = 'Email address is required.'; }
    elseif (!filter_var($values['email'], FILTER_VALIDATE_EMAIL)) { $errors['email'] = 'Please enter a valid email address.'; }
    else {
        $exists = q('SELECT 1 FROM users WHERE email = ?', [$values['email']])->fetch();
        if ($exists) { $errors['email'] = 'This email address is already registered.'; }
        elseif (table_exists('admins') && q('SELECT 1 FROM admins WHERE email = ?', [$values['email']])->fetch()) {
            $errors['email'] = 'This email address is already in use.';
        }
    }

    if ($values['phone'] === '') { $errors['phone'] = 'Phone number is required.'; }
    elseif (!preg_match('/^\+?[0-9\s\-()]{7,20}$/', $values['phone'])) { $errors['phone'] = 'Please enter a valid phone number.'; }

    if ($password === '') { $errors['password'] = 'Password is required.'; }
    elseif (strlen($password) < 8) { $errors['password'] = 'Password must be at least 8 characters.'; }
    elseif (!preg_match('/[A-Z]/', $password)) { $errors['password'] = 'Password must contain at least one uppercase letter.'; }
    elseif (!preg_match('/[a-z]/', $password)) { $errors['password'] = 'Password must contain at least one lowercase letter.'; }
    elseif (!preg_match('/[0-9]/', $password)) { $errors['password'] = 'Password must contain at least one number.'; }

    if ($confirm === '') { $errors['confirm_password'] = 'Please confirm your password.'; }
    elseif ($confirm !== $password) { $errors['confirm_password'] = 'Passwords do not match.'; }

    if (!$values['terms']) { $errors['terms'] = 'Please accept the Terms and Privacy Policy to continue.'; }

    // ---- Insert if no errors ----
    if (empty($errors)) {
        // Username is generated from the email so the form stays short (login still accepts email).
        $base = preg_replace('/[^a-z0-9_]/', '', strtolower(strstr($values['email'], '@', true))) ?: 'user';
        $base = substr($base, 0, 40);
        $values['username'] = $base;
        for ($i = 0; q('SELECT 1 FROM users WHERE username = ?', [$values['username']])->fetch(); $i++) {
            $values['username'] = $base . random_int(100, 99999);
            if ($i > 20) { break; }
        }
        $values['gender'] = ''; $values['date_of_birth'] = ''; $values['district'] = ''; $values['address'] = '';
        $values['country'] = 'Uganda';
        try {
            $pdo = db();
            $pdo->beginTransaction();
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $now = date('Y-m-d H:i:s');
            $accepted = $now;
            $pdo->prepare('INSERT INTO users (first_name, last_name, username, email, phone, password_hash, gender, date_of_birth, country, district, address, role, status, terms_accepted_at, privacy_accepted_at, created_at, updated_at)
                           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, "customer", "active", ?, ?, ?, ?)')
                ->execute([
                    $values['first_name'], $values['last_name'], $values['username'], $values['email'],
                    $values['phone'], $hash, $values['gender'] ?: null, $values['date_of_birth'] ?: null,
                    $values['country'], $values['district'] ?: null, $values['address'] ?: null,
                    $accepted, $accepted, $now, $now
                ]);
            // Read the new id BEFORE commit(): on MySQL, commit() resets lastInsertId() to 0.
            $newId = (int)$pdo->lastInsertId();
            $pdo->commit();
            admin_notify('customer', 'New customer registered', trim($values['first_name'] . ' ' . $values['last_name']) . ' (' . $values['email'] . ') just created an account.', 'admin/customer-details.php?id=' . $newId);
        } catch (Throwable $e) {
            if (isset($pdo) && $pdo->inTransaction()) { $pdo->rollBack(); }
            error_log('Registration failed: ' . $e->getMessage());
            $errors['_general'] = 'Registration failed. Please try again.';
            $newId = 0;
        }

        // Safety net: if the id still came back empty, find the row we just inserted.
        if ($newId <= 0 && empty($errors['_general'])) {
            $row = q('SELECT id FROM users WHERE email = ?', [$values['email']])->fetch();
            $newId = $row ? (int)$row['id'] : 0;
            if ($newId <= 0) {
                $errors['_general'] = 'Registration could not be completed. Please try again.';
            }
        }

        // The account exists now. Logging in is a separate step so a problem
        // here can never be reported as a failed registration.
        if ($newId > 0) {
            try {
                $user = q('SELECT * FROM users WHERE id = ?', [$newId])->fetch();
                customer_login($user);
                flash('success', 'Welcome to ' . e(SITE_NAME) . ', ' . e($values['first_name']) . '! Your account has been created.');
                redirect('customer/dashboard.php');
            } catch (Throwable $e) {
                error_log('Auto-login after registration failed: ' . $e->getMessage());
                flash('success', 'Your account has been created. Please log in.');
                redirect('login.php');
            }
        }
    }
}
require __DIR__ . '/includes/header.php';
?>
<h1>Create Your Account</h1>
<p class="lead">Join our home appliances store to discover quality products and enjoy convenient shopping.</p>
<?php if (!$customerAccountsAvailable): ?>
  <div class="alert error" role="alert">Customer registration is temporarily unavailable. The site administrator must import <code>database.sql</code> in phpMyAdmin.</div>
<?php endif; ?>

<form method="post" action="<?= e(url('register.php')) ?>" class="auth-form" novalidate>
  <?= csrf_field() ?>

  <?php if (!empty($errors['_general'])): ?>
    <div class="alert error" role="alert"><?= e($errors['_general']) ?></div>
  <?php endif; ?>

  <div class="form-grid">
    <div class="form-field">
      <label for="first_name">First Name <span class="required">*</span></label>
      <input type="text" id="first_name" name="first_name" maxlength="100" autocomplete="given-name"
             value="<?= e($values['first_name']) ?>" placeholder="Your first name"
             <?= isset($errors['first_name']) ? 'aria-invalid="true"' : '' ?>>
      <?php if (isset($errors['first_name'])): ?><span class="field-error"><?= e($errors['first_name']) ?></span><?php endif; ?>
    </div>

    <div class="form-field">
      <label for="last_name">Last Name <span class="required">*</span></label>
      <input type="text" id="last_name" name="last_name" maxlength="100" autocomplete="family-name"
             value="<?= e($values['last_name']) ?>" placeholder="Your last name"
             <?= isset($errors['last_name']) ? 'aria-invalid="true"' : '' ?>>
      <?php if (isset($errors['last_name'])): ?><span class="field-error"><?= e($errors['last_name']) ?></span><?php endif; ?>
    </div>

    <div class="form-field">
      <label for="email">Email Address <span class="required">*</span></label>
      <input type="email" id="email" name="email" maxlength="150" autocomplete="email"
             value="<?= e($values['email']) ?>" placeholder="you@example.com"
             <?= isset($errors['email']) ? 'aria-invalid="true"' : '' ?>>
      <?php if (isset($errors['email'])): ?><span class="field-error"><?= e($errors['email']) ?></span><?php endif; ?>
    </div>

    <div class="form-field">
      <label for="phone">Phone Number <span class="required">*</span></label>
      <input type="tel" id="phone" name="phone" maxlength="20" autocomplete="tel"
             value="<?= e($values['phone']) ?>" placeholder="e.g. +256 700 000 000"
             <?= isset($errors['phone']) ? 'aria-invalid="true"' : '' ?>>
      <?php if (isset($errors['phone'])): ?><span class="field-error"><?= e($errors['phone']) ?></span><?php endif; ?>
    </div>

    <div class="form-field full">
      <label for="password">Password <span class="required">*</span></label>
      <div class="password-input">
        <input type="password" id="password" name="password" minlength="8" autocomplete="new-password"
               placeholder="8+ characters, with upper, lower and a number"
               <?= isset($errors['password']) ? 'aria-invalid="true"' : '' ?>>
        <button type="button" class="toggle-password" aria-label="Show/hide password">👁️</button>
      </div>
      <div id="password-strength" class="strength-meter"></div>
      <?php if (isset($errors['password'])): ?><span class="field-error"><?= e($errors['password']) ?></span><?php endif; ?>
    </div>

    <div class="form-field full">
      <label for="confirm_password">Confirm Password <span class="required">*</span></label>
      <div class="password-input">
        <input type="password" id="confirm_password" name="confirm_password" minlength="8" autocomplete="new-password"
               placeholder="Re-enter your password"
               <?= isset($errors['confirm_password']) ? 'aria-invalid="true"' : '' ?>>
        <button type="button" class="toggle-password" aria-label="Show/hide password">👁️</button>
      </div>
      <?php if (isset($errors['confirm_password'])): ?><span class="field-error"><?= e($errors['confirm_password']) ?></span><?php endif; ?>
    </div>

    <div class="form-field full checkbox-field">
      <label class="checkbox-label">
        <input type="checkbox" name="terms" value="1" <?= $values['terms'] ? 'checked' : '' ?>>
        I accept the <a href="<?= e(url('terms.php')) ?>" target="_blank">Terms and Conditions</a>
        and <a href="<?= e(url('privacy.php')) ?>" target="_blank">Privacy Policy</a>
        <span class="required">*</span>
      </label>
      <?php if (isset($errors['terms'])): ?><span class="field-error"><?= e($errors['terms']) ?></span><?php endif; ?>
    </div>
  </div>

  <div class="form-actions">
    <button type="submit" class="btn">Create Account</button>
  </div>

  <?php render_google_signin(); ?>
</form>

<p class="auth-switch">
  Already have an account? <a href="<?= e(url('login.php')) ?>">Log in</a>
</p>

<?php require __DIR__ . '/includes/footer.php'; ?>
<?php
require __DIR__ . '/includes/bootstrap.php';
require_once __DIR__ . '/includes/email.php';

$errors = [];
$old = ['name' => '', 'email' => '', 'subject' => is_string($_GET['subject'] ?? '') ? mb_substr($_GET['subject'] ?? '', 0, 160) : '', 'message' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    foreach (['name' => 120, 'email' => 160, 'subject' => 160, 'message' => 2000] as $k => $max) {
        $old[$k] = post($k, $max);
    }
    // Honeypot field: real users leave it empty, simple bots fill it.
    if (post('website', 50) !== '') {
        redirect('contact.php');
    }
    // Basic rate limit: max 5 messages per session per hour.
    $_SESSION['msg_times'] = array_filter($_SESSION['msg_times'] ?? [], fn($t) => $t > time() - 3600);
    if (count($_SESSION['msg_times']) >= 5) { $errors[] = 'You have sent several messages recently. Please wait a while or call us.'; }
    if (mb_strlen($old['name']) < 2) { $errors[] = 'Please enter your name.'; }
    if (!filter_var($old['email'], FILTER_VALIDATE_EMAIL)) { $errors[] = 'Please enter a valid email address.'; }
    if ($old['subject'] === '') { $errors[] = 'Please add a subject.'; }
    if (mb_strlen($old['message']) < 10) { $errors[] = 'Please write a message of at least 10 characters.'; }
    if (!$errors) {
        q('INSERT INTO messages (name, email, subject, message) VALUES (?,?,?,?)', [$old['name'], strtolower($old['email']), $old['subject'], $old['message']]);
        $messageId = (int)db()->lastInsertId();
        admin_notify('message', 'New enquiry', $old['name'] . ': ' . $old['subject'], 'admin/messages.php');
        if (EMAIL_NOTIFY_CONTACT && email_smtp_configured() && email_mailer_available()) {
            $notificationSubject = 'Website enquiry: ' . $old['subject'];
            $notificationBody = "Website enquiry from {$old['name']} <{$old['email']}>\n\n{$old['message']}";
            $emailRecordId = null;
            if (table_exists('email_messages')) {
                try {
                    q('INSERT INTO email_messages
                        (direction, sender_email, sender_name, recipient_email, subject, body, status, contact_message_id, admin_id)
                        VALUES (?,?,?,?,?,?,?,?,?)',
                        [
                            'outgoing',
                            EMAIL_FROM_ADDRESS,
                            EMAIL_FROM_NAME,
                            EMAIL_FROM_ADDRESS,
                            $notificationSubject,
                            $notificationBody,
                            'queued',
                            $messageId,
                            null,
                        ]);
                    $emailRecordId = (int)db()->lastInsertId();
                } catch (PDOException $exception) {
                    error_log('HomeEase contact notification could not be queued: ' . $exception->getMessage());
                }
            }
            $notification = send_store_email(
                EMAIL_FROM_ADDRESS,
                EMAIL_FROM_NAME,
                $notificationSubject,
                $notificationBody,
                strtolower($old['email'])
            );
            if ($emailRecordId !== null) {
                try {
                    q('UPDATE email_messages SET status = ?, provider_message_id = ? WHERE id = ?', [
                        $notification['success'] ? 'sent_to_server' : $notification['state'],
                        $notification['success'] ? ($notification['message_id'] ?: null) : null,
                        $emailRecordId,
                    ]);
                } catch (PDOException $exception) {
                    error_log('HomeEase contact notification status could not be recorded: ' . $exception->getMessage());
                }
            }
            if (!$notification['success']) {
                error_log('HomeEase contact notification failed: ' . $notification['error']);
            }
        } elseif (EMAIL_NOTIFY_CONTACT) {
            error_log('HomeEase contact notification is enabled but SMTP or PHPMailer is not configured.');
        }
        $_SESSION['msg_times'][] = time();
        flash('success', 'Thank you! Your message has been received. We reply within one working day.');
        redirect('contact.php');
    }
}
$title = 'Contact & support';
require __DIR__ . '/includes/header.php';
?>
<h1>How can we help?</h1>
<div class="two-col">
  <div>
    <?php if ($errors): ?>
      <div class="alert error" role="alert"><ul><?php foreach ($errors as $er): ?><li><?= e($er) ?></li><?php endforeach; ?></ul></div>
    <?php endif; ?>
    <form method="post" action="<?= e(url('contact.php')) ?>" class="panel">
      <?= csrf_field() ?>
      <label>Your name <input name="name" required maxlength="120" value="<?= e($old['name']) ?>"></label>
      <label>Email <input type="email" name="email" required maxlength="160" value="<?= e($old['email']) ?>"></label>
      <label>Subject <input name="subject" required maxlength="160" value="<?= e($old['subject']) ?>"></label>
      <label>Message <textarea name="message" rows="5" required maxlength="2000"><?= e($old['message']) ?></textarea></label>
      <div class="hp" aria-hidden="true"><label>Leave blank <input name="website" tabindex="-1" autocomplete="off"></label></div>
      <button class="btn" type="submit">Send message</button>
    </form>
  </div>
  <div class="panel">
    <h2>Other ways to reach us</h2>
    <p><svg width="16" height="16" viewBox="0 0 24 24" aria-hidden="true" style="vertical-align:-1px;"><path d="M6.62 10.79c1.44-2.83 3.75-4.81 6.59-4.81 1.94 0 3.57 1.1 4.5 2.78.93-1.68 2.56-2.78 4.5-2.78 2.84 0 5.15 1.98 6.59 4.81L20 15H4zM12 17a3 3 0 1 0 0-6 3 3 0 0 0 0 6z"/></svg> <strong><?= e(SITE_PHONE) ?></strong><br><small>Mon to Sat, 8am to 6pm (EAT)</small></p>
    <p><svg width="16" height="16" viewBox="0 0 24 24" aria-hidden="true" style="vertical-align:-1px;"><path d="M22 6c0-1.1-.9-2-2-2H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16l5-6-5-6v-6zM12 20a4 4 0 1 0 0-8 4 4 0 0 0 0 8zm8-9h-2V5c0-1.1-.9-2-2-2h-4V3c0-1.1-.9-2-2-2H8c-1.1 0-2 .9-2 2v2H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c-1.1 0-2-.9-2-2z"/></svg> <a href="https://wa.me/<?= e(SITE_WHATSAPP) ?>" target="_blank" rel="noopener">Chat on WhatsApp</a></p>
    <p><svg width="16" height="16" viewBox="0 0 24 24" aria-hidden="true" style="vertical-align:-1px;"><path d="M22 6c0-1.1-.9-2-2-2H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2zM20 8l-8 5-8-5V2l8 5 8-5v6z"/></svg> <?= e(SITE_EMAIL) ?></p>
    <p><svg width="16" height="16" viewBox="0 0 24 24" aria-hidden="true" style="vertical-align:-1px;"><circle cx="1" cy="5" r="1"/><circle cx="4" cy="5" r="1"/><path d="M5 19H2l1-3.5A2 2 0 0 1 4.5 15H18a2 2 0 0 1 1.61.85l1.78 3.57A2 2 0 0 1 20.83 21H6.12"/></svg> <a href="<?= e(url('track.php')) ?>">Track an order</a></p>
    <p><svg width="16" height="16" viewBox="0 0 24 24" aria-hidden="true" style="vertical-align:-1px;"><path d="M11 9H2v2h9zm8 0h-9c-.6 0-1 .4-1 1v4c0 .6.4 1 1 1h9c.6 0 1-.4 1-1v-4c0-.6-.4-1-1-1zm-1 4H2V9h16v4z"/></svg> <a href="<?= e(url('faq.php')) ?>">Read the FAQ</a></p>
  </div>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>

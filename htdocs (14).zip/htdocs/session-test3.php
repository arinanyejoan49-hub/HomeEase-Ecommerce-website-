<?php
// TEMPORARY diagnostic v3. Open, refresh twice, read the result, then DELETE this file.
header('Content-Type: text/plain'); header('Cache-Control: no-store');
$hex = bin2hex(random_bytes(16));
$names = ['homeease_sid', 'homeease_sid2', 'he_session', 'PHPSESSID', 'sid', 'hex_value_test'];
// 1) same names, but with a short NON-hex value
foreach ($names as $n) { setcookie('v_' . $n, 'abc', ['path' => '/', 'httponly' => true, 'samesite' => 'Lax']); }
// 2) the real candidate names with a 32-hex value, like a session id
foreach ($names as $n) { setcookie($n, $hex, ['path' => '/', 'httponly' => true, 'samesite' => 'Lax']); }
echo "Refresh this page, then read the list. YES = the browser kept it.\n\n";
echo "-- 32-hex value (like a session id) --\n";
foreach ($names as $n) { printf("%-16s : %s\n", $n, isset($_COOKIE[$n]) ? 'YES' : 'NO'); }
echo "\n-- short value 'abc' --\n";
foreach ($names as $n) { printf("%-18s : %s\n", 'v_' . $n, isset($_COOKIE['v_' . $n]) ? 'YES' : 'NO'); }
echo "\nCookies the browser sent: " . implode(', ', array_keys($_COOKIE)) . "\n";
echo "\nSet-Cookie headers PHP sends: " . count(array_filter(headers_list(), fn($h) => stripos($h, 'Set-Cookie') === 0)) . "\n";

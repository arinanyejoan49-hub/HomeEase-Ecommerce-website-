-- Run once only on an existing customer database that predates remembered login.
ALTER TABLE users
  ADD COLUMN remember_token CHAR(64) NULL,
  ADD COLUMN remember_expires DATETIME NULL;

-- HomeEase sample data. Import AFTER schema.sql.
-- Safe to re-run: it clears the sample tables first (this also deletes any orders, so run it only on a fresh database).
SET NAMES utf8mb4;
DELETE FROM order_items;
DELETE FROM orders;
DELETE FROM products;
DELETE FROM categories;

INSERT INTO categories (id, name, slug, icon, description, sort_order) VALUES
(1, 'Kitchen Appliances', 'kitchen', '🍳', 'Small countertop appliances for everyday food prep.', 1),
(2, 'Cooking', 'cooking', '🔥', 'Hotplates, cookers and ovens for the kitchen.', 2),
(3, 'Fridges & Cooling', 'cooling', '❄️', 'Fridges, freezers and fans for cooling.', 3),
(4, 'Laundry & Cleaning', 'laundry', '🧺', 'Washers, irons and cleaning equipment.', 4),
(5, 'Student Essentials', 'student', '🎓', 'Bundles and essentials for hostel life.', 5),
(6, 'Lighting & Power', 'power', '💡', 'Lamps, extensions and power protection.', 6),
(7, 'Home Entertainment', 'entertainment', '📺', 'Televisions and audio for the living room.', 7),
(8, 'Cleaning Appliances', 'cleaning', '🧹', 'Vacuums and tools for a clean home.', 8),
(9, 'Home Comfort and Climate Control', 'climate', '🌬️', 'Fans and air conditioners for comfort.', 9),
(10, 'Home Security', 'security', '🔒', 'CCTV and safety devices.', 10),
(11, 'Smart Home Devices', 'smart-home', '🏠', 'Smart plugs and connected devices.', 11),
(12, 'Personal Care Appliances', 'personal-care', '🪮', 'Grooming and personal care devices.', 12),
(13, 'Water Dispensers and Purifiers', 'water', '💧', 'Dispensers and water purification.', 13),
(14, 'Home Office Electronics', 'home-office', '💻', 'Electronics for a home workspace.', 14),
(15, 'Home Furniture and Storage', 'furniture', '🛋️', 'Furniture and storage solutions.', 15),
(16, 'Home Decor and Accessories', 'decor', '🖼️', 'Decor and home accessories.', 16),
(17, 'Bedding and Mattresses', 'bedding', '🛏️', 'Mattresses and bedding.', 17),
(18, 'Household Tools and Maintenance', 'tools', '🔧', 'Tools for home maintenance.', 18),
(19, 'Outdoor and Garden Equipment', 'outdoor', '🌿', 'Outdoor and garden equipment.', 19),
(20, 'Power Backup and Solar Products', 'solar', '☀️', 'Solar and backup power products.', 20);

DELETE FROM faqs;
INSERT INTO faqs (question, answer, sort_order, is_published) VALUES
('Are your appliances genuine?', 'Yes. We source from authorised distributors and every appliance comes with a manufacturer or store warranty of 12 to 24 months, stated on each product page.', 1, 1),
('How long does delivery take?', 'Within Masaka City 1 to 2 working days, around Masaka 2 to 3 days and the rest of Uganda 3 to 6 days. See the Delivery page for fees and details.', 2, 1),
('What payment methods do you accept?', 'MTN or Airtel mobile money, card, or cash on delivery. On this demo site payments run in test mode, so no real money is taken.', 3, 1),
('Can I return an item?', 'Yes. Faulty or wrong items can be returned within 7 days of delivery. Unused items in original packaging can be returned within 7 days for a refund or exchange minus delivery cost. See Returns & warranty.', 4, 1),
('Do appliances work with Uganda power supply?', 'All items are rated for 220 to 240 V, 50 Hz, the Ugandan standard. We also sell surge-protected extensions and solar lamps for outages.', 5, 1),
('Is there a student discount?', 'Yes. Use code STUDENT10 in your cart for 10% off. Our Student Starter Bundle is also reduced.', 6, 1),
('Do you keep my card details?', 'No. Card details are checked and discarded. We keep only the last four digits for your receipt.', 7, 1);
INSERT INTO products (id, category_id, name, slug, brand, description, specs, price, old_price, stock, energy_rating, warranty_months, is_featured) VALUES
(1, 1, 'Electric Kettle 1.7L', 'electric-kettle-1-7l', 'Hisense', 'Fast-boil stainless steel kettle with auto shut-off and boil-dry protection. Perfect for tea, instant noodles and quick meals in a hostel room.', 'Capacity: 1.7 L\nPower: 1800 W\nAuto shut-off: Yes\nCord: 360° swivel base', 55000, 65000, 40, 'A', 12, 1),
(2, 1, 'Rice Cooker 1.8L', 'rice-cooker-1-8l', 'Von', 'Non-stick inner pot with keep-warm function. Cooks rice for 4 to 6 people and can also steam vegetables.', 'Capacity: 1.8 L\nPower: 700 W\nFunctions: Cook, keep warm\nIncludes: Measuring cup and spatula', 120000, NULL, 25, 'A', 12, 1),
(3, 1, 'Blender 1.5L with Grinder', 'blender-1-5l-grinder', 'Ramtons', 'Strong motor blender with a dry grinder jar for spices and groundnuts. Great for juices, smoothies and sauces.', 'Capacity: 1.5 L glass jar\nPower: 450 W\nSpeeds: 2 plus pulse\nExtra: Dry grinder jar', 135000, 150000, 18, 'B', 12, 1),
(4, 1, '2-Slice Toaster', '2-slice-toaster', 'Von', 'Browning control with a removable crumb tray. Toasts bread evenly in under two minutes.', 'Slots: 2\nPower: 750 W\nSettings: 6 browning levels\nExtras: Defrost and cancel', 75000, NULL, 30, 'B', 12, 0),
(5, 1, 'Microwave Oven 20L', 'microwave-oven-20l', 'Samsung', 'Compact microwave with 5 power levels and a 30-minute timer. Reheats and defrosts quickly.', 'Capacity: 20 L\nPower: 700 W\nControl: Dial\nTurntable: 245 mm', 380000, 420000, 12, 'A', 24, 1),
(6, 1, 'Air Fryer 4L', 'air-fryer-4l', 'Philips', 'Cook crispy chips, chicken and snacks with little or no oil. Digital temperature and timer control.', 'Capacity: 4 L\nPower: 1500 W\nTemperature: 80 to 200 °C\nTimer: 60 min', 280000, 320000, 10, 'A', 12, 1),
(7, 1, 'Sandwich Maker', 'sandwich-maker', 'Hisense', 'Non-stick plates make hot toasted sandwiches and chapati wraps in minutes.', 'Plates: Non-stick\nPower: 750 W\nIndicator lights: Power and ready', 70000, NULL, 22, 'B', 12, 0),
(8, 2, '2-Plate Electric Hotplate', '2-plate-electric-hotplate', 'Von', 'Two independent cooking plates with adjustable heat. A budget cooking solution for students and small kitchens.', 'Plates: 2 (1500 W each)\nControl: Thermostat knobs\nBody: Stainless steel', 85000, 95000, 28, 'B', 12, 1),
(9, 2, 'Table-top Gas Cooker 2 Burner', 'tabletop-gas-cooker-2-burner', 'Ramtons', 'Stainless steel gas cooker with auto-ignition. Works with standard LPG cylinders and is a good backup when power is off.', 'Burners: 2\nIgnition: Auto\nTop: Stainless steel\nGas: LPG', 150000, NULL, 15, '', 12, 0),
(10, 3, 'Mini Fridge 90L', 'mini-fridge-90l', 'Hisense', 'A compact single-door fridge with a small freezer box. Fits hostel rooms and uses little electricity.', 'Capacity: 90 L\nDoors: 1\nFreezer box: Yes\nHeight: 84 cm', 650000, 720000, 8, 'A', 24, 1),
(11, 3, 'Double Door Fridge 200L', 'double-door-fridge-200l', 'Samsung', 'Frost-free double-door fridge with a separate freezer. Suited to families that shop in bulk.', 'Capacity: 200 L\nDoors: 2\nDefrost: Frost-free\nCompressor: Inverter', 1350000, 1480000, 5, 'A+', 24, 1),
(12, 3, '16" Standing Fan', '16-inch-standing-fan', 'Ramtons', 'Three speed settings, adjustable height and oscillation. Keeps rooms cool at low running cost.', 'Blade: 16 inch\nSpeeds: 3\nHeight: Adjustable\nPower: 55 W', 95000, NULL, 35, 'A', 12, 0),
(13, 3, 'Rechargeable Fan with Light', 'rechargeable-fan-light', 'Sayona', 'Keeps running during power cuts. Built-in LED light and a USB phone charging port.', 'Battery: 4500 mAh\nRuntime: up to 8 hours\nLight: LED\nCharging: AC adapter', 130000, 150000, 20, 'A', 12, 1),
(14, 4, 'Semi-Automatic Washing Machine 7kg', 'semi-automatic-washing-machine-7kg', 'Hisense', 'Twin-tub washer and spinner. Saves time and effort for family laundry without needing a plumbed connection.', 'Wash capacity: 7 kg\nTubs: Twin\nTimer: 15 min wash\nBody: Plastic, rust-free', 780000, 850000, 6, 'A', 24, 1),
(15, 4, 'Steam Iron 2000W', 'steam-iron-2000w', 'Philips', 'Non-stick soleplate with a spray function. Gets uniforms and work clothes crisp quickly.', 'Power: 2000 W\nSoleplate: Non-stick\nWater tank: 250 ml\nFunctions: Steam, spray', 65000, NULL, 30, 'B', 12, 0),
(16, 4, 'Bagless Vacuum Cleaner', 'bagless-vacuum-cleaner', 'Ramtons', 'Lightweight vacuum with a washable filter. Cleans tiles, carpets and corners.', 'Power: 1400 W\nDust cup: 1.5 L\nCord: 5 m\nFilter: Washable', 220000, 245000, 9, 'B', 12, 0),
(17, 5, 'Student Starter Bundle', 'student-starter-bundle', 'HomeEase', 'Everything for a first hostel kitchen: electric kettle, 1-plate hotplate, non-stick pot and pan, and cutlery set. Save compared with buying separately.', 'Kettle 1.5 L\n1-plate hotplate\nPot and pan (non-stick)\nCutlery set (12 pieces)', 190000, 235000, 14, 'B', 12, 1),
(18, 5, 'Non-stick Cookware Set 7pc', 'non-stick-cookware-set-7pc', 'Tefal', 'Pots, a frying pan and lids that work on gas, hotplates and electric cookers. Easy to clean.', 'Pieces: 7\nCoating: Non-stick\nHandles: Heat resistant\nSuitable for: Gas and electric', 160000, 180000, 16, '', 12, 0),
(19, 6, 'Solar Rechargeable LED Lamp', 'solar-rechargeable-led-lamp', 'Sollatek', 'Studies and reading continue when the power goes. Charges from the sun or a USB cable and also charges a phone.', 'Light: 3 brightness levels\nBattery: 2200 mAh\nCharging: Solar or USB\nRuntime: up to 12 hours', 45000, 55000, 50, 'A', 12, 1),
(20, 6, '6-Way Surge Protected Extension', '6-way-surge-protected-extension', 'Sollatek', 'Protects appliances from voltage spikes. Master switch and a 3 m cable.', 'Sockets: 6\nCable: 3 m\nProtection: Surge and overload\nSwitch: Master', 35000, NULL, 60, '', 12, 0);

UPDATE products SET image = CASE slug
    WHEN 'microwave-oven-20l' THEN 'microwave-oven-20l-lifestyle.webp'
    WHEN 'air-fryer-4l' THEN 'air-fryer-4l-white.webp'
    WHEN 'double-door-fridge-200l' THEN 'double-door-fridge-200l.webp'
    WHEN '2-plate-electric-hotplate' THEN '2-plate-electric-hotplate.jpg'
    WHEN 'rechargeable-fan-light' THEN 'rechargeable-fan-light.webp'
    WHEN 'non-stick-cookware-set-7pc' THEN 'tefal-non-stick-cookware-set-7pc.webp'
    WHEN 'solar-rechargeable-led-lamp' THEN 'solar-rechargeable-led-lamp.webp'
    ELSE image
END
WHERE slug IN (
    'microwave-oven-20l', 'air-fryer-4l', 'double-door-fridge-200l',
    '2-plate-electric-hotplate', 'rechargeable-fan-light',
    'non-stick-cookware-set-7pc', 'solar-rechargeable-led-lamp'
);

INSERT INTO products (id, category_id, name, slug, brand, description, specs, price, old_price, stock, energy_rating, warranty_months, is_featured, image) VALUES
(21, 1, 'Mini Blender Personal', 'mini-blender-personal', '', 'A compact personal blender for smoothies and drinks on the go.', 'Type: Personal blender', 85000, NULL, 10, '', 12, 0, 'mini-blender-personal.webp'),
(22, 9, 'Air Cooler 20L', 'air-cooler-20l', '', 'A portable air cooler for keeping a room comfortable.', 'Capacity: 20 L', 350000, NULL, 10, '', 12, 0, 'air-cooler-20l.webp'),
(23, 4, 'Clothes Dryer 7kg', 'clothes-dryer-7kg', '', 'A 7 kg clothes dryer for household laundry.', 'Capacity: 7 kg', 550000, NULL, 10, '', 12, 0, ''),
(24, 1, 'Coffee Maker 12-Cup', 'coffee-maker-12-cup', '', 'A countertop coffee maker for home use.', 'Capacity: 12 cups', 150000, NULL, 10, '', 12, 0, 'coffee-maker-12-cup.webp'),
(25, 6, 'Desk Lamp LED', 'desk-lamp-led', '', 'An LED desk lamp for reading and workspace lighting.', 'Light source: LED', 45000, NULL, 10, '', 12, 0, 'desk-lamp-led.webp'),
(26, 1, 'Electric Deep Fryer 3L', 'electric-deep-fryer-3l', '', 'A countertop electric deep fryer for home cooking.', 'Capacity: 3 L', 250000, NULL, 10, '', 12, 0, 'electric-deep-fryer-3l.webp'),
(27, 1, 'Electric Griddle', 'electric-griddle', '', 'An electric griddle for countertop cooking.', '', 150000, NULL, 10, '', 12, 0, 'electric-griddle.webp'),
(28, 2, 'Electric Oven 30L', 'electric-oven-30l', '', 'A countertop electric oven for everyday cooking.', 'Capacity: 30 L', 320000, NULL, 10, '', 12, 0, 'electric-oven-30l.webp'),
(29, 1, 'Food Processor 2L', 'food-processor-2l', '', 'A food processor for preparing ingredients at home.', 'Capacity: 2 L', 250000, NULL, 10, '', 12, 0, ''),
(30, 4, 'Fully Automatic Washing Machine 8kg', 'fully-automatic-washing-machine-8kg', '', 'A fully automatic washing machine for household laundry.', 'Wash capacity: 8 kg', 1200000, NULL, 10, '', 12, 0, 'fully-automatic-washing-machine-8kg.webp'),
(31, 2, 'Gas Oven with Hob', 'gas-oven-with-hob', '', 'A gas oven with a hob for kitchen cooking.', '', 850000, NULL, 10, '', 12, 0, 'gas-oven-with-hob.webp'),
(32, 14, 'LED Ring Light with Stand', 'led-ring-light-with-stand', '', 'An LED ring light supplied with a stand for home-office use.', 'Light source: LED\nIncludes: Stand', 85000, NULL, 10, '', 12, 0, 'led-ring-light-with-stand.webp'),
(33, 6, 'Power Bank 20000mAh', 'power-bank-20000mah', '', 'A portable power bank for charging compatible devices.', 'Capacity: 20000 mAh', 75000, NULL, 10, '', 12, 0, 'power-bank-20000mah.webp'),
(34, 2, 'Pressure Cooker 6L', 'pressure-cooker-6l', '', 'A 6 L pressure cooker for preparing meals at home.', 'Capacity: 6 L', 180000, NULL, 10, '', 12, 0, 'pressure-cooker-6l.webp'),
(35, 3, 'Single Door Fridge 135L', 'single-door-fridge-135l', '', 'A 135 L single-door refrigerator for home or hostel use.', 'Capacity: 135 L\nDoors: 1', 750000, NULL, 10, '', 12, 0, 'single-door-fridge-135l.webp'),
(36, 8, 'Steam Mop', 'steam-mop', '', 'A steam mop for household floor cleaning.', '', 280000, NULL, 10, '', 12, 0, 'steam-mop.webp'),
(37, 13, 'Water Dispenser', 'water-dispenser', '', 'A water dispenser for home or office use.', '', 400000, NULL, 10, '', 12, 0, 'water-dispenser.webp'),
(38, 2, 'Nutrichef Non-stick Cookware Set', 'nutrichef-non-stick-cookware-set', 'Nutrichef', 'A non-stick cookware set for everyday kitchen use.', '', 250000, NULL, 10, '', 12, 0, 'nutrichef-blue-cookware-set.avif');

# HomeEase: affordable home appliances for students and families (Uganda)

Individual e-commerce project, BSIT 63102 Electronic Commerce, Uganda Martyrs University.
Stack: HTML, CSS, JavaScript, PHP 8 (PDO) and MySQL. No frameworks, no build step.

## Features
- Catalogue: 20 categories, 38 sample products with product-name-matched images, search, filters (category, brand, max price), sorting, product detail pages with specs and warranty
- Store and admin interfaces use a consistent orange, black, cream, and neutral palette
- Public-page sections, product cards, category cards, and panels reveal with a subtle animation as they enter the viewport; system reduced-motion preferences disable the effect.
- Homepage Popular Picks and Featured Products use the product `is_featured` flag. To change the handpicked products, open Admin > Products, edit a product, and toggle **Featured on home page**; products also need to be visible in the shop.
- Cart: add, change quantity, remove, coupon codes (STUDENT10, WELCOME5), delivery estimate; prices always read from the database
- Checkout: guest checkout; mobile money/card payment simulation and pay on delivery; stock is decremented inside a database transaction
- Order tracking by order number + email; order confirmation page
- Support: contact form (saved to DB, honeypot and rate limit), FAQ, WhatsApp button
- Admin (`/login.php`): shared sign-in redirects administrators to the dashboard and customers to their account; includes searchable product management, orders, customer accounts, support, returns, reports, and account settings
- Pages: delivery, returns and warranty, privacy, terms, sustainability and ethics, about
- Google Analytics 4, loaded only after the visitor accepts cookies
- New features: customer order history, forgot/reset password, DB-driven FAQ management, inventory management, payment management, reports & analytics.
- Admin email management: a unified website-enquiry and IMAP inbox, outgoing email, reply/forward, sent-message history and manual mailbox sync. SMTP/IMAP are optional and require configuration before use.
- New migrations in `database/migrations/`: `add_category_fields.sql`, `add_user_id_to_orders.sql`, `add_faqs_inventory.sql`, `add_return_refund_status.sql`, and `add_return_admin_reply.sql`. Apply a migration only if its schema change is not already present. The application adds `refund_status` and `admin_reply` to existing return-request tables automatically; if the database account cannot alter tables, import the matching migration using an account with ALTER permission.

## Product images

Public product photos belong in `assets/products/`; the `includes/` directory is blocked from direct web access. The shared `product_image_url()` helper resolves uploaded photos, product-name/slug matches, and known matching product families, then uses a local “image unavailable” SVG when there is no suitable photo. Appliance photos use `object-fit: contain`. Use descriptive filenames with ASCII letters, numbers, hyphens, and underscores; avoid emoji and other non-ASCII characters so Windows compressed folders can include the files. Originals are preserved in `includes/images/` and `includes/images/image-audit-originals/`. Homepage and Categories page cards use one curated representative image per category, with category imagery for furniture, decor and bedding. The product image audit is in `docs/product-image-audit.csv`. The KitchenPro food processor source image was renamed to `includes/images/kitchenpro-food-processor-2l.webp` for ZIP compatibility. The Clothes Dryer 7kg photo is sourced from [Wikimedia Commons](https://commons.wikimedia.org/wiki/File:Clothes_dryer_1_2018-09-29.jpg) by FASTILY and licensed under [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/). New sample product prices and stock are illustrative; confirm them before taking real orders.

The homepage carousel uses four locally stored lifestyle photographs in `assets/images/hero/` (home interior, kitchen, laundry room, and living room). Photos are from Unsplash and are locally hosted to avoid third-party image dependencies: [home interior](https://images.unsplash.com/photo-1600210492486-724fe5c67fb0), [kitchen](https://images.unsplash.com/photo-1556911220-bff31c812dba), [laundry room](https://images.unsplash.com/photo-1626806787461-102c1bfaaea1), and [living room](https://images.unsplash.com/photo-1600607687939-ce8a6c25118c). See the [Unsplash License](https://unsplash.com/license).

## Run locally (XAMPP / WAMP / Laragon)
1. Copy this folder into `htdocs` (for example `htdocs/homeease`).
2. In phpMyAdmin create a database `homeease` (collation `utf8mb4_general_ci`), then import `sql/schema.sql`. Import `sql/seed.sql` only into a new, empty database: it replaces sample catalogue and order data.
3. Copy nothing else: if your MySQL user is not `root` with an empty password, create `config.local.php`:
   ```php
   <?php
   define('DB_HOST', 'localhost');
   define('DB_NAME', 'homeease');
   define('DB_USER', 'root');
   define('DB_PASS', '');
   define('SITE_URL', 'http://localhost');
   define('APP_ENV', 'development');
   ```
4. Create an administrator from a private local console by running `php tools/create-admin.php "Store Administrator" admin@example.com`; enter and confirm a strong password when prompted. The password is not stored in the command or source files.
5. Open `http://localhost/homeease/`. All roles sign in at `http://localhost/homeease/login.php`; administrators go to `/admin/index.php`, and customers go to `/customer/dashboard.php`.

## Shared login and account recovery

The shared login at `/login.php` authenticates against the existing `admins` and `users` tables. An administrator is identified by an account in `admins`; customers are identified by an active account with `users.role = 'customer'`. Public registration always writes the customer role and cannot grant administrator access. The old `/admin/login.php` address redirects to the shared page. Existing admin and customer rows and password hashes are preserved.

The shared login background is stored as a random, validated image under `assets/uploads/`; its filename is kept in the `site_settings` table, which is created automatically and is included in `sql/schema.sql`. Only administrators can change it.

On an existing site, back up the `homeease` database before importing any migration. If customer-account tables are missing, import `database.sql` once; it creates missing customer tables and adds the nullable order link without deleting existing products or orders. If password reset tokens already existed before admin recovery was added, import `database/migrations/add_admin_password_resets.sql` once to preserve existing customer reset tokens and allow tokens for administrator accounts. This migration changes only the reset-token table. SMTP must be configured in `config.local.php` for reset links to be emailed. Only when `APP_ENV` is explicitly set to `development` on non-HTTPS can a local reset link be displayed; the default production configuration never exposes reset tokens in the response.

To create the first administrator safely, use the CLI setup script above. It inserts an account in `admins` and refuses to overwrite an existing account. Do not promote a customer or run a seed script on a database containing real store data.

## Deploy to free hosting (e.g. InfinityFree)
1. Create a hosting account and a MySQL database in the control panel; note the host name, database name, user and password.
2. Import `sql/schema.sql` using phpMyAdmin. Import `sql/seed.sql` only for a newly created, empty database; it replaces sample catalogue and order data.
3. Upload all files into `htdocs` with the File Manager or FTP. Create `config.local.php` there with your real database details and, when you have it, `define('GA_ID', 'G-XXXXXXX');`.
4. Make sure `assets/uploads` is writable (permission 755 or 775).
5. Enable the free SSL certificate in the panel, then add `define('FORCE_HTTPS', true);` to `config.local.php`.
6. Edit `SITE_EMAIL`, `SITE_PHONE`, `SITE_WHATSAPP` (put them in `config.local.php`).
7. Set `SITE_URL` to the HTTPS origin of the deployed website in `config.local.php` (for example `https://shop.example.com`); this is used to create valid password-reset links without trusting the request's Host header.
8. Create the first administrator through the host's private PHP CLI if available. If CLI access is unavailable, create the admin using a trusted database administrator and a PHP-generated `password_hash()`; never use a published default password.

For an existing installation created before customer accounts were added, select the existing `homeease` database in phpMyAdmin and import `database.sql` once. This adds the account-related tables and the nullable `orders.user_id` column without deleting store data. The application also adds that column automatically when it detects an older orders table. If your database account cannot alter tables, import `database/migrations/add_user_id_to_orders.sql` using a database account with ALTER permission. If customer accounts were already installed before remembered login was introduced, import `sql/customer-remember-login-upgrade.sql` once. To add the downloaded sample products to an existing catalogue without re-importing the destructive seed, import `database/migrations/add_downloaded_product_catalogue.sql` once.

To let signed-in customers send support messages from their dashboard and read admin replies there, apply `database/migrations/add_customer_email_messaging.sql` once after the customer-account and email-management tables are installed. This adds a nullable customer link to existing website messages without deleting enquiries. New customer messages appear in Admin > Emails > Inbox; administrators can reply from the message view, and the reply is shown in that customer’s dashboard. Return-request replies are shown in Customer > Returns & Refunds and generate an in-account notification. SMTP must be configured for email notifications to reach a customer’s mailbox; replies and notifications remain available in the account independently.

To correct existing product image references after deploying the descriptive image files, apply `database/migrations/fix_product_image_duplicates.sql` once. It updates only five image filename fields and does not change products, prices, stock, customers, orders, or other records.

## Admin email management

For an existing database, import `database/migrations/add_email_management.sql` once using phpMyAdmin. Fresh installations include the email tables in `sql/schema.sql`. Existing website contact enquiries remain in the `messages` table and appear alongside mail imported from the configured mailbox.

For Gmail, use `smtp.gmail.com` on port `587` with `tls` for SMTP, and `imap.gmail.com` on port `993` with `ssl` for IMAP. Set the username/from address to the full Gmail address. The current mailer uses an app password rather than OAuth: Google requires 2-Step Verification for app passwords, and the option may be unavailable for managed Workspace accounts. Google recommends “Sign in with Google” where a client supports it. Never use your normal Google sign-in password here.

Install the SMTP mailer from the project directory:

```powershell
composer install
```

In the ignored `config.local.php`, add the values supplied by the business email provider. Never put real credentials in the repository or database:

```php
define('EMAIL_FROM_ADDRESS', 'your-business-address@example.com');
define('EMAIL_FROM_NAME', 'HomeEase');
define('EMAIL_SMTP_HOST', 'smtp.gmail.com');
define('EMAIL_SMTP_PORT', 587);
define('EMAIL_SMTP_ENCRYPTION', 'tls'); // tls or ssl
define('EMAIL_SMTP_USERNAME', 'your-full-address@gmail.com');
define('EMAIL_SMTP_PASSWORD', 'your-app-password');
define('EMAIL_NOTIFY_CONTACT', true); // optional contact-form notifications
// Optional: only when local antivirus HTTPS/SMTP scanning intercepts TLS.
define('EMAIL_SMTP_CA_FILE', 'C:\\path\\outside\\the\\website\\to\\trusted-root.pem');

define('EMAIL_IMAP_HOST', 'imap.gmail.com');
define('EMAIL_IMAP_PORT', 993);
define('EMAIL_IMAP_ENCRYPTION', 'ssl'); // tls or ssl
define('EMAIL_IMAP_USERNAME', 'your-full-address@gmail.com');
define('EMAIL_IMAP_PASSWORD', 'your-app-password');
define('EMAIL_IMAP_MAILBOX', 'INBOX'); // optional
```

Use the exact host names, ports, and credentials given by the provider. `EMAIL_SMTP_CA_FILE` is optional and should point outside the website root to a PEM certificate authority file only if local antivirus TLS scanning causes certificate verification failures; normal certificate and hostname verification remain enabled. Enable IMAP access for the mailbox if required. The active WAMP PHP build must also have the IMAP extension enabled in its `php.ini`, followed by an Apache restart. Incoming email synchronization is manual from Admin > Emails > Email settings; the app does not run a background poller. Sending reports when the SMTP server accepts a message; it cannot confirm delivery.

## Running the disposable SQLite tests

The SQLite database is for automated testing only; the production application uses MySQL/MariaDB. From the project directory:

1. Build the disposable test database with `py -3 tests/build_sqlite.py`. The builder translates MySQL table options, auto-increment keys, and named unique constraints. It writes through a temporary file and refuses to replace a non-empty database unless `--force` is explicitly supplied.
2. Start the PHP development server in one terminal with `C:\wamp64\bin\php\php8.4.15\php.exe -d "auto_prepend_file=C:\wamp64\www\homeease\tests\sqlite_config.php" -S 127.0.0.1:8080 -t .`. This test-only configuration points to `tests/test.sqlite`; do not use it with a production database.
4. In a second terminal, install the `requests` Python package if it is not already available, then run `py -3 tests/e2e.py`.

The end-to-end script creates accounts and orders, changes test stock, and drops test-only tables when it finishes. Run it only against the disposable SQLite database, never against live or customer data. Importing `sql/seed.sql` also clears sample catalogue/order tables, so use it only on a fresh disposable database.

## Google Analytics (GA4)
1. analytics.google.com > create a property and a Web data stream with your live URL.
2. Copy the Measurement ID (G-...) into `config.local.php` as `GA_ID`.
3. Visit your site, click **Accept** on the cookie banner, then check Reports > Realtime.
4. After a few days of visits, report: users/visits, traffic sources (Acquisition), most-viewed pages (Engagement > Pages and screens). Take screenshots.

## Google sign-in ("Continue with Google")
1. console.cloud.google.com > create/select a project > **APIs & Services > OAuth consent screen** (External; add your app name, support email and your domain).
2. **Credentials > Create credentials > OAuth client ID > Web application.**
3. Under **Authorized redirect URIs** add exactly: `https://YOUR-DOMAIN/google-callback.php` (use `https`; add `http://localhost/google-callback.php` too for local testing).
4. Copy the Client ID and Client secret into `config.local.php`:
   `define('GOOGLE_CLIENT_ID', '....apps.googleusercontent.com');` and `define('GOOGLE_CLIENT_SECRET', '...');`
5. Reload the login page: the round Google button appears under the Log In form (and on the Create Account page).
6. When ready for the public, set the consent screen's publishing status to **In production**; until then only listed test users can sign in.

Notes: new customers are created from their Google name and verified email (no phone yet). An existing customer with the same verified email is linked to their Google account. The host must allow outgoing HTTPS (cURL) requests.

## Security measures (for your report)
- Prepared statements (PDO) everywhere: prevents SQL injection
- Output escaping with `htmlspecialchars` on every dynamic value: prevents XSS
- CSRF tokens on every POST form
- Passwords stored with `password_hash` (bcrypt), login rate limit (5 tries then 5 minute lock), session ID regenerated on login
- Card numbers are validated and discarded; only last 4 digits stored; payments are test mode
- Session cookies: HttpOnly, SameSite=Lax, Secure on HTTPS; security headers
- Image uploads checked by real image type and size, saved under random names, PHP execution blocked in the uploads folder
- Prices and stock are always taken from the database, never from the browser
- `.htaccess` blocks direct access to config, SQL and include files

## Folder map
`index.php`, `products.php`, `product.php`, `cart.php`, `checkout.php`, `order-success.php`, `track.php`, `contact.php`, `faq.php` and policy pages in the root; `admin/` back-office; `includes/` shared PHP; `assets/` CSS, JS, uploads; `sql/` database; `docs/` report drafts; `tests/` automated checks (`python3 tests/build_sqlite.py` then `python3 tests/e2e.py` against `php -S`).

## Version history
Use Git: `git init`, `git add .`, `git commit -m "message"` after each change, and push to GitHub for your repository link.

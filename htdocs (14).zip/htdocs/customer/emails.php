<?php
require __DIR__ . '/../includes/bootstrap.php';
require_customer();
require_once __DIR__ . '/../includes/email.php';

$title = 'Messages & Email';
$here = 'customer/emails.php';
$user = current_customer();
$hasCustomerLink = column_exists('messages', 'customer_id');
$hasEmailStorage = table_exists('email_messages');
$hasCustomerEmailLink = $hasEmailStorage && column_exists('email_messages', 'customer_id');
$errors = [];
$values = ['subject' => '', 'message' => '', 'email_subject' => '', 'email_body' => '', 'reply_to' => ''];
$takeRateLimitSlot = static function (): bool {
    $_SESSION['customer_email_times'] = array_values(array_filter(
        $_SESSION['customer_email_times'] ?? [],
        static fn($time) => $time > time() - 3600
    ));
    if (count($_SESSION['customer_email_times']) >= 5) {
        return false;
    }
    $_SESSION['customer_email_times'][] = time();
    return true;
};

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $action = post('action', 24);
    if ($action === 'send_email') {
        $values['email_subject'] = post('email_subject', 255);
        $values['email_body'] = post('email_body', 5000);
        $values['reply_to'] = post('reply_to', 12);
        if (!$hasCustomerEmailLink) {
            $errors[] = 'Customer email is not ready yet. Apply the customer email inbox database update first.';
        }
        if ($values['email_subject'] === '' || preg_match('/[\r\n]/', $values['email_subject'])) {
            $errors[] = 'Enter a valid email subject.';
        }
        if (mb_strlen($values['email_body']) < 10) {
            $errors[] = 'Write an email message of at least 10 characters.';
        }
        $replyTarget = false;
        $inReplyTo = null;
        if ($values['reply_to'] !== '' && $hasCustomerEmailLink) {
            $replyId = filter_var($values['reply_to'], FILTER_VALIDATE_INT);
            $replyTarget = $replyId
                ? q("SELECT id, subject, rfc_message_id, provider_message_id
                     FROM email_messages
                     WHERE id = ? AND customer_id = ?
                       AND (direction = 'outgoing' OR LOWER(sender_email) = LOWER(?))",
                    [(int)$replyId, (int)$user['id'], EMAIL_FROM_ADDRESS])->fetch()
                : false;
            if (!$replyTarget && $replyId) {
                $replyTarget = q("SELECT id, subject, rfc_message_id, provider_message_id
                                  FROM email_messages
                                  WHERE id = ? AND customer_id IS NULL
                                    AND contact_message_id IN (SELECT id FROM messages WHERE customer_id = ?)
                                    AND direction = 'outgoing'",
                    [(int)$replyId, (int)$user['id']])->fetch();
            }
            if (!$replyTarget) {
                $errors[] = 'The email you are replying to could not be found in your account.';
            } else {
                $inReplyTo = $replyTarget['rfc_message_id'] ?: $replyTarget['provider_message_id'];
                if (!is_string($inReplyTo) || preg_match('/^<[^<>\r\n]+>$/', $inReplyTo) !== 1) {
                    $inReplyTo = null;
                }
            }
        }
        if (!$errors && !$takeRateLimitSlot()) {
            $errors[] = 'You have sent several messages recently. Please wait before sending another.';
        }
        if (!$errors) {
            $customerName = trim($user['first_name'] . ' ' . $user['last_name']);
            $customerEmail = strtolower($user['email']);
            q('INSERT INTO email_messages
                (direction, sender_email, sender_name, recipient_email, subject, body, status, customer_id, in_reply_to)
                VALUES (?,?,?,?,?,?,?,?,?)',
                [
                    'incoming', $customerEmail, $customerName, EMAIL_FROM_ADDRESS,
                    $values['email_subject'], $values['email_body'], 'queued',
                    (int)$user['id'], $inReplyTo,
                ]);
            $emailId = (int)db()->lastInsertId();
            $result = send_store_email(
                EMAIL_FROM_ADDRESS,
                EMAIL_FROM_NAME,
                $values['email_subject'],
                $values['email_body'],
                $customerEmail,
                $inReplyTo
            );
            q('UPDATE email_messages SET status = ?, provider_message_id = ?, rfc_message_id = ? WHERE id = ?', [
                $result['success'] ? 'sent_to_server' : $result['state'],
                $result['success'] ? ($result['message_id'] ?: null) : null,
                $result['success'] ? ($result['message_id'] ?: null) : null,
                $emailId,
            ]);
            if ($result['success']) {
                flash('success', 'Your email was accepted by HomeEase’s mail server. Delivery is not confirmed.');
                redirect('customer/emails.php');
            }
            $errors[] = $result['error'];
        }
    } else {
        $values['subject'] = post('subject', 160);
        $values['message'] = post('message', 2000);
        if (!$hasCustomerLink) {
            $errors[] = 'Customer messaging is not ready yet. Please try again later.';
        }
        if ($values['subject'] === '' || preg_match('/[\r\n]/', $values['subject'])) {
            $errors[] = 'Enter a subject for your message.';
        }
        if (mb_strlen($values['message']) < 10) {
            $errors[] = 'Please write a message of at least 10 characters.';
        }
        if (!$errors && !$takeRateLimitSlot()) {
            $errors[] = 'You have sent several messages recently. Please wait before sending another.';
        }

        if (!$errors) {
            $customerName = trim($user['first_name'] . ' ' . $user['last_name']);
            $customerEmail = strtolower($user['email']);
            q('INSERT INTO messages (name, email, subject, message, status, customer_id) VALUES (?,?,?,?,?,?)', [
                $customerName,
                $customerEmail,
                $values['subject'],
                $values['message'],
                'new',
                (int)$user['id'],
            ]);
            $messageId = (int)db()->lastInsertId();

            if (EMAIL_NOTIFY_CONTACT && email_smtp_configured() && email_mailer_available()) {
                $notification = send_store_email(
                    EMAIL_FROM_ADDRESS,
                    EMAIL_FROM_NAME,
                    'Customer dashboard message: ' . $values['subject'],
                    "Customer message from {$customerName} <{$customerEmail}>\n\n{$values['message']}",
                    $customerEmail
                );
                if (!$notification['success']) {
                    error_log('HomeEase customer message notification failed for message ' . $messageId . ': ' . $notification['error']);
                }
            }

            flash('success', 'Your message has been sent to HomeEase Support. You can read our reply here.');
            redirect('customer/emails.php');
        }
    }
}

$messages = $hasCustomerLink
    ? q('SELECT id, subject, message, status, created_at FROM messages WHERE customer_id = ? ORDER BY created_at DESC LIMIT 100', [(int)$user['id']])->fetchAll()
    : [];
$repliesByMessage = [];
if ($hasCustomerLink && $hasEmailStorage && $messages) {
    $messageIds = array_map(static fn($message) => (int)$message['id'], $messages);
    $placeholders = implode(',', array_fill(0, count($messageIds), '?'));
    q("UPDATE email_messages SET is_read = 1
       WHERE direction = 'outgoing' AND is_read = 0 AND contact_message_id IN ($placeholders)", $messageIds);
    $replies = q("SELECT contact_message_id, sender_name, body, status, created_at
                  FROM email_messages
                  WHERE direction = 'outgoing' AND contact_message_id IN ($placeholders)
                  ORDER BY created_at", $messageIds)->fetchAll();
    foreach ($replies as $reply) {
        $repliesByMessage[(int)$reply['contact_message_id']][] = $reply;
    }
}
$customerEmails = [];
if ($hasCustomerEmailLink) {
    q("UPDATE email_messages SET is_read = 1
       WHERE customer_id = ? AND direction = 'outgoing' AND is_read = 0", [(int)$user['id']]);
    $customerEmails = q("SELECT id, direction, sender_email, sender_name, recipient_email, subject, body, status, provider_message_id, rfc_message_id, created_at
                         FROM email_messages
                         WHERE customer_id = ?
                            OR contact_message_id IN (SELECT id FROM messages WHERE customer_id = ?)
                         ORDER BY created_at DESC LIMIT 100", [(int)$user['id'], (int)$user['id']])->fetchAll();
}
$replyToEmail = filter_var($_GET['reply_to'] ?? null, FILTER_VALIDATE_INT);
if ($replyToEmail && $hasCustomerEmailLink) {
    $replyEmail = q("SELECT id, subject FROM email_messages
                     WHERE id = ? AND customer_id = ?
                       AND (direction = 'outgoing' OR LOWER(sender_email) = LOWER(?))",
        [(int)$replyToEmail, (int)$user['id'], EMAIL_FROM_ADDRESS])->fetch();
    if (!$replyEmail) {
        $replyEmail = q("SELECT id, subject FROM email_messages
                         WHERE id = ? AND customer_id IS NULL
                           AND contact_message_id IN (SELECT id FROM messages WHERE customer_id = ?)
                           AND direction = 'outgoing'",
            [(int)$replyToEmail, (int)$user['id']])->fetch();
    }
    if ($replyEmail) {
        $values['reply_to'] = (string)$replyEmail['id'];
        $values['email_subject'] = 'Re: ' . preg_replace('/^(Re:\s*)+/i', '', $replyEmail['subject']);
    }
}

require __DIR__ . '/../includes/header.php';
?>
<div class="customer-layout">
  <?php require __DIR__ . '/_sidebar.php'; ?>
  <main class="customer-email-page">
    <div class="section-head">
      <div><h1>Messages &amp; Email</h1><p class="muted">Contact HomeEase Support and follow replies in your account.</p></div>
    </div>
    <?php if (!$hasCustomerLink): ?>
      <div class="alert error" role="alert">Customer messaging needs its database update. Apply <code>database/migrations/add_customer_email_messaging.sql</code>.</div>
    <?php elseif (!$hasEmailStorage): ?>
      <div class="alert error" role="alert">Messages can be submitted, but replies need email storage. Apply <code>database/migrations/add_email_management.sql</code> first.</div>
    <?php endif; ?>
    <?php if ($errors): ?><div class="alert error" role="alert"><ul><?php foreach ($errors as $error): ?><li><?= e($error) ?></li><?php endforeach; ?></ul></div><?php endif; ?>

    <?php if (!$hasCustomerEmailLink): ?>
      <div class="alert error" role="alert">Email inbox is not installed yet. Apply <code>database/migrations/add_customer_email_inbox.sql</code> after the email management migration.</div>
    <?php else: ?>
      <section class="panel customer-email-compose" id="email-compose">
        <h2><?= $values['reply_to'] !== '' ? 'Reply to HomeEase' : 'Email HomeEase Support' ?></h2>
        <p class="muted">Emails are sent to HomeEase Support from the business mailbox. Replies sent to your account email appear here after the support inbox is synchronized.</p>
        <form method="post">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="send_email">
          <?php if ($values['reply_to'] !== ''): ?><input type="hidden" name="reply_to" value="<?= e($values['reply_to']) ?>"><?php endif; ?>
          <label>To <input type="email" value="<?= e(EMAIL_FROM_ADDRESS) ?>" readonly></label>
          <label>Subject <input name="email_subject" maxlength="255" required value="<?= e($values['email_subject']) ?>"></label>
          <label>Message <textarea name="email_body" rows="6" maxlength="5000" required><?= e($values['email_body']) ?></textarea></label>
          <button class="btn" type="submit"><?= $values['reply_to'] !== '' ? 'Send reply' : 'Send email' ?></button>
        </form>
      </section>

      <section class="customer-email-history" id="customer-email-inbox"
               data-sync-url="<?= e(url('customer/email-sync.php')) ?>"
               data-csrf="<?= e(csrf_token()) ?>">
        <h2>Your email inbox</h2>
        <p class="muted small" id="customer-email-sync-status" role="status" aria-live="polite">
          New email is checked automatically while this page is open.
        </p>
        <?php if (!$customerEmails): ?>
          <p class="empty">No emails are linked to your account yet. Send HomeEase Support a message using the form above.</p>
        <?php else: ?>
          <?php foreach (array_reverse($customerEmails) as $email): ?>
            <?php $fromSupport = $email['direction'] === 'outgoing' || strcasecmp($email['sender_email'], EMAIL_FROM_ADDRESS) === 0; ?>
            <article class="panel customer-email-thread">
              <div class="customer-email-thread-head">
                <div>
                  <h3><?= e($email['subject']) ?></h3>
                  <span class="muted"><?= $fromSupport ? 'From HomeEase Support' : 'From you' ?> · <?= e(date('j M Y, H:i', strtotime($email['created_at']))) ?></span>
                </div>
                <span class="pill <?= $email['status'] === 'sent_to_server' || $email['status'] === 'received' ? 'read' : 'pending' ?>">
                  <?= $email['status'] === 'sent_to_server' ? 'Accepted by mail server' : ($email['status'] === 'received' ? 'Received' : e(ucfirst(str_replace('_', ' ', $email['status'])))) ?>
                </span>
              </div>
              <div class="customer-email-message <?= $fromSupport ? 'from-support' : '' ?>">
                <strong><?= $fromSupport ? e($email['sender_name'] ?: 'HomeEase Support') : 'You' ?></strong>
                <p><?= nl2br(e($email['body'])) ?></p>
                <?php if ($email['status'] === 'sent_to_server'): ?><small>Email was accepted by the mail server; delivery is not confirmed.</small><?php endif; ?>
              </div>
              <?php if ($fromSupport): ?>
                <a class="btn small ghost customer-email-reply" href="<?= e(url('customer/emails.php?reply_to=' . (int)$email['id'] . '#email-compose')) ?>">Reply</a>
              <?php endif; ?>
            </article>
          <?php endforeach; ?>
        <?php endif; ?>
      </section>
      <script>
        (() => {
          const inbox = document.getElementById('customer-email-inbox');
          const status = document.getElementById('customer-email-sync-status');
          if (!inbox || !status) return;

          let syncing = false;
          const syncInbox = async () => {
            if (syncing || document.visibilityState !== 'visible') return;
            syncing = true;
            try {
              const response = await fetch(inbox.dataset.syncUrl, {
                method: 'POST',
                credentials: 'same-origin',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8' },
                body: new URLSearchParams({ csrf: inbox.dataset.csrf || '' })
              });
              const result = await response.json();
              if (!response.ok || !result.success) {
                status.textContent = result.error || 'Could not check for new email. Please try again later.';
                return;
              }
              if (result.added > 0 || result.delivery_failures > 0) {
                window.location.reload();
                return;
              }
              status.textContent = result.skipped
                ? 'Inbox is up to date. New email is checked automatically while this page is open.'
                : 'Inbox checked just now. New email is checked automatically while this page is open.';
            } catch {
              status.textContent = 'Could not check for new email. Check your connection and try again later.';
            } finally {
              syncing = false;
            }
          };

          syncInbox();
          window.setInterval(syncInbox, 60000);
          document.addEventListener('visibilitychange', () => {
            if (document.visibilityState === 'visible') syncInbox();
          });
        })();
      </script>
    <?php endif; ?>

    <?php if ($hasCustomerLink): ?>
      <section class="panel customer-email-compose">
        <h2>Send a message</h2>
        <p class="muted">We’ll respond here, and email you when outgoing email is configured.</p>
        <form method="post">
          <?= csrf_field() ?>
          <label>Subject <input name="subject" maxlength="160" required value="<?= e($values['subject']) ?>"></label>
          <label>Message <textarea name="message" rows="5" maxlength="2000" required><?= e($values['message']) ?></textarea></label>
          <button class="btn" type="submit">Send to HomeEase Support</button>
        </form>
      </section>

      <section class="customer-email-history">
        <h2>Your conversations</h2>
        <?php if (!$messages): ?>
          <p class="empty">You haven’t sent a message yet. Contact us using the form above.</p>
        <?php else: ?>
          <?php foreach ($messages as $message): ?>
            <article class="panel customer-email-thread">
              <div class="customer-email-thread-head">
                <div><h3><?= e($message['subject']) ?></h3><span class="muted">Sent <?= e(date('j M Y, H:i', strtotime($message['created_at']))) ?></span></div>
                <span class="pill <?= $repliesByMessage[(int)$message['id']] ?? false ? 'read' : 'pending' ?>"><?= !empty($repliesByMessage[(int)$message['id']]) ? 'Reply received' : 'Awaiting reply' ?></span>
              </div>
              <div class="customer-email-message">
                <strong>You</strong>
                <p><?= nl2br(e($message['message'])) ?></p>
              </div>
              <?php foreach ($repliesByMessage[(int)$message['id']] ?? [] as $reply): ?>
                <div class="customer-email-message from-support">
                  <strong><?= e($reply['sender_name'] ?: 'HomeEase Support') ?></strong>
                  <p><?= nl2br(e($reply['body'])) ?></p>
                  <small><?= e(date('j M Y, H:i', strtotime($reply['created_at']))) ?><?= $reply['status'] !== 'sent_to_server' ? ' · Email notification could not be sent; this reply is available in your account.' : '' ?></small>
                </div>
              <?php endforeach; ?>
            </article>
          <?php endforeach; ?>
        <?php endif; ?>
      </section>
    <?php endif; ?>
  </main>
</div>
<?php require __DIR__ . '/../includes/footer.php'; ?>

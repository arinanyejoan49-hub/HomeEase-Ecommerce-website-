<?php
require __DIR__ . '/../includes/bootstrap.php';
require_customer();
$title = 'Customer Support';
$here = 'customer/support.php';
$user = current_customer();
$errors = [];
$values = ['subject'=>'','message'=>'','order_no'=>''];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $values['subject'] = post('subject', 160);
    $values['message'] = post('message', 2000);
    $values['order_no'] = post('order_no', 24);
    if ($values['subject'] === '') $errors[] = 'Subject is required.';
    if ($values['message'] === '') $errors[] = 'Message is required.';
    if ($values['order_no'] !== '') {
        $order = table_exists('orders') && column_exists('orders', 'user_id')
            ? q('SELECT order_no FROM orders WHERE order_no = ? AND user_id = ?', [$values['order_no'], (int)$user['id']])->fetch()
            : false;
        if (!$order) $errors[] = 'That order number is not linked to your account.';
    }
    if (empty($errors) && table_exists('support_tickets')) {
        q('INSERT INTO support_tickets (user_id, subject, message, order_no) VALUES (?,?,?,?)',
            [(int)$user['id'], $values['subject'], $values['message'], $values['order_no'] ?: null]);
        admin_notify('support', 'New support ticket', trim(($user['first_name'] ?? '') . ' ' . ($user['last_name'] ?? '')) . ': ' . $values['subject'], 'admin/support.php');
        flash('success', 'Support request submitted.');
        redirect('customer/support.php');
    }
}
$tickets = table_exists('support_tickets') ? q('SELECT * FROM support_tickets WHERE user_id = ? ORDER BY created_at DESC', [(int)$user['id']])->fetchAll() : [];
require __DIR__ . '/../includes/header.php';
?>
<h1>Customer Support</h1>
<?php if ($errors): ?><div class="alert error"><ul><?php foreach($errors as $e) echo '<li>'.e($e).'</li>'; ?></ul></div><?php endif; ?>
<div class="panel" style="margin-bottom:18px;">
  <h2>New Request</h2>
  <form method="post" class="form-grid">
    <?= csrf_field() ?>
    <label class="full">Subject <input name="subject" required maxlength="160" value="<?= e($values['subject']) ?>"></label>
    <label>Order Number (optional) <input name="order_no" maxlength="24" value="<?= e($values['order_no']) ?>"></label>
    <label class="full">Message <textarea name="message" rows="4" required maxlength="2000"><?= e($values['message']) ?></textarea></label>
    <div class="full"><button class="btn" type="submit">Submit Request</button></div>
  </form>
</div>
<?php if (!$tickets): ?>
  <p class="muted">No support requests yet.</p>
<?php else: ?>
<div class="table-wrap">
<table class="data">
  <thead><tr><th>Date</th><th>Subject</th><th>Status</th><th>Reply</th></tr></thead>
  <tbody>
  <?php foreach ($tickets as $t): ?>
    <tr>
      <td><?= e(date('j M Y', strtotime($t['created_at']))) ?></td>
      <td><?= e($t['subject']) ?><?= $t['order_no'] ? '<br><small class="muted">Order: '.e($t['order_no']).'</small>' : '' ?></td>
      <td><span class="pill <?= e($t['status']) ?>"><?= e($t['status']) ?></span></td>
      <td><?= $t['admin_reply'] ? e($t['admin_reply']) : '<span class="muted">Awaiting response</span>' ?></td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>
</div>
<?php endif; ?>
<p><a class="btn small ghost" href="<?= e(url('customer/dashboard.php')) ?>">Back</a></p>
<?php require __DIR__ . '/../includes/footer.php'; ?>
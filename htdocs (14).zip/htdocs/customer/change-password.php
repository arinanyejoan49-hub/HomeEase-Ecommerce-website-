<?php
require __DIR__ . '/../includes/bootstrap.php';
require_customer();

$title = 'Change Password';
$desc = 'Update your account password.';
$here = 'customer/change-password.php';

$user = current_customer();
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();

    $current = $_POST['current_password'] ?? '';
    $new     = $_POST['new_password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';

    if (!password_verify($current, $user['password_hash'])) {
        $errors['current_password'] = 'Current password is incorrect.';
    }
    if ($new === '') { $errors['new_password'] = 'New password is required.'; }
    elseif (strlen($new) < 8) { $errors['new_password'] = 'Password must be at least 8 characters.'; }
    elseif (!preg_match('/[A-Z]/', $new)) { $errors['new_password'] = 'Password must contain at least one uppercase letter.'; }
    elseif (!preg_match('/[a-z]/', $new)) { $errors['new_password'] = 'Password must contain at least one lowercase letter.'; }
    elseif (!preg_match('/[0-9]/', $new)) { $errors['new_password'] = 'Password must contain at least one number.'; }
    if ($new !== '' && $new === $current) { $errors['new_password'] = 'New password must be different from current password.'; }
    if ($confirm === '') { $errors['confirm_password'] = 'Please confirm your new password.'; }
    elseif ($confirm !== $new) { $errors['confirm_password'] = 'Passwords do not match.'; }

    if (empty($errors)) {
        try {
            q('UPDATE users SET password_hash = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?',
                [password_hash($new, PASSWORD_DEFAULT), (int)$user['id']]);
            flash('success', 'Password changed successfully.');
            redirect('customer/dashboard.php');
        } catch (Throwable $e) {
            error_log('Password change failed: ' . $e->getMessage());
            $errors['_general'] = 'Password change failed. Please try again.';
        }
    }
}
require __DIR__ . '/../includes/header.php';
?>
<h1>Change Password</h1>
<p class="lead">Update your account password.</p>

<?php if (!empty($errors['_general'])): ?>
  <div class="alert error" role="alert"><?= e($errors['_general']) ?></div>
<?php endif; ?>

<form method="post" class="auth-form" novalidate>
  <?= csrf_field() ?>

  <div class="form-field">
    <label for="current_password">Current Password <span class="required">*</span></label>
    <div class="password-input">
      <input type="password" id="current_password" name="current_password"
             placeholder="••••••••"
             <?= isset($errors['current_password']) ? 'aria-invalid="true"' : '' ?>>
      <button type="button" class="toggle-password" aria-label="Show/hide password">👁️</button>
    </div>
    <?php if (isset($errors['current_password'])): ?><span class="field-error"><?= e($errors['current_password']) ?></span><?php endif; ?>
  </div>

  <div class="form-field">
    <label for="new_password">New Password <span class="required">*</span></label>
    <div class="password-input">
      <input type="password" id="new_password" name="new_password" minlength="8"
             placeholder="••••••••"
             <?= isset($errors['new_password']) ? 'aria-invalid="true"' : '' ?>>
      <button type="button" class="toggle-password" aria-label="Show/hide password">👁️</button>
    </div>
    <div id="password-strength" class="strength-meter"></div>
    <?php if (isset($errors['new_password'])): ?><span class="field-error"><?= e($errors['new_password']) ?></span><?php endif; ?>
  </div>

  <div class="form-field">
    <label for="confirm_password">Confirm New Password <span class="required">*</span></label>
    <div class="password-input">
      <input type="password" id="confirm_password" name="confirm_password" minlength="8"
             placeholder="••••••••"
             <?= isset($errors['confirm_password']) ? 'aria-invalid="true"' : '' ?>>
      <button type="button" class="toggle-password" aria-label="Show/hide password">👁️</button>
    </div>
    <?php if (isset($errors['confirm_password'])): ?><span class="field-error"><?= e($errors['confirm_password']) ?></span><?php endif; ?>
  </div>

  <div class="form-actions">
    <a class="btn small ghost" href="<?= e(url('customer/dashboard.php')) ?>">Cancel</a>
    <button type="submit" class="btn">Change Password</button>
  </div>
</form>

<?php require __DIR__ . '/../includes/footer.php'; ?>
<?php
require __DIR__ . '/../includes/bootstrap.php';
require_customer();
require __DIR__ . '/../includes/card.php';
$title = 'My Dashboard';
$here = 'customer/dashboard.php';
$user = current_customer();
$orderCount = 0; $pendingCount = 0; $deliveredCount = 0;
if (table_exists('orders') && column_exists('orders', 'user_id')) {
    $orderCount = (int)q('SELECT COUNT(*) FROM orders WHERE user_id = ?', [(int)$user['id']])->fetchColumn();
    $pendingCount = (int)q("SELECT COUNT(*) FROM orders WHERE user_id = ? AND status IN ('pending','confirmed','processing')", [(int)$user['id']])->fetchColumn();
    $deliveredCount = (int)q("SELECT COUNT(*) FROM orders WHERE user_id = ? AND status = 'delivered'", [(int)$user['id']])->fetchColumn();
}
$wishlistCount = wishlist_count();
$recentOrders = table_exists('orders') && column_exists('orders', 'user_id')
    ? q('SELECT * FROM orders WHERE user_id = ? ORDER BY id DESC LIMIT 5', [(int)$user['id']])->fetchAll()
    : [];
$unreadNotifs = 0;
if (table_exists('notifications')) {
    $unreadNotifs = (int)q('SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0', [(int)$user['id']])->fetchColumn();
}
$recommended = q('SELECT p.*, c.icon FROM products p JOIN categories c ON c.id = p.category_id WHERE p.is_active = 1 ORDER BY p.is_featured DESC, p.id DESC LIMIT 4')->fetchAll();
require __DIR__ . '/../includes/header.php';
?>
<div class="customer-layout">
  <?php require __DIR__ . '/_sidebar.php'; ?>
  <div>
<p class="lead">Welcome, <?= e($user['first_name'] . ' ' . $user['last_name']) ?>. Manage your account, orders, and shopping from here.</p>
<div class="stat-grid" style="margin-bottom:18px;">
  <div class="stat orders"><div class="stat-body"><span>Total Orders</span><b><?= $orderCount ?></b></div></div>
  <div class="stat"><div class="stat-body"><span>Pending</span><b><?= $pendingCount ?></b></div></div>
  <div class="stat customers"><div class="stat-body"><span>Delivered</span><b><?= $deliveredCount ?></b></div></div>
  <div class="stat products"><div class="stat-body"><span>Wishlist</span><b><?= $wishlistCount ?></b></div></div>
</div>
<div class="dashboard-grid">
  <section class="panel wide">
    <h2>Recent Orders</h2>
    <?php if (!$recentOrders): ?>
      <p class="muted">No orders yet. <a href="<?= e(url('products.php')) ?>">Start shopping</a>.</p>
    <?php else: ?>
    <div class="table-wrap"><table class="data">
      <thead><tr><th>Order</th><th>Date</th><th>Total</th><th>Status</th><th></th></tr></thead>
      <tbody>
      <?php foreach ($recentOrders as $o): ?>
        <tr>
          <td><a href="<?= e(url('customer/order.php?id=' . $o['id'])) ?>"><?= e($o['order_no']) ?></a></td>
          <td><?= e(date('j M Y', strtotime($o['created_at']))) ?></td>
          <td><?= e(money($o['total'])) ?></td>
          <td><span class="pill <?= e($o['status']) ?>"><?= e(order_statuses()[$o['status']] ?? $o['status']) ?></span></td>
          <td><a class="btn small" href="<?= e(url('customer/order.php?id=' . $o['id'])) ?>">View</a></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table></div>
    <?php endif; ?>
  </section>
  <section class="panel">
    <h2>Quick Actions</h2>
    <div style="display:flex; flex-direction:column; gap:8px;">
      <a class="btn" href="<?= e(url('products.php')) ?>">Shop Now</a>
      <a class="btn small ghost" href="<?= e(url('customer/orders.php')) ?>">My Orders</a>
      <a class="btn small ghost" href="<?= e(url('customer/addresses.php')) ?>">Addresses</a>
      <a class="btn small ghost" href="<?= e(url('customer/wishlist.php')) ?>">Wishlist</a>
      <a class="btn small ghost" href="<?= e(url('customer/notifications.php')) ?>">Notifications (<?= $unreadNotifs ?>)</a>
      <a class="btn small ghost" href="<?= e(url('customer/reviews.php')) ?>">Reviews</a>
      <a class="btn small ghost" href="<?= e(url('customer/returns.php')) ?>">Returns</a>
      <a class="btn small ghost" href="<?= e(url('customer/support.php')) ?>">Support</a>
      <a class="btn small ghost" href="<?= e(url('customer/emails.php')) ?>">Messages &amp; Email<?= $unreadCustomerReplies ? ' (' . $unreadCustomerReplies . ' new)' : '' ?></a>
      <a class="btn small ghost" href="<?= e(url('customer/recently-viewed.php')) ?>">Recently Viewed</a>
      <a class="btn small ghost" href="<?= e(url('customer/settings.php')) ?>">Settings</a>
    </div>
  </section>
</div>
<section class="panel" style="margin-top:18px;">
  <h2>Recommended Products</h2>
  <div class="grid"><?php foreach ($recommended as $p) product_card($p); ?></div>
</section>
<p style="margin-top:18px;">
  <a class="btn small ghost" href="<?= e(url('customer/edit-profile.php')) ?>">Edit Profile</a>
  <a class="btn small ghost" href="<?= e(url('customer/change-password.php')) ?>">Change Password</a>
  <a class="btn small danger" href="<?= e(url('logout.php')) ?>">Logout</a>
</p>
</div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
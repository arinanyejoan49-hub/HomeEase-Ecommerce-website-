<?php
require __DIR__ . '/../includes/bootstrap.php';
require_customer();
$title = 'My Addresses';
$here = 'customer/addresses.php';
$user = current_customer();
$errors = [];
$values = ['recipient_name'=>'','phone'=>'','district'=>'','town'=>'','address'=>'','landmark'=>'','instructions'=>'','is_default'=>0];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $action = post('action', 20);
    if ($action === 'delete') {
        $id = (int)($_POST['id'] ?? 0);
        q('DELETE FROM customer_addresses WHERE id = ? AND user_id = ?', [$id, (int)$user['id']]);
        flash('success', 'Address deleted.');
        redirect('customer/addresses.php');
    }
    if ($action === 'default') {
        $id = (int)($_POST['id'] ?? 0);
        q('UPDATE customer_addresses SET is_default = 0 WHERE user_id = ?', [(int)$user['id']]);
        q('UPDATE customer_addresses SET is_default = 1 WHERE id = ? AND user_id = ?', [$id, (int)$user['id']]);
        flash('success', 'Default address updated.');
        redirect('customer/addresses.php');
    }
    $id = (int)($_POST['id'] ?? 0);
    $values['recipient_name'] = post('recipient_name', 120);
    $values['phone'] = post('phone', 30);
    $values['district'] = post('district', 100);
    $values['town'] = post('town', 100);
    $values['address'] = post('address', 255);
    $values['landmark'] = post('landmark', 255);
    $values['instructions'] = post('instructions', 500);
    $values['is_default'] = isset($_POST['is_default']) ? 1 : 0;
    if ($values['recipient_name'] === '') $errors[] = 'Recipient name is required.';
    if ($values['phone'] === '') $errors[] = 'Phone is required.';
    if ($values['district'] === '') $errors[] = 'District is required.';
    if ($values['town'] === '') $errors[] = 'Town is required.';
    if ($values['address'] === '') $errors[] = 'Address is required.';
    if (empty($errors)) {
        if ($values['is_default']) q('UPDATE customer_addresses SET is_default = 0 WHERE user_id = ?', [(int)$user['id']]);
        if ($id > 0) {
            q('UPDATE customer_addresses SET recipient_name=?,phone=?,district=?,town=?,address=?,landmark=?,instructions=?,is_default=? WHERE id=? AND user_id=?',
                [$values['recipient_name'],$values['phone'],$values['district'],$values['town'],$values['address'],$values['landmark'],$values['instructions'],$values['is_default'],$id,(int)$user['id']]);
            flash('success','Address updated.');
        } else {
            q('INSERT INTO customer_addresses (user_id,recipient_name,phone,district,town,address,landmark,instructions,is_default) VALUES (?,?,?,?,?,?,?,?,?)',
                [(int)$user['id'],$values['recipient_name'],$values['phone'],$values['district'],$values['town'],$values['address'],$values['landmark'],$values['instructions'],$values['is_default']]);
            flash('success','Address added.');
        }
        redirect('customer/addresses.php');
    }
}
$editId = (int)($_GET['edit'] ?? 0);
if ($editId && empty($errors)) {
    $row = q('SELECT * FROM customer_addresses WHERE id = ? AND user_id = ?', [$editId, (int)$user['id']])->fetch();
    if ($row) {
        foreach (['recipient_name','phone','district','town','address','landmark','instructions'] as $k) $values[$k] = $row[$k];
        $values['is_default'] = (int)$row['is_default'];
    } else $editId = 0;
}
$addresses = table_exists('customer_addresses') ? q('SELECT * FROM customer_addresses WHERE user_id = ? ORDER BY is_default DESC, id DESC', [(int)$user['id']])->fetchAll() : [];
require __DIR__ . '/../includes/header.php';
?>
<h1>My Addresses</h1>
<?php if ($errors): ?><div class="alert error"><ul><?php foreach($errors as $e) echo '<li>'.e($e).'</li>'; ?></ul></div><?php endif; ?>
<div class="panel" style="margin-bottom:18px;">
  <h2><?= $editId ? 'Edit Address' : 'Add Address' ?></h2>
  <form method="post" class="form-grid">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="save">
    <input type="hidden" name="id" value="<?= (int)$editId ?>">
    <label>Recipient Name <input name="recipient_name" required maxlength="120" value="<?= e($values['recipient_name']) ?>"></label>
    <label>Phone <input name="phone" required maxlength="30" value="<?= e($values['phone']) ?>"></label>
    <label>District <input name="district" required maxlength="100" value="<?= e($values['district']) ?>"></label>
    <label>Town <input name="town" required maxlength="100" value="<?= e($values['town']) ?>"></label>
    <label class="full">Address <textarea name="address" rows="2" required maxlength="255"><?= e($values['address']) ?></textarea></label>
    <label class="full">Landmark <input name="landmark" maxlength="255" value="<?= e($values['landmark']) ?>"></label>
    <label class="full">Instructions <textarea name="instructions" rows="2" maxlength="500"><?= e($values['instructions']) ?></textarea></label>
    <label class="check"><input type="checkbox" name="is_default" <?= $values['is_default']?'checked':'' ?>> Default</label>
    <div class="full"><button class="btn" type="submit"><?= $editId?'Update':'Add' ?> Address</button>
      <?php if ($editId): ?><a class="btn ghost" href="<?= e(url('customer/addresses.php')) ?>">Cancel</a><?php endif; ?></div>
  </form>
</div>
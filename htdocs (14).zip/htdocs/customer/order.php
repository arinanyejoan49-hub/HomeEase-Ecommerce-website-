<?php
require __DIR__ . '/../includes/bootstrap.php';
require_customer();

$title = 'Order details';
$here = 'customer/order.php';

$user = current_customer();
$id = (int)($_GET['id'] ?? 0);
$order = null;
$items = [];
if ($id > 0 && table_exists('orders') && column_exists('orders', 'user_id')) {
    $order = q('SELECT * FROM orders WHERE id = ? AND user_id = ?', [$id, (int)$user['id']])->fetch() ?: null;
    if ($order) {
        $items = q('SELECT oi.*, p.slug, p.image FROM order_items oi LEFT JOIN products p ON p.id = oi.product_id WHERE oi.order_id = ? ORDER BY oi.id', [$id])->fetchAll();
    }
}

require __DIR__ . '/../includes/header.php';
if (!$order) {
    echo '<div class="alert error">Order not found.</div>';
    echo '<p><a class="btn" href="' . e(url('customer/orders.php')) . '">Back to orders</a></p>';
    require __DIR__ . '/../includes/footer.php';
    exit;
}
$zone = ZONES[$order['zone']] ?? ['Delivery', 0, ''];
?>
<h1>Order <?= e($order['order_no']) ?></h1>
<p>Placed <?= e(date('j M Y, H:i', strtotime($order['created_at']))) ?></p>
<div class="two-col">
  <div class="panel">
    <h2>Items</h2>
    <ul class="mini-items">
      <?php foreach ($items as $i): ?>
      <li class="order-item">
        <span class="order-item-product"><?= product_media($i, 'order-item-image') ?><span><?= e($i['name']) ?> × <?= (int)$i['qty'] ?></span></span>
        <b class="order-item-price"><?= e(money($i['price'] * $i['qty'])) ?></b>
      </li>
      <?php endforeach; ?>
    </ul>
    <dl class="totals">
      <div><dt>Subtotal</dt><dd><?= e(money($order['subtotal'])) ?></dd></div>
      <?php if ($order['discount']): ?><div class="good"><dt>Discount (<?= e($order['coupon']) ?>)</dt><dd>-<?= e(money($order['discount'])) ?></dd></div><?php endif; ?>
      <div><dt>Delivery</dt><dd><?= $order['delivery_fee'] ? e(money($order['delivery_fee'])) : 'Free' ?></dd></div>
      <div class="grand"><dt>Total</dt><dd><?= e(money($order['total'])) ?></dd></div>
    </dl>
  </div>
  <div class="panel">
    <h2>Details</h2>
    <p><b>Status:</b> <span class="pill <?= e($order['status']) ?>"><?= e(order_statuses()[$order['status']] ?? $order['status']) ?></span></p>
    <p><b>Payment:</b> <?= e($order['payment_method']) ?> · <?= e(payment_status_label($order['payment_status'])) ?><?= $order['payment_ref'] ? ' · ref ' . e(payment_reference_label($order['payment_ref'])) : '' ?><?= $order['card_last4'] ? ' · card ending ' . e($order['card_last4']) : '' ?></p>
    <p><b>Delivery:</b> <?= e($zone[0]) ?>, <?= e($zone[2]) ?></p>
    <p><b>To:</b> <?= e($order['address']) ?></p>
    <?php if ($order['notes']): ?><p><b>Notes:</b> <?= e($order['notes']) ?></p><?php endif; ?>
    <p><a class="btn small" href="<?= e(url('track.php')) ?>">Track order</a><?php if (receipt_is_paid($order)): ?> <a class="btn small ghost" href="<?= e(receipt_url($order)) ?>">View receipt</a><?php endif; ?></p>
  </div>
</div>
<p><a class="btn small ghost" href="<?= e(url('customer/orders.php')) ?>">Back to orders</a></p>
<?php require __DIR__ . '/../includes/footer.php'; ?>
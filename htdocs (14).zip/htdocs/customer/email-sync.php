<?php
require __DIR__ . '/../includes/bootstrap.php';
require_customer();
require_once __DIR__ . '/../includes/email.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed.']);
    exit;
}

$sentToken = $_POST['csrf'] ?? '';
$knownToken = $_SESSION['csrf'] ?? '';
if (!is_string($sentToken) || $knownToken === '' || !hash_equals($knownToken, $sentToken)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'The session has expired. Refresh the page and try again.']);
    exit;
}

if (!table_exists('email_messages') || !table_exists('email_sync_state')
    || !column_exists('email_messages', 'customer_id')) {
    http_response_code(503);
    echo json_encode(['success' => false, 'error' => 'Customer email synchronization is not available until the inbox database update is installed.']);
    exit;
}

$result = email_sync_imap_if_due();
if (!$result['success']) {
    http_response_code(503);
    echo json_encode(['success' => false, 'error' => $result['error']]);
    exit;
}

echo json_encode([
    'success' => true,
    'skipped' => (bool)($result['skipped'] ?? false),
    'added' => (int)($result['added'] ?? 0),
    'delivery_failures' => (int)($result['delivery_failures'] ?? 0),
]);

<?php
require __DIR__ . '/../includes/bootstrap.php';
require_customer();
$title = 'Notifications';
$here = 'customer/notifications.php';
$user = current_customer();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $action = post('action', 20);
    if ($action === 'read') {
        $id = (int)($_POST['id'] ?? 0);
        q('UPDATE notifications SET is_read = 1 WHERE id = ? AND user_id = ?', [$id, (int)$user['id']]);
    } elseif ($action === 'readall') {
        q('UPDATE notifications SET is_read = 1 WHERE user_id = ?', [(int)$user['id']]);
    } elseif ($action === 'delete') {
        $id = (int)($_POST['id'] ?? 0);
        q('DELETE FROM notifications WHERE id = ? AND user_id = ?', [$id, (int)$user['id']]);
    }
    redirect('customer/notifications.php');
}
$notifs = table_exists('notifications') ? q('SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 100', [(int)$user['id']])->fetchAll() : [];
$unread = 0;
foreach ($notifs as $n) { if (!$n['is_read']) $unread++; }
require __DIR__ . '/../includes/header.php';
?>
<h1>Notifications</h1>
<p class="muted"><?= $unread ?> unread.</p>
<form method="post" class="inline" style="margin-bottom:12px;">
  <?= csrf_field() ?><input type="hidden" name="action" value="readall">
  <button class="btn small ghost" type="submit">Mark all as read</button>
</form>
<?php if (!$notifs): ?>
  <p class="muted">No notifications yet.</p>
<?php else: ?>
  <div class="panel">
  <?php foreach ($notifs as $n): ?>
    <article class="msg <?= $n['is_read'] ? '' : 'unread' ?>" style="padding:12px 16px; border-bottom:1px solid var(--line);">
      <header><b><?= e($n['title']) ?></b> <small class="muted"><?= e(date('j M Y, H:i', strtotime($n['created_at']))) ?></small></header>
      <p><?= e($n['message']) ?></p>
      <?php if ($n['link']): ?><p><a class="btn small" href="<?= e(url($n['link'])) ?>">View</a></p><?php endif; ?>
      <form method="post" class="inline" style="display:inline;">
        <?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$n['id'] ?>">
        <?php if (!$n['is_read']): ?><button class="btn small ghost" name="action" value="read" type="submit">Mark read</button><?php endif; ?>
        <button class="btn small danger" name="action" value="delete" type="submit">Delete</button>
      </form>
    </article>
  <?php endforeach; ?>
  </div>
<?php endif; ?>
<p><a class="btn small ghost" href="<?= e(url('customer/dashboard.php')) ?>">Back</a></p>
<?php require __DIR__ . '/../includes/footer.php'; ?>
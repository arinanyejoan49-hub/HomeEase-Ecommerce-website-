<?php
require __DIR__ . '/includes/bootstrap.php';
$title = 'Privacy policy';
require __DIR__ . '/includes/header.php';
?>
<h1>Privacy policy</h1>
<p class="muted">Last updated <?= e(date('j F Y')) ?>. We handle personal data in line with Uganda's Data Protection and Privacy Act, 2019.</p>
<h2>What we collect</h2>
<ul>
  <li><b>Order details:</b> name, email, phone number and delivery address, so we can deliver and support your order.</li>
  <li><b>Messages</b> you send through the contact form.</li>
  <li><b>Payment information:</b> we record only the payment method, status, reference and, for cards, the last four digits. Full card numbers and security codes are never stored.</li>
  <li><b>Sign in with Google:</b> if you choose it, Google shares your name and verified email address with us. We never receive your Google password.</li>
  <li><b>Usage data</b> through Google Analytics, only if you accept analytics cookies.</li>
</ul>
<h2>How we use it</h2>
<p>To process and deliver orders, give support and warranty service, prevent fraud and meet legal obligations. We do not sell your data.</p>
<h2>Who we share it with</h2>
<p>Delivery riders and couriers (name, phone and address only), payment providers, and Google (analytics, if you consent). Nobody else unless the law requires it.</p>
<h2>Cookies</h2>
<p>A session cookie keeps your cart and secure checkout working. Analytics cookies are used only after you click Accept on the cookie notice. You can change your choice by clearing this site's cookies.</p>
<h2>Security</h2>
<p>Passwords are hashed, database queries are parameterised, forms are protected against forgery, and the live site is served over HTTPS where the host supports it.</p>
<h2>Your rights</h2>
<p>You may ask to see, correct or delete your personal data. Contact us at <?= e(SITE_EMAIL) ?> and we will respond within 30 days. We keep order records for as long as needed for warranty and accounting.</p>
<?php require __DIR__ . '/includes/footer.php'; ?>

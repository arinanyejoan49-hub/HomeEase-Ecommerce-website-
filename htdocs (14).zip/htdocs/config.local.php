<?php
    define('PESAJET_API_KEY', 'pk_3878e3b7ff6259573b168beab2eb0e71b72124ed2d551559');
define('PESAJET_WEBHOOK_SECRET', 'whsec_b7a64ccf3a24fdb2b772f2a7d16bbb4e39ef110ed7c8fc6d');
// Local-only Gmail settings. This file is ignored by Git.
// Add the Google app password locally after enabling 2-Step Verification.

define('SITE_EMAIL', 'arinanyejoan85@gmail.com');
define('SITE_PHONE', '0793797709');
define('SITE_WHATSAPP', '256760348245');
define('EMAIL_FROM_ADDRESS', 'arinanyejoan85@gmail.com');
define('EMAIL_FROM_NAME', 'HomeEase');
define('EMAIL_NOTIFY_CONTACT', true);

define('EMAIL_SMTP_HOST', 'smtp.gmail.com');
define('EMAIL_SMTP_PORT', 587);
define('EMAIL_SMTP_ENCRYPTION', 'tls');
define('EMAIL_SMTP_USERNAME', 'arinanyejoan85@gmail.com');
define('EMAIL_SMTP_CA_FILE', '');
define('EMAIL_SMTP_PASSWORD', 'jfigyiktqedeguwv');
// Remove spaces from Google's displayed app-password groups before saving.
// define('EMAIL_SMTP_PASSWORD', 'your-google-app-password');

// IMAP can use the same Google app password:
// define('EMAIL_IMAP_PASSWORD', 'your-google-app-password');
define('EMAIL_IMAP_HOST', 'imap.gmail.com');
define('EMAIL_IMAP_PORT', 993);
define('EMAIL_IMAP_ENCRYPTION', 'ssl');
define('EMAIL_IMAP_USERNAME', 'arinanyejoan85@gmail.com');
define('EMAIL_IMAP_PASSWORD', 'jfigyiktqedeguwv');
define('EMAIL_IMAP_MAILBOX', 'INBOX');

// Google sign-in ("Continue with Google")
define('GOOGLE_CLIENT_ID', '920243899443-pij4mbm70veu34b2mtvtkdlh5058hdoh.apps.googleusercontent.com');
define('GOOGLE_CLIENT_SECRET', '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');

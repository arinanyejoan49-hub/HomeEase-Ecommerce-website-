<?php
require __DIR__ . '/includes/bootstrap.php';
$title = 'Sustainability & ethics';
require __DIR__ . '/includes/header.php';
?>
<h1>Sustainability &amp; ethics</h1>
<p class="lead">Affordable should not mean wasteful or dishonest. Here is what we commit to.</p>
<div class="two-col">
  <div class="panel">
    <h2><svg width="18" height="18" viewBox="0 0 24 24" aria-hidden="true" style="vertical-align:-1px;"><path d="M11 19l2-2V3h4l2 2v8h-4l-2 2z"/></svg> Lower bills, lower impact</h2>
    <p>Every product shows an energy rating badge where one applies. Fridges, fans and cookers use the most power in a home, so we highlight efficient models and explain running costs in plain words. For students on a tight budget, an efficient appliance saves money every month.</p>
  </div>
  <div class="panel">
    <h2><svg width="18" height="18" viewBox="0 0 24 24" aria-hidden="true" style="vertical-align:-1px;"><path d="M3 7v10a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2zM3 3v4h18V3H3z"/></svg> E-waste take-back</h2>
    <p>Electronic waste is a growing problem in Uganda. When you buy a replacement appliance from us, we collect your old one on delivery and pass it to a licensed e-waste recycler or refurbisher. Ask us at checkout notes or on WhatsApp.</p>
  </div>
  <div class="panel">
    <h2><svg width="18" height="18" viewBox="0 0 24 24" aria-hidden="true" style="vertical-align:-1px;"><path d="M17 3H7c-1.1 0-1.99.9-1.99 2S5.9 7 7 7h4v2H7c-2.21 0-4 1.79-4 4s1.79 4 4 4h4v2h4c2.21 0 4-1.79 4-4s-1.79-4-4-4h-4V5c0-1.1-.9-2-2-2z"/></svg> Repair before replace</h2>
    <p>Warranty claims start with a repair where possible. We keep common spare parts such as kettle bases and fan guards to extend the life of appliances.</p>
  </div>
  <div class="panel">
    <h2><svg width="18" height="18" viewBox="0 0 24 24" aria-hidden="true" style="vertical-align:-1px;"><path d="M17 24v-2c0-3.31-2.69-6-6-6s-6 2.69-6 6v2H2v-2c0-5.52 4.48-10 10-10s10 4.48 10 10v2zm-11-13c0-3.87 3.13-7 7-7s7 3.13 7 7-3.13 7-7 7-7-3.13-7-7z"/></svg> Honest selling</h2>
    <p>Genuine products only, no fake "was" prices, clear specifications and honest stock levels. Students and families should be able to trust what they buy. We also do not use pressure tactics or hidden fees at checkout.</p>
  </div>
  <div class="panel">
    <h2><svg width="18" height="18" viewBox="0 0 24 24" aria-hidden="true" style="vertical-align:-1px;"><path d="M21 12A9 9 0 0 0 9 3a9 9 0 0 0-9 9c0 4.08 2.67 7.56 6.41 8.89v1.12l-.66.12c-.84.15-1.48.86-1.48 1.77v1.5c0 .81.64 1.62 1.48 1.77l.66.12v1.12c3.74 1.33 6.41 4.81 6.41 8.89 0 4.97-4.03 9-9 9s-9-4.03-9-9c0-4.97 4.03-9 9-9s9 4.03 9 9c0-4.08-2.67-7.56-6.41-8.89v-1.12l.66-.12c.84-.15 1.48-.86 1.48-1.77v-1.5c0-.81-.64-1.62-1.48-1.77l-.66-.12V12c-3.74-1.33-6.41-4.81-6.41-8.89 0-4.97 4.03-9 9-9s9 4.03 9 9z"/></svg> International &amp; local considerations</h2>
    <p>Products are imported from international brands and rated for Uganda's 220-240 V supply. Prices are in UGX, with import duty included in the price. We plan to support delivery to neighbouring East African countries and display prices in other currencies as the business grows.</p>
  </div>
  <div class="panel">
    <h2><svg width="18" height="18" viewBox="0 0 24 24" aria-hidden="true" style="vertical-align:-1px;"><path d="M12 17a5 5 0 0 1-5-5V3c0-1.1.9-2 2-2h8c1.1 0 2 .9 2 2v9a5 5 0 0 1-5 5zm-2-8a3 3 0 0 1 3-3h8a3 3 0 0 1 3 3v9a3 3 0 0 1-3 3H13a3 3 0 0 1-3-3z"/></svg> Data ethics</h2>
    <p>We collect only what we need, never store card numbers, ask for consent before analytics cookies, and never sell customer data.</p>
  </div>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>

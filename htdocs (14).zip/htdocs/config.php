<?php
// Site configuration. DO NOT put real passwords here if you commit to a public repo.
// On your host, create config.local.php (same folder) with your real database details;
// it is loaded first and overrides the defaults below.

defined('DB_DRIVER') or define('DB_DRIVER', 'mysql');   // 'mysql' in production ('sqlite' only for local tests)
defined('DB_HOST')   or define('DB_HOST', 'sql309.infinityfree.com');
defined('DB_NAME')   or define('DB_NAME', 'if0_43305450_homeease');
defined('DB_USER')   or define('DB_USER', 'if0_43305450');
defined('DB_PASS')   or define('DB_PASS', 'yxAV5dBMg8');
defined('DB_PATH')   or define('DB_PATH', __DIR__ . '/tests/test.sqlite'); // sqlite tests only

defined('SITE_NAME')  or define('SITE_NAME', 'HomeEase');
defined('SITE_URL') or define('SITE_URL', 'http://homeease.free.je');
defined('APP_ENV') or define('APP_ENV', 'production');
defined('SITE_EMAIL') or define('SITE_EMAIL', 'arinanyejoan85@gmail.com');
defined('SITE_PHONE') or define('SITE_PHONE', '0793797709');
defined('SITE_WHATSAPP') or define('SITE_WHATSAPP', '256760348245'); // digits only, with country code
defined('EMAIL_FROM_ADDRESS') or define('EMAIL_FROM_ADDRESS', SITE_EMAIL);
defined('EMAIL_FROM_NAME') or define('EMAIL_FROM_NAME', SITE_NAME);
defined('EMAIL_NOTIFY_CONTACT') or define('EMAIL_NOTIFY_CONTACT', true);
defined('EMAIL_SMTP_HOST') or define('EMAIL_SMTP_HOST', 'smtp.gmail.com');
defined('EMAIL_SMTP_PORT') or define('EMAIL_SMTP_PORT', 587);
defined('EMAIL_SMTP_ENCRYPTION') or define('EMAIL_SMTP_ENCRYPTION', 'tls');
defined('EMAIL_SMTP_USERNAME') or define('EMAIL_SMTP_USERNAME', 'arinanyejoan85@gmail.com');
defined('EMAIL_SMTP_PASSWORD') or define('EMAIL_SMTP_PASSWORD', 'hpgtypkblqleettr');
defined('EMAIL_SMTP_CA_FILE') or define('EMAIL_SMTP_CA_FILE', '');
defined('EMAIL_IMAP_HOST') or define('EMAIL_IMAP_HOST', 'imap.gmail.com');
defined('EMAIL_IMAP_PORT') or define('EMAIL_IMAP_PORT', 993);
defined('EMAIL_IMAP_ENCRYPTION') or define('EMAIL_IMAP_ENCRYPTION', 'ssl');
defined('EMAIL_IMAP_USERNAME') or define('EMAIL_IMAP_USERNAME', 'arinanyejoan85@gmail.com');
defined('EMAIL_IMAP_PASSWORD') or define('EMAIL_IMAP_PASSWORD', 'hpgtypkblqleettr');
defined('EMAIL_IMAP_MAILBOX') or define('EMAIL_IMAP_MAILBOX', 'INBOX');

// PesaJet mobile money (MTN / Airtel). Put the real values in config.local.php, NOT here:
//   define('PESAJET_API_KEY', 'pk_...');            // public API key from the PesaJet dashboard
//   define('PESAJET_WEBHOOK_SECRET', 'whsec_...'); // webhook signing secret
// While PESAJET_API_KEY is empty, checkout keeps using the built-in payment simulation.
defined('PESAJET_API_KEY') or define('PESAJET_API_KEY', '');
defined('PESAJET_WEBHOOK_SECRET') or define('PESAJET_WEBHOOK_SECRET', '');
defined('PESAJET_BASE_URL') or define('PESAJET_BASE_URL', 'https://payments.pesajet.com/api/v1');

// Google Analytics 4 measurement ID, e.g. 'G-ABC123XYZ'. Leave empty to disable tracking.
defined('GA_ID') or define('GA_ID', 'G-JRN2BK8LGB');

// Google sign-in ("Continue with Google"). Create an OAuth client in Google Cloud Console, then put these in config.local.php.
// Leave empty to hide the Google button. GOOGLE_REDIRECT_URI is optional; by default it is this site's /google-callback.php.
defined('GOOGLE_CLIENT_ID') or define('GOOGLE_CLIENT_ID', '');
defined('GOOGLE_CLIENT_SECRET') or define('GOOGLE_CLIENT_SECRET', '');
defined('GOOGLE_REDIRECT_URI') or define('GOOGLE_REDIRECT_URI', '');

// Coupon codes: code => percent off the subtotal
defined('COUPONS') or define('COUPONS', ['STUDENT10' => 10, 'WELCOME5' => 5]);

// Delivery zones: key => [label, fee in UGX, estimated working days]
defined('ZONES') or define('ZONES', [
    'pickup'   => ['Store pickup (Masaka)', 0, 'Ready in 1 day'],
    'masaka'   => ['Masaka City (Nyendo, Kimaanya, Katwe-Butego & town)', 5000, '1 to 2 working days'],
    'region'   => ['Around Masaka (Lwengo, Kalungu, Bukomansimbi, Kyotera, Rakai, Sembabule)', 10000, '2 to 3 working days'],
    'upcountry'=> ['Rest of Uganda, including Kampala (by courier/bus)', 20000, '3 to 6 working days'],
]);
// Free delivery for the Masaka zones when the discounted subtotal is at least this much
defined('FREE_DELIVERY_FROM') or define('FREE_DELIVERY_FROM', 5000);

// Set true on a live site that has HTTPS to force secure cookies and redirect http to https
defined('FORCE_HTTPS') or define('FORCE_HTTPS', false);

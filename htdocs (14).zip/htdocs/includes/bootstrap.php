<?php
declare(strict_types=1);

if (!defined('HOMEEASE_TEST_SQLITE') && file_exists(__DIR__ . '/../config.local.php')) {
    require __DIR__ . '/../config.local.php';
}
require __DIR__ . '/../config.php';
require __DIR__ . '/pesajet.php';

// ---------- Base path (works in the web root or a sub-folder, and inside /admin) ----------
$__script = str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? '');
$__dir = rtrim(str_replace('\\', '/', dirname($__script)), '/');
if (substr($__dir, -6) === '/admin') {
    $__dir = substr($__dir, 0, -6);
}
if (substr($__dir, -9) === '/customer') {
    $__dir = substr($__dir, 0, -9);
}
define('BASE', $__dir);

// ---------- Security: HTTPS, headers, session ----------
function request_is_https(): bool
{
    return (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
}

$isHttps = request_is_https();
if (FORCE_HTTPS && !$isHttps && PHP_SAPI !== 'cli') {
    header('Location: https://' . ($_SERVER['HTTP_HOST'] ?? '') . ($_SERVER['REQUEST_URI'] ?? '/'), true, 301);
    exit;
}
ini_set('session.use_only_cookies', '1');
ini_set('session.use_strict_mode', '1');
header('X-Frame-Options: SAMEORIGIN');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: strict-origin-when-cross-origin');
header('Permissions-Policy: camera=(), microphone=(), geolocation=()');

session_set_cookie_params([
    'lifetime' => 0,
    'path' => '/',
    // Only mark the cookie Secure when PHP itself is on HTTPS. A proxy header must not
    // do this: a Secure cookie set over plain http is silently rejected by the browser.
    'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
    'httponly' => true,
    'samesite' => 'Lax',
]);
session_name('he_session');
session_start();

function he_regenerate_session(): void
{
    session_regenerate_id(true);
}

// ---------- Database (PDO with prepared statements) ----------
function db(): PDO
{
    static $pdo = null;
    if ($pdo) {
        return $pdo;
    }
    try {
        if (DB_DRIVER === 'sqlite') {
            $pdo = new PDO('sqlite:' . DB_PATH);
        } else {
            $pdo = new PDO(
                'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
                DB_USER,
                DB_PASS
            );
        }
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        $pdo->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
    } catch (Throwable $e) {
        http_response_code(500);
        error_log('DB connection failed: ' . $e->getMessage());
        exit('Sorry, the store is temporarily unavailable. Please try again shortly.');
    }
    return $pdo;
}

function q(string $sql, array $params = []): PDOStatement
{
    $st = db()->prepare($sql);
    $st->execute($params);
    return $st;
}

function table_exists(string $table): bool
{
    if (DB_DRIVER === 'sqlite') {
        return (bool)q("SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = ?", [$table])->fetchColumn();
    }

    return (bool)q(
        'SELECT 1 FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = ?',
        [$table]
    )->fetchColumn();
}

function column_exists(string $table, string $column): bool
{
    if (!preg_match('/^[a-zA-Z0-9_]+$/', $table) || !preg_match('/^[a-zA-Z0-9_]+$/', $column)) {
        return false;
    }

    if (DB_DRIVER === 'sqlite') {
        foreach (q('PRAGMA table_info("' . $table . '")')->fetchAll() as $row) {
            if (($row['name'] ?? '') === $column) {
                return true;
            }
        }
        return false;
    }

    return (bool)q(
        'SELECT 1 FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = ? AND column_name = ?',
        [$table, $column]
    )->fetchColumn();
}

// ---------- Helpers ----------
function e($v): string
{
    return htmlspecialchars((string)$v, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function payment_status_label(string $status): string
{
    return str_ireplace('test', 'simulated', $status);
}

function payment_reference_label(string $reference): string
{
    return str_ireplace('TEST', 'SIM', $reference);
}

function url(string $path = ''): string
{
    return BASE . '/' . ltrim($path, '/');
}

function money($n): string
{
    return 'UGX ' . number_format((int)$n);
}

function redirect(string $path): void
{
    header('Location: ' . (preg_match('#^https?://#', $path) ? $path : url($path)));
    exit;
}

function csrf_token(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="csrf" value="' . e(csrf_token()) . '">';
}

function csrf_verify(): void
{
    $sent = $_POST['csrf'] ?? '';
    $known = $_SESSION['csrf'] ?? '';
    if (!is_string($sent) || $known === '' || !hash_equals($known, $sent)) {
        http_response_code(400);
        exit('Invalid or expired form. Please go back, refresh the page and try again.');
    }
}

function flash(string $type, string $msg): void
{
    $_SESSION['flash'][] = [$type, $msg];
}

function flashes(): array
{
    $f = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);
    return $f;
}

function post(string $key, int $max = 255): string
{
    $v = $_POST[$key] ?? '';
    return is_string($v) ? mb_substr(trim($v), 0, $max) : '';
}

// ---------- Admin auth ----------
function is_admin(): bool
{
    return !empty($_SESSION['admin_id']) && empty($_SESSION['customer_id']);
}

function require_admin(): void
{
    header('Cache-Control: no-store');
    if (is_customer()) {
        http_response_code(403);
        exit('Access denied.');
    }
    if (!is_admin()) {
        redirect('login.php');
    }
    if (!table_exists('admins') || !q('SELECT 1 FROM admins WHERE id = ?', [(int)$_SESSION['admin_id']])->fetchColumn()) {
        unset($_SESSION['admin_id'], $_SESSION['admin_name'], $_SESSION['auth_role']);
        he_regenerate_session();
        redirect('login.php');
    }
}

// ---------- Customer auth ----------
function is_customer(): bool
{
    return !empty($_SESSION['customer_id']) && empty($_SESSION['admin_id']);
}

function require_customer(): void
{
    header('Cache-Control: no-store');
    if (is_admin()) {
        redirect('admin/index.php');
    }
    if (!is_customer() || !table_exists('users') || current_customer() === null) {
        redirect('login.php');
    }
}

function current_customer(): ?array
{
    if (!is_customer()) {
        return null;
    }
    static $customer = null;
    if ($customer !== null) {
        return $customer;
    }
    $customer = q('SELECT * FROM users WHERE id = ? AND status = "active" AND role = "customer"', [(int)$_SESSION['customer_id']])->fetch();
    if (!$customer) {
        customer_logout();
        return null;
    }
    return $customer;
}

function customer_login(array $user): void
{
    if (($user['role'] ?? '') !== 'customer') {
        throw new LogicException('Only customer accounts can use customer authentication.');
    }
    he_regenerate_session();
    unset($_SESSION['admin_id'], $_SESSION['admin_name'], $_SESSION['return_url'], $_SESSION['csrf']);
    $_SESSION['customer_id'] = (int)$user['id'];
    $_SESSION['customer_name'] = $user['first_name'] . ' ' . $user['last_name'];
    $_SESSION['customer_email'] = $user['email'];
    $_SESSION['customer_role'] = $user['role'];
    $_SESSION['auth_role'] = 'customer';
    q('UPDATE users SET updated_at = CURRENT_TIMESTAMP WHERE id = ?', [(int)$user['id']]);
}

function admin_login(array $admin): void
{
    he_regenerate_session();
    unset(
        $_SESSION['customer_id'],
        $_SESSION['customer_name'],
        $_SESSION['customer_email'],
        $_SESSION['customer_role'],
        $_SESSION['return_url'],
        $_SESSION['csrf']
    );
    $_SESSION['admin_id'] = (int)$admin['id'];
    $_SESSION['admin_name'] = $admin['name'];
    $_SESSION['auth_role'] = 'admin';
}

function customer_logout(): void
{
    if (is_customer() && table_exists('users') && column_exists('users', 'remember_token')) {
        q('UPDATE users SET remember_token = NULL, remember_expires = NULL WHERE id = ?', [(int)$_SESSION['customer_id']]);
    }
    unset($_SESSION['customer_id'], $_SESSION['customer_name'], $_SESSION['customer_email'], $_SESSION['customer_role']);
    if (($_SESSION['auth_role'] ?? '') === 'customer') {
        unset($_SESSION['auth_role']);
    }
    he_regenerate_session();
    setcookie('he_remember', '', [
        'expires' => time() - 3600,
        'path' => '/',
        'secure' => request_is_https(),
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    unset($_COOKIE['he_remember']);
}

// ---------- Login throttling ----------
function record_login_attempt(string $identifier, bool $success): void
{
    if (!table_exists('login_attempts')) {
        $attempts = $_SESSION['local_login_attempts'][$identifier] ?? [];
        $attempts[] = time();
        $_SESSION['local_login_attempts'][$identifier] = array_values(array_filter(
            $attempts,
            static function ($attemptedAt): bool {
                return is_int($attemptedAt) && $attemptedAt > time() - 86400;
            }
        ));
        return;
    }

    q('INSERT INTO login_attempts (identifier, success) VALUES (?, ?)', [$identifier, $success ? 1 : 0]);
    // Clean old attempts (older than 24 hours)
    if (DB_DRIVER === 'sqlite') {
        q("DELETE FROM login_attempts WHERE attempted_at < datetime('now', '-24 hours')");
    } else {
        q('DELETE FROM login_attempts WHERE attempted_at < DATE_SUB(NOW(), INTERVAL 24 HOUR)');
    }
}

function is_rate_limited(string $identifier, int $maxAttempts = 5, int $windowMinutes = 15): bool
{
    if (!table_exists('login_attempts')) {
        $cutoff = time() - (max(1, $windowMinutes) * 60);
        $attempts = $_SESSION['local_login_attempts'][$identifier] ?? [];
        $recentAttempts = array_filter($attempts, static function ($attemptedAt) use ($cutoff): bool {
            return is_int($attemptedAt) && $attemptedAt > $cutoff;
        });
        return count($recentAttempts) >= $maxAttempts;
    }

    if (DB_DRIVER === 'sqlite') {
        $row = q("SELECT COUNT(*) AS c FROM login_attempts WHERE identifier = ? AND attempted_at > datetime('now', ?)", [$identifier, '-' . max(1, $windowMinutes) . ' minutes'])->fetch();
    } else {
        $row = q('SELECT COUNT(*) AS c FROM login_attempts WHERE identifier = ? AND attempted_at > DATE_SUB(NOW(), INTERVAL ? MINUTE)', [$identifier, $windowMinutes])->fetch();
    }
    return (int)($row['c'] ?? 0) >= $maxAttempts;
}

// ---------- Star ratings (from the reviews table) ----------
// One query per request: average rating and review count for every reviewed product.
function product_rating_stats(): array
{
    static $stats = null;
    if ($stats !== null) {
        return $stats;
    }
    $stats = [];
    try {
        if (table_exists('reviews')) {
            $rows = q("SELECT product_id, AVG(rating) AS avg_rating, COUNT(*) AS n FROM reviews WHERE status <> 'rejected' GROUP BY product_id")->fetchAll();
            foreach ($rows as $r) {
                $stats[(int)$r['product_id']] = ['avg' => (float)$r['avg_rating'], 'count' => (int)$r['n']];
            }
        }
    } catch (Throwable $e) {
        error_log('HomeEase could not load ratings: ' . $e->getMessage());
    }
    return $stats;
}

// Compact rating, like "★ 3.8 (315)". Shows three stars until a product has a review.
function product_rating_html(int $productId): string
{
    $s = product_rating_stats()[$productId] ?? null;
    if (!$s || $s['count'] < 1) {
        return '<span class="rating" aria-label="3 stars"><span class="stars" aria-hidden="true">★★★</span></span>';
    }
    $avg = number_format($s['avg'], 1);
    $label = 'Rated ' . $avg . ' out of 5 from ' . $s['count'] . ' review' . ($s['count'] === 1 ? '' : 's');
    return '<span class="rating" aria-label="' . e($label) . '"><span class="stars" aria-hidden="true">★</span> <strong>'
        . e($avg) . '</strong> <span class="rating-count" aria-hidden="true">(' . (int)$s['count'] . ')</span></span>';
}

// Five stars for one review: filled up to the rating, outlined after.
function review_stars_html(int $rating): string
{
    $rating = max(0, min(5, $rating));
    return '<span class="rating" aria-label="' . $rating . ' out of 5 stars"><span class="stars" aria-hidden="true">'
        . str_repeat('★', $rating) . '<span class="stars-empty">' . str_repeat('★', 5 - $rating) . '</span></span></span>';
}

// ---------- Product images stored in the database ----------
// Photos live in the product_images table (not only on disk), so every copy of the site that
// shares the database shows them immediately. products.image holds the reference "db:<token>".
function product_images_table_ready(): bool
{
    static $ready = null;
    if ($ready !== null) {
        return $ready;
    }
    try {
        if (!table_exists('product_images')) {
            if (DB_DRIVER === 'sqlite') {
                db()->exec('CREATE TABLE IF NOT EXISTS product_images (token TEXT PRIMARY KEY, mime TEXT NOT NULL, data BLOB NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP)');
            } else {
                db()->exec('CREATE TABLE IF NOT EXISTS product_images (token CHAR(32) NOT NULL PRIMARY KEY, mime VARCHAR(30) NOT NULL, data MEDIUMBLOB NOT NULL, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4');
            }
        }
        $ready = table_exists('product_images');
    } catch (Throwable $e) {
        error_log('HomeEase could not create product_images: ' . $e->getMessage());
        $ready = false;
    }
    return $ready;
}

// Returns [bytes, mime] for an image file, shrinking very large photos when GD is available.
function product_image_prepare(string $path): ?array
{
    $info = @getimagesize($path);
    $types = [IMAGETYPE_JPEG => 'image/jpeg', IMAGETYPE_PNG => 'image/png', IMAGETYPE_WEBP => 'image/webp'];
    if (!$info || !isset($types[$info[2]])) {
        return null;
    }
    $mime = $types[$info[2]];
    $bytes = @file_get_contents($path);
    if ($bytes === false || $bytes === '') {
        return null;
    }
    $max = 1200;
    if (($info[0] > $max || $info[1] > $max)
        && function_exists('imagecreatefromstring') && function_exists('imagecreatetruecolor')) {
        $src = @imagecreatefromstring($bytes);
        if ($src !== false) {
            $scale = min($max / $info[0], $max / $info[1]);
            $nw = max(1, (int)round($info[0] * $scale));
            $nh = max(1, (int)round($info[1] * $scale));
            $dst = imagecreatetruecolor($nw, $nh);
            if ($mime !== 'image/jpeg') {
                imagealphablending($dst, false);
                imagesavealpha($dst, true);
            }
            imagecopyresampled($dst, $src, 0, 0, 0, 0, $nw, $nh, $info[0], $info[1]);
            ob_start();
            $ok = false;
            if ($mime === 'image/jpeg') {
                $ok = imagejpeg($dst, null, 85);
            } elseif ($mime === 'image/png') {
                $ok = imagepng($dst, null, 6);
            } elseif (function_exists('imagewebp')) {
                $ok = imagewebp($dst, null, 85);
            }
            $out = (string)ob_get_clean();
            if ($ok && $out !== '') {
                $bytes = $out;
            }
        }
    }
    return [$bytes, $mime];
}

// Saves an uploaded image into the database. Returns "db:<token>" or null on failure.
function product_image_store(string $path): ?string
{
    $prepared = product_image_prepare($path);
    if ($prepared === null || !product_images_table_ready()) {
        return null;
    }
    [$bytes, $mime] = $prepared;
    $token = bin2hex(random_bytes(16));
    try {
        $st = db()->prepare('INSERT INTO product_images (token, mime, data) VALUES (?, ?, ?)');
        $st->bindValue(1, $token);
        $st->bindValue(2, $mime);
        $st->bindValue(3, $bytes, PDO::PARAM_LOB);
        $st->execute();
    } catch (Throwable $e) {
        error_log('HomeEase could not store a product image: ' . $e->getMessage());
        return null;
    }
    return 'db:' . $token;
}

function product_image_delete(string $ref): void
{
    if (strncmp($ref, 'db:', 3) !== 0 || !preg_match('/^[a-f0-9]{32}$/', substr($ref, 3))) {
        return;
    }
    try {
        if (table_exists('product_images')) {
            q('DELETE FROM product_images WHERE token = ?', [substr($ref, 3)]);
        }
    } catch (Throwable $e) {
        error_log('HomeEase could not delete a product image: ' . $e->getMessage());
    }
}

// ---------- Products ----------
function product_image_url(array $p): string
{
    $root = __DIR__ . '/../assets/';
    $productsDir = $root . 'products/';
    $uploadsDir = $root . 'uploads/';
    $extensions = ['jpg', 'jpeg', 'png', 'webp', 'avif', 'jfif', 'svg'];
    $image = is_string($p['image'] ?? null) ? trim($p['image']) : '';

    if ($image !== '' && strncmp($image, 'db:', 3) === 0) {
        $token = substr($image, 3);
        if (preg_match('/^[a-f0-9]{32}$/', $token)) {
            return url('product-image.php?t=' . $token);
        }
    }

    if ($image !== '') {
        $uploadName = basename($image);
        $uploadExt = strtolower(pathinfo($uploadName, PATHINFO_EXTENSION));
        if ($uploadName === $image && in_array($uploadExt, $extensions, true)
            && is_file($uploadsDir . $uploadName)) {
            return url('assets/uploads/' . rawurlencode($uploadName));
        }
    }

    $normalize = static fn(string $name): string => trim(
        (string)preg_replace('/[^a-z0-9]+/i', '-', strtolower($name)),
        '-'
    );
    $nameIdentity = $normalize((string)($p['name'] ?? ''));
    $slugIdentity = $normalize((string)($p['slug'] ?? ''));
    $identities = array_filter([$nameIdentity, $slugIdentity]);

    static $filesByName = null;
    if ($filesByName === null) {
        $filesByName = [];
        foreach (glob($productsDir . '*') ?: [] as $file) {
            if (is_file($file) && in_array(strtolower(pathinfo($file, PATHINFO_EXTENSION)), $extensions, true)) {
                $filesByName[basename($file)] = $file;
            }
        }
    }
    $files = $filesByName;

    if ($image !== '') {
        $publicName = basename(str_replace('\\', '/', $image));
        $publicFile = $files[$publicName] ?? null;
        if ($publicFile) {
            return url('assets/products/' . rawurlencode($publicName));
        }
    }

    $name = strtolower((string)($p['name'] ?? ''));
    $families = [
        '/\bmicrowave oven 20l samsung\b/' => 'samsung-microwave-oven-20l.webp',
        '/\bmicrowave oven 20l\b/' => 'microwave-oven-20l-lifestyle.webp',
        '/\bmicrowave\b/' => 'microwave-oven-20l-lifestyle.webp',
        '/\bfood processor 2l\b/' => 'food-processor-2l.jpg',
        '/\bclothes dryer 7kg\b/' => 'clothes-dryer-7kg.jpg',
        '/\bair fryer 4l philips\b/' => 'air-fryer-4l-philips.webp',
        '/^air fryer 4l$/' => 'air-fryer-4l-white.webp',
        '/\bair fryer\b/' => 'air-fryer-4l-lifestyle.webp',
        '/\bdouble door fridge 200l samsung\b/' => 'double-door-fridge-samsung-200l.webp',
        '/\bdouble door fridge 200l\b/' => 'double-door-fridge-200l.webp',
        '/\b2[- ]plate electric hotplate\b|\b2[- ]plate hotplate\b/' => '2-plate-electric-hotplate.jpg',
        '/\brechargeable fan with light\b/' => 'rechargeable-fan-light.webp',
        '/\bnon[- ]stick cookware set 7pc tefal\b/' => 'tefal-non-stick-cookware-set-7pc.webp',
        '/\bnon[- ]stick cookware set 7pc\b/' => 'non-stick-cookware-set-7pc.webp',
        '/\bnutrichef non[- ]stick cookware set\b/' => 'nutrichef-blue-cookware-set.avif',
        '/\bsolar rechargeable led lamp sollatek 13\b/' => 'solar-led-lamp-panel-kit.webp',
        '/\bsolar rechargeable led lamp sollatek 17\b/' => 'solar-rechargeable-lantern.webp',
        '/\bsolar rechargeable led lamp\b/' => 'solar-rechargeable-led-lamp.webp',
        '/\belectric kettle\b|\bkettle\b/' => 'electric-kettle-1-7l.jpg',
        '/\brice cooker\b/' => 'rice-cooker-1-8l.jpg',
        '/\bmini blender personal\b/' => 'mini-blender-personal.webp',
        '/\bblender\b/' => 'blender-1-5l-grinder.webp',
        '/\bsandwich maker\b/' => 'sandwich-maker.webp',
        '/\btable[- ]?top gas cooker\b|\b2 burner gas cooker\b/' => 'tabletop-gas-cooker-2-burner.webp',
        '/\bmini fridge 90l\b/' => 'mini-fridge-90l.webp',
        '/\b16.{0,2} standing fan\b|\b16 inch standing fan\b/' => '16-inch-standing-fan.webp',
        '/\bsemi[- ]automatic washing machine 7kg\b/' => 'semi-automatic-washing-machine-7kg.webp',
        '/\bfully automatic washing machine 8kg\b/' => 'fully-automatic-washing-machine-8kg.webp',
        '/\bsteam iron 2000w\b/' => 'steam-iron-2000w.webp',
        '/\bbagless vacuum cleaner\b/' => 'bagless-vacuum-cleaner.webp',
        '/\bstudent starter bundle\b/' => 'student-starter-bundle.webp',
        '/\b6[- ]way surge protected extension\b/' => '6-way-surge-protected-extension.webp',
        '/\b2[- ]slice toaster\b/' => '2-slice-toaster.webp',
        '/\bcoffee maker 12[- ]cup\b/' => 'coffee-maker-12-cup.webp',
        '/\bdesk lamp led\b/' => 'desk-lamp-led.webp',
        '/\belectric deep fryer 3l\b/' => 'electric-deep-fryer-3l.webp',
        '/\belectric griddle\b/' => 'electric-griddle.webp',
        '/\belectric oven 30l\b/' => 'electric-oven-30l.webp',
        '/\bgas oven with hob\b/' => 'gas-oven-with-hob.webp',
        '/\bled ring light with stand\b/' => 'led-ring-light-with-stand.webp',
        '/\bsingle door fridge 135l\b/' => 'single-door-fridge-135l.webp',
        '/\bsteam mop\b/' => 'steam-mop.webp',
        '/\bwater dispenser\b/' => 'water-dispenser.webp',
    ];
    foreach ($families as $pattern => $filename) {
        if (preg_match($pattern, $name) && isset($files[$filename])) {
            return url('assets/products/' . rawurlencode($filename));
        }
    }

    $exactSvg = null;
    foreach ($files as $name => $file) {
        if ($nameIdentity !== '' && $normalize(pathinfo($name, PATHINFO_FILENAME)) === $nameIdentity) {
            if (strtolower(pathinfo($name, PATHINFO_EXTENSION)) === 'svg') {
                $exactSvg = $name;
                continue;
            }
            return url('assets/products/' . rawurlencode($name));
        }
    }

    foreach ($files as $name => $file) {
        if ($slugIdentity !== '' && $normalize(pathinfo($name, PATHINFO_FILENAME)) === $slugIdentity) {
            return url('assets/products/' . rawurlencode($name));
        }
    }

    if ($exactSvg !== null) {
        return url('assets/products/' . rawurlencode($exactSvg));
    }

    return url('assets/images/product-image-unavailable.svg');
}

function category_media(array $category): string
{
    $imagesBySlug = [
        'kitchen' => 'images/hero/modern-kitchen.jpg',
        'cooking' => 'products/tabletop-gas-cooker-2-burner.webp',
        'cooling' => 'products/double-door-fridge-samsung-200l.webp',
        'laundry' => 'products/fully-automatic-washing-machine-8kg.webp',
        'student' => 'products/student-starter-bundle.webp',
        'power' => 'products/solar-led-lamp-panel-kit.webp',
        'entertainment' => 'images/hero/smart-living-room.jpg',
        'cleaning' => 'products/bagless-vacuum-cleaner.webp',
        'climate' => 'products/air-cooler-20l.webp',
        'security' => 'images/hero/home-interior.jpg',
        'smart-home' => 'images/hero/smart-living-room.jpg',
        'personal-care' => 'products/led-ring-light-with-stand.webp',
        'water' => 'products/water-dispenser.webp',
        'home-office' => 'products/desk-lamp-led.webp',
        'furniture' => 'images/categories/living-room-furniture.webp',
        'decor' => 'images/categories/home-decor.webp',
        'bedding' => 'images/categories/bedding-mattresses.webp',
        'tools' => 'images/hero/home-essentials.jpg',
        'outdoor' => 'products/rechargeable-solar-fan.jpg',
        'solar' => 'products/solar-rechargeable-lantern.webp',
    ];
    $slug = (string)($category['slug'] ?? '');
    if (!isset($imagesBySlug[$slug])) {
        return '';
    }

    $image = $imagesBySlug[$slug];
    if (!is_file(__DIR__ . '/../assets/' . $image)) {
        return '';
    }

    return '<span class="cat-image category-image" aria-hidden="true"><img src="'
        . e(url('assets/' . $image)) . '" alt="" loading="lazy"></span>';
}

function product_media(array $p, string $class = ''): string
{
    $alt = (string)($p['name'] ?? 'Product');
    $src = product_image_url($p);
    $fallback = url('assets/images/product-image-unavailable.svg');
    $imageClass = trim('product-image ' . $class);
    $name = e($alt);

    return '<img class="' . e($imageClass) . '" src="' . e($src) . '" alt="' . $name
        . '" loading="lazy" onerror="this.onerror=null;this.src=\'' . e($fallback) . '\'">';
}

function discount_pct(array $p): int
{
    if (!empty($p['old_price']) && $p['old_price'] > $p['price']) {
        return (int)round((1 - $p['price'] / $p['old_price']) * 100);
    }
    return 0;
}

function energy_badge(string $r): string
{
    return $r === '' ? '' : '<span class="badge energy" title="Energy efficiency rating">⚡ ' . e($r) . '</span>';
}

function slugify(string $s): string
{
    $s = strtolower(trim(preg_replace('/[^A-Za-z0-9]+/', '-', $s), '-'));
    return $s === '' ? 'product' : $s;
}

// ---------- Cart (stored in session as product_id => qty; prices always read from the DB) ----------
function cart_raw(): array
{
    return $_SESSION['cart'] ?? [];
}

function cart_count(): int
{
    return array_sum(cart_raw());
}

function cart_add(int $id, int $qty = 1): bool
{
    $p = q('SELECT id, stock FROM products WHERE id = ? AND is_active = 1', [$id])->fetch();
    if (!$p || $p['stock'] < 1) {
        return false;
    }
    $cart = cart_raw();
    $cart[$id] = min((int)$p['stock'], ($cart[$id] ?? 0) + max(1, $qty), 20);
    $_SESSION['cart'] = $cart;
    return true;
}

function cart_set(int $id, int $qty): void
{
    $cart = cart_raw();
    if ($qty <= 0) {
        unset($cart[$id]);
    } elseif (isset($cart[$id])) {
        $p = q('SELECT stock FROM products WHERE id = ?', [$id])->fetch();
        $cart[$id] = min($qty, (int)($p['stock'] ?? 1), 20);
    }
    $_SESSION['cart'] = $cart;
}

function cart_items(): array
{
    $cart = cart_raw();
    if (!$cart) {
        return [];
    }
    $ids = array_map('intval', array_keys($cart));
    $in = implode(',', array_fill(0, count($ids), '?'));
    $rows = q("SELECT p.*, c.icon FROM products p JOIN categories c ON c.id = p.category_id
               WHERE p.id IN ($in) AND p.is_active = 1", $ids)->fetchAll();
    $items = [];
    foreach ($rows as $r) {
        $r['qty'] = min($cart[$r['id']], max(0, (int)$r['stock']));
        if ($r['qty'] < 1) {
            continue;
        }
        $r['line'] = $r['qty'] * $r['price'];
        $items[] = $r;
    }
    return $items;
}

function cart_totals(array $items, string $zone = 'masaka', string $coupon = ''): array
{
    $subtotal = 0;
    foreach ($items as $i) {
        $subtotal += $i['line'];
    }
    $coupon = strtoupper($coupon);
    $pct = COUPONS[$coupon] ?? 0;
    $discount = (int)round($subtotal * $pct / 100);
    $after = $subtotal - $discount;
    $fee = ZONES[$zone][1] ?? 0;
    if (in_array($zone, ['masaka', 'region'], true) && $after >= FREE_DELIVERY_FROM) {
        $fee = 0;
    }
    if (!$items) {
        $fee = 0;
    }
    return [
        'subtotal' => $subtotal,
        'discount' => $discount,
        'coupon' => $pct ? $coupon : '',
        'delivery' => $fee,
        'total' => $after + $fee,
    ];
}

function order_statuses(): array
{
    return ['pending' => 'Pending', 'confirmed' => 'Confirmed', 'dispatched' => 'Dispatched', 'delivered' => 'Delivered', 'cancelled' => 'Cancelled'];
}

// ---------- Wishlist (stored in session as array of product ids) ----------
function wishlist_count(): int
{
    return count(wishlist_raw());
}
function wishlist_raw(): array
{
    if (is_customer() && table_exists('wishlists')) {

        $user = current_customer();
        if ($user) {
            $ids = q('SELECT product_id FROM wishlists WHERE user_id = ?', [(int)$user['id']])->fetchAll(PDO::FETCH_COLUMN);
            return array_values(array_unique(array_map('intval', $ids)));
        }
    }
    return array_unique(array_map('intval', $_SESSION['wishlist'] ?? []));
}

function wishlist_add(int $id): void
{
    if (is_customer() && table_exists('wishlists')) {
        $user = current_customer();
        if ($user) {
            try {
                q('INSERT INTO wishlists (user_id, product_id) VALUES (?,?)', [(int)$user['id'], $id]);
            } catch (Throwable $e) { /* duplicate */ }
            return;
        }
    }
    $wl = wishlist_raw();
    if (!in_array($id, $wl, true)) {
        $wl[] = $id;
        $_SESSION['wishlist'] = $wl;
    }
}

function wishlist_remove(int $id): void
{
    if (is_customer() && table_exists('wishlists')) {
        $user = current_customer();
        if ($user) {
            q('DELETE FROM wishlists WHERE user_id = ? AND product_id = ?', [(int)$user['id'], $id]);
            return;
        }
    }
    $wl = wishlist_raw();
    $_SESSION['wishlist'] = array_values(array_diff($wl, [$id]));
}

function wishlist_items(): array
{
    $ids = wishlist_raw();
    if (!$ids) {
        return [];
    }
    $in = implode(',', array_fill(0, count($ids), '?'));
    return q("SELECT p.*, c.icon FROM products p JOIN categories c ON c.id = p.category_id
              WHERE p.id IN ($in) AND p.is_active = 1 ORDER BY p.id DESC", $ids)->fetchAll();
}

function is_wishlisted(int $id): bool
{
    return in_array($id, wishlist_raw(), true);
}

function restore_customer_session(): void
{
    $token = $_COOKIE['he_remember'] ?? '';
    if (is_customer() || !is_string($token) || !preg_match('/^[a-f0-9]{64}$/', $token)) {
        return;
    }
    if (!table_exists('users')) {
        setcookie('he_remember', '', [
            'expires' => time() - 3600,
            'path' => '/',
            'secure' => request_is_https(),
            'httponly' => true,
            'samesite' => 'Lax',
        ]);
        unset($_COOKIE['he_remember']);
        return;
    }

    $user = q("SELECT * FROM users
               WHERE remember_token = ? AND remember_expires > CURRENT_TIMESTAMP AND status = 'active'",
        [hash('sha256', $token)])->fetch();
    if ($user) {
        customer_login($user);
        return;
    }

    setcookie('he_remember', '', [
        'expires' => time() - 3600,
        'path' => '/',
        'secure' => request_is_https(),
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    unset($_COOKIE['he_remember']);
}

restore_customer_session();

// ---- Auto-create missing tables (safe, idempotent) ----
function ensure_tables(): void
{
    static $done = false;
    if ($done) { return; }
    $done = true;
    $tables = [
        "CREATE TABLE IF NOT EXISTS customer_addresses (id INT AUTO_INCREMENT PRIMARY KEY, user_id INT NOT NULL, recipient_name VARCHAR(120) NOT NULL, phone VARCHAR(30) NOT NULL, district VARCHAR(100) NOT NULL, town VARCHAR(100) NOT NULL, address VARCHAR(255) NOT NULL, landmark VARCHAR(255) NULL, instructions VARCHAR(500) NULL, is_default TINYINT(1) NOT NULL DEFAULT 0, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
        "CREATE TABLE IF NOT EXISTS wishlists (id INT AUTO_INCREMENT PRIMARY KEY, user_id INT NOT NULL, product_id INT NOT NULL, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, UNIQUE KEY uniq_user_product (user_id, product_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
        "CREATE TABLE IF NOT EXISTS notifications (id INT AUTO_INCREMENT PRIMARY KEY, user_id INT NOT NULL, title VARCHAR(160) NOT NULL, message VARCHAR(500) NOT NULL, link VARCHAR(255) NULL, is_read TINYINT(1) NOT NULL DEFAULT 0, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
        "CREATE TABLE IF NOT EXISTS order_receipts (id INT AUTO_INCREMENT PRIMARY KEY, order_id INT NOT NULL, receipt_no VARCHAR(48) NOT NULL, issued_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, emailed_at DATETIME NULL, email_status VARCHAR(30) NOT NULL DEFAULT 'not_sent', email_error VARCHAR(255) NULL, UNIQUE KEY uniq_receipt_order (order_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
        "CREATE TABLE IF NOT EXISTS admin_notifications (id INT AUTO_INCREMENT PRIMARY KEY, type VARCHAR(24) NOT NULL DEFAULT 'order', title VARCHAR(160) NOT NULL, message VARCHAR(500) NOT NULL, link VARCHAR(255) NULL, is_read TINYINT(1) NOT NULL DEFAULT 0, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, INDEX idx_admin_notif_read (is_read, id), INDEX idx_admin_notif_type (type, id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
        "CREATE TABLE IF NOT EXISTS reviews (id INT AUTO_INCREMENT PRIMARY KEY, product_id INT NOT NULL, user_id INT NOT NULL, order_id INT NULL, rating TINYINT NOT NULL, title VARCHAR(160) NULL, body TEXT NOT NULL, status VARCHAR(12) NOT NULL DEFAULT 'pending', created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
        "CREATE TABLE IF NOT EXISTS return_requests (id INT AUTO_INCREMENT PRIMARY KEY, order_id INT NOT NULL, user_id INT NOT NULL, reason VARCHAR(500) NOT NULL, status VARCHAR(20) NOT NULL DEFAULT 'requested', refund_status VARCHAR(24) NOT NULL DEFAULT 'not_applicable', admin_note VARCHAR(500) NULL, admin_reply TEXT NULL, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
        "CREATE TABLE IF NOT EXISTS support_tickets (id INT AUTO_INCREMENT PRIMARY KEY, user_id INT NOT NULL, subject VARCHAR(160) NOT NULL, message TEXT NOT NULL, order_no VARCHAR(24) NULL, status VARCHAR(12) NOT NULL DEFAULT 'open', admin_reply TEXT NULL, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
        "CREATE TABLE IF NOT EXISTS customer_settings (user_id INT PRIMARY KEY, email_notifications TINYINT(1) NOT NULL DEFAULT 1, promo_notifications TINYINT(1) NOT NULL DEFAULT 1, preferred_contact VARCHAR(20) NOT NULL DEFAULT 'email') ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
        "CREATE TABLE IF NOT EXISTS site_settings (setting_key VARCHAR(100) PRIMARY KEY, setting_value TEXT NOT NULL, updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP)",
        "CREATE TABLE IF NOT EXISTS faqs (id INT AUTO_INCREMENT PRIMARY KEY, question VARCHAR(255) NOT NULL, answer TEXT NOT NULL, sort_order INT NOT NULL DEFAULT 0, is_published TINYINT(1) NOT NULL DEFAULT 1, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
        "CREATE TABLE IF NOT EXISTS inventory_adjustments (id INT AUTO_INCREMENT PRIMARY KEY, product_id INT NOT NULL, admin_id INT NULL, change_qty INT NOT NULL, reason VARCHAR(255) NOT NULL, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
    ];
    foreach ($tables as $sql) {
        try { q($sql); } catch (Throwable $e) { /* ignore */ }
    }
    if (table_exists('orders') && !column_exists('orders', 'user_id')) {
        try {
            q('ALTER TABLE orders ADD COLUMN user_id INT NULL');
        } catch (PDOException $e) {
            if (!column_exists('orders', 'user_id')) {
                throw $e;
            }
        }
    }
    if (table_exists('return_requests') && !column_exists('return_requests', 'refund_status')) {
        try {
            q("ALTER TABLE return_requests ADD COLUMN refund_status VARCHAR(24) NOT NULL DEFAULT 'not_applicable'");
        } catch (PDOException $e) {
            if (!column_exists('return_requests', 'refund_status')) {
                throw $e;
            }
        }
    }
    if (table_exists('return_requests') && !column_exists('return_requests', 'admin_reply')) {
        try {
            q('ALTER TABLE return_requests ADD COLUMN admin_reply TEXT NULL');
        } catch (PDOException $e) {
            if (!column_exists('return_requests', 'admin_reply')) {
                throw $e;
            }
        }
    }
    try {
        if (table_exists('faqs')) {
            q('UPDATE faqs SET answer = ?
               WHERE question = ? AND answer LIKE ?',
                [
                    (pesajet_enabled() ? 'MTN or Airtel mobile money, or cash on delivery. For mobile money you approve a prompt sent to your phone.' : 'MTN or Airtel mobile money, card, or cash on delivery. Card and mobile-money payments are simulated; no real money is taken.'),
                    'What payment methods do you accept?',
                    '%demo site payments run%',
                ]);
        }
        if (table_exists('faqs') && (int)q('SELECT COUNT(*) FROM faqs')->fetchColumn() === 0) {
            $defaults = [
                ['Are your appliances genuine?', 'Yes. We source from authorised distributors and every appliance comes with a manufacturer or store warranty of 12 to 24 months, stated on each product page.', 1],
                ['How long does delivery take?', 'Within Masaka City 1 to 2 working days, around Masaka 2 to 3 days and the rest of Uganda 3 to 6 days. See the Delivery page for fees and details.', 2],
                ['What payment methods do you accept?', (pesajet_enabled() ? 'MTN or Airtel mobile money, or cash on delivery. For mobile money you approve a prompt sent to your phone.' : 'MTN or Airtel mobile money, card, or cash on delivery. Card and mobile-money payments are simulated; no real money is taken.'), 3],
                ['Can I return an item?', 'Yes. Faulty or wrong items can be returned within 7 days of delivery. Unused items in original packaging can be returned within 7 days for a refund or exchange minus delivery cost. See Returns & warranty.', 4],
                ['Do appliances work with Uganda power supply?', 'All items are rated for 220 to 240 V, 50 Hz, the Ugandan standard. We also sell surge-protected extensions and solar lamps for outages.', 5],
                ['Is there a student discount?', 'Yes. Use code STUDENT10 in your cart for 10% off. Our Student Starter Bundle is also reduced.', 6],
                ['Do you keep my card details?', 'No. Card details are checked and discarded. We keep only the last four digits for your receipt.', 7],
            ];
            foreach ($defaults as [$qq,$aa,$ss]) {
                q('INSERT INTO faqs (question, answer, sort_order, is_published) VALUES (?,?,?,1)', [$qq,$aa,$ss]);
            }
        }
    } catch (Throwable $e) { /* ignore */ }
}
require __DIR__ . '/admin_notifications.php';
require __DIR__ . '/receipt.php';
ensure_tables();

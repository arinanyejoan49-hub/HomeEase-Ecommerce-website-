<?php
function product_card(array $p, bool $featured = false): void
{
    $off = discount_pct($p);
    $out = $p['stock'] < 1;
    ?>
    <article class="card product<?= $featured ? ' featured-product-card' : '' ?>">
      <a class="media" href="<?= e(url('product.php?slug=' . $p['slug'])) ?>">
        <?= product_media($p) ?>
        <?php if ($featured): ?><span class="badge featured-label">Featured</span><?php endif; ?>
        <?php if ($off): ?><span class="badge sale">-<?= $off ?>%</span><?php endif; ?>
      </a>
      <div class="body">
        <p class="brand-line"><a href="<?= e(url('products.php?brand=' . rawurlencode($p['brand']))) ?>"><?= e($p['brand']) ?></a> <?= energy_badge($p['energy_rating']) ?></p>
        <?php if ($featured && !empty($p['category_name'])): ?><p class="product-category"><?= e($p['category_name']) ?></p><?php endif; ?>
        <h3><a href="<?= e(url('product.php?slug=' . $p['slug'])) ?>"><?= e($p['name']) ?></a></h3>
        <p class="rating-line"><?= product_rating_html((int)$p['id']) ?></p>
        <p class="price"><strong><?= e(money($p['price'])) ?></strong>
          <?php if ($off): ?><s><?= e(money($p['old_price'])) ?></s><?php endif; ?></p>
        <?php if ($out): ?>
          <p class="stock out">Out of stock</p>
        <?php else: ?>
          <?php if ($featured): ?>
            <p class="stock <?= $p['stock'] <= 5 ? 'low' : 'ok' ?>"><?= $p['stock'] <= 5 ? 'Only ' . (int)$p['stock'] . ' left in stock' : 'In stock' ?></p>
          <?php elseif ($p['stock'] <= 5): ?>
            <p class="stock low">Only <?= (int)$p['stock'] ?> left</p>
          <?php endif; ?>
          <form method="post" action="<?= e(url('cart.php')) ?>">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="add">
            <input type="hidden" name="id" value="<?= (int)$p['id'] ?>">
            <button class="btn block" type="submit"><?= $featured ? 'Add to Cart' : 'Add to cart' ?></button>
          </form>
        <?php endif; ?>
        <?php if ($featured): ?>
          <a class="btn block ghost featured-view" href="<?= e(url('product.php?slug=' . $p['slug'])) ?>">View Product</a>
          <a class="featured-wishlist" href="<?= e(url('wishlist.php?action=' . (is_wishlisted((int)$p['id']) ? 'remove' : 'add') . '&id=' . (int)$p['id'])) ?>"><?= is_wishlisted((int)$p['id']) ? 'Remove from wishlist' : '♡ Add to wishlist' ?></a>
        <?php endif; ?>
      </div>
    </article>
    <?php
}

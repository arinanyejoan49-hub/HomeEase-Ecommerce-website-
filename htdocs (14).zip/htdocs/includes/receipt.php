<?php
declare(strict_types=1);

/**
 * Payment receipts.
 *
 * A receipt is issued once an order is PAID (card / mobile money at checkout or when PesaJet confirms,
 * cash on delivery when the admin marks the order delivered). Each receipt is recorded in `order_receipts`,
 * shown on receipt.php (print or "Save as PDF" from the browser) and emailed to the customer.
 *
 * Nothing here may break checkout or payment handling, so every public function fails quietly.
 */

function receipt_is_paid(array $order): bool
{
    // 'paid', 'paid (simulated)', 'paid on delivery'. Not: 'pay on delivery', 'awaiting payment', 'payment failed'.
    return stripos((string)($order['payment_status'] ?? ''), 'paid') === 0;
}

function receipt_number(array $order): string
{
    return 'RC-' . $order['order_no'];
}

function receipt_token(array $order): string
{
    $key = hash('sha256', 'receipt|' . DB_NAME . '|' . DB_PASS . '|' . EMAIL_SMTP_PASSWORD);
    return substr(hash_hmac('sha256', $order['order_no'] . '|' . strtolower((string)$order['email']), $key), 0, 32);
}

/** Relative (site) or absolute link to the receipt page. The token lets a guest customer open it from their email. */
function receipt_path(array $order): string
{
    return 'receipt.php?no=' . rawurlencode((string)$order['order_no']) . '&t=' . receipt_token($order);
}

function receipt_url(array $order, bool $absolute = false): string
{
    return $absolute ? rtrim(SITE_URL, '/') . url(receipt_path($order)) : url(receipt_path($order));
}

function receipt_ready(): bool
{
    static $ok = null;
    if ($ok === null) {
        try {
            $ok = table_exists('order_receipts');
        } catch (Throwable $e) {
            $ok = false;
        }
    }
    return $ok;
}

function receipt_record(int $orderId): ?array
{
    try {
        if (!receipt_ready()) {
            return null;
        }
        return q('SELECT * FROM order_receipts WHERE order_id = ?', [$orderId])->fetch() ?: null;
    } catch (Throwable $e) {
        return null;
    }
}

/** Make sure a receipt row exists for a paid order. Returns the row, with '_new' => true when it was just created. */
function receipt_issue(array $order): ?array
{
    try {
        if (!receipt_ready() || !receipt_is_paid($order)) {
            return null;
        }
        $existing = receipt_record((int)$order['id']);
        if ($existing) {
            $existing['_new'] = false;
            return $existing;
        }
        try {
            q('INSERT INTO order_receipts (order_id, receipt_no, issued_at) VALUES (?, ?, ?)', [(int)$order['id'], receipt_number($order), date('Y-m-d H:i:s')]);
            $row = receipt_record((int)$order['id']);
            if ($row) {
                $row['_new'] = true;
            }
            return $row;
        } catch (Throwable $e) {
            // Lost a race with another request that issued it first.
            $row = receipt_record((int)$order['id']);
            if ($row) {
                $row['_new'] = false;
            }
            return $row;
        }
    } catch (Throwable $e) {
        error_log('receipt_issue failed: ' . $e->getMessage());
        return null;
    }
}

function receipt_payment_label(array $order): string
{
    switch ($order['payment_method']) {
        case 'momo':
            return 'Mobile money';
        case 'card':
            return 'Card' . (!empty($order['card_last4']) ? ' ending ' . $order['card_last4'] : '');
        case 'cod':
            return 'Cash on delivery';
        default:
            return ucfirst((string)$order['payment_method']);
    }
}

/** The receipt itself: table layout with inline styles so it renders the same in a browser and in an email client. */
function receipt_html(array $o, array $items, string $issuedAt): string
{
    $zone = ZONES[$o['zone']] ?? ['Delivery', 0, ''];
    $first = explode(' ', trim((string)$o['customer_name']))[0];
    $td = 'padding:8px 0;border-bottom:1px solid #E5E5E5;font-size:14px;';
    ob_start();
    ?>
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:640px;margin:0 auto;background:#FFFFFF;border:1px solid #E5E5E5;border-radius:12px;overflow:hidden;font-family:Arial,Helvetica,sans-serif;color:#333333;">
  <tr><td style="background:#FF7900;padding:20px 28px;">
    <table role="presentation" width="100%" cellpadding="0" cellspacing="0"><tr>
      <td style="font-size:24px;font-weight:700;color:#111111;"><?= e(SITE_NAME) ?></td>
      <td align="right" style="font-size:13px;font-weight:700;letter-spacing:1px;color:#111111;">PAYMENT RECEIPT</td>
    </tr></table>
  </td></tr>
  <tr><td style="padding:26px 28px 8px;">
    <p style="margin:0 0 4px;font-size:15px;">Thank you, <?= e($first) ?>. We have received your payment.</p>
    <p style="margin:0;font-size:30px;font-weight:700;color:#111111;"><?= e(money($o['total'])) ?> <span style="display:inline-block;vertical-align:middle;margin-left:8px;padding:3px 10px;border-radius:999px;background:#E7F5EC;color:#16803C;font-size:12px;font-weight:700;letter-spacing:.5px;">PAID</span></p>
  </td></tr>
  <tr><td style="padding:12px 28px;">
    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="font-size:14px;">
      <tr><td style="padding:4px 0;color:#737373;width:38%;">Receipt no.</td><td style="padding:4px 0;"><b><?= e(receipt_number($o)) ?></b></td></tr>
      <tr><td style="padding:4px 0;color:#737373;">Date issued</td><td style="padding:4px 0;"><?= e(date('j M Y, H:i', strtotime($issuedAt))) ?></td></tr>
      <tr><td style="padding:4px 0;color:#737373;">Order no.</td><td style="padding:4px 0;"><?= e($o['order_no']) ?></td></tr>
      <tr><td style="padding:4px 0;color:#737373;">Payment method</td><td style="padding:4px 0;"><?= e(receipt_payment_label($o)) ?></td></tr>
      <?php if (!empty($o['payment_ref'])): ?><tr><td style="padding:4px 0;color:#737373;">Payment reference</td><td style="padding:4px 0;"><?= e(payment_reference_label((string)$o['payment_ref'])) ?></td></tr><?php endif; ?>
      <tr><td style="padding:4px 0;color:#737373;">Payment status</td><td style="padding:4px 0;"><?= e(ucfirst(payment_status_label((string)$o['payment_status']))) ?></td></tr>
      <tr><td style="padding:4px 0;color:#737373;vertical-align:top;">Billed to</td><td style="padding:4px 0;"><?= e($o['customer_name']) ?><br><?= e($o['email']) ?><br><?= e($o['phone']) ?></td></tr>
      <tr><td style="padding:4px 0;color:#737373;vertical-align:top;">Delivery</td><td style="padding:4px 0;"><?= e($zone[0]) ?><br><?= e($o['address']) ?></td></tr>
    </table>
  </td></tr>
  <tr><td style="padding:12px 28px 0;">
    <table role="presentation" width="100%" cellpadding="0" cellspacing="0">
      <tr>
        <th align="left" style="<?= $td ?>border-bottom:2px solid #111111;color:#111111;">Item</th>
        <th align="center" style="<?= $td ?>border-bottom:2px solid #111111;color:#111111;">Qty</th>
        <th align="right" style="<?= $td ?>border-bottom:2px solid #111111;color:#111111;">Price</th>
        <th align="right" style="<?= $td ?>border-bottom:2px solid #111111;color:#111111;">Total</th>
      </tr>
      <?php foreach ($items as $i): ?>
      <tr>
        <td style="<?= $td ?>"><?= e($i['name']) ?></td>
        <td align="center" style="<?= $td ?>"><?= (int)$i['qty'] ?></td>
        <td align="right" style="<?= $td ?>"><?= e(money($i['price'])) ?></td>
        <td align="right" style="<?= $td ?>"><?= e(money($i['price'] * $i['qty'])) ?></td>
      </tr>
      <?php endforeach; ?>
    </table>
  </td></tr>
  <tr><td style="padding:8px 28px 20px;">
    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="font-size:14px;">
      <tr><td align="right" style="padding:4px 0;color:#737373;">Subtotal</td><td align="right" style="padding:4px 0;width:130px;"><?= e(money($o['subtotal'])) ?></td></tr>
      <?php if ((int)$o['discount'] > 0): ?><tr><td align="right" style="padding:4px 0;color:#16803C;">Discount<?= $o['coupon'] ? ' (' . e($o['coupon']) . ')' : '' ?></td><td align="right" style="padding:4px 0;color:#16803C;">-<?= e(money($o['discount'])) ?></td></tr><?php endif; ?>
      <tr><td align="right" style="padding:4px 0;color:#737373;">Delivery</td><td align="right" style="padding:4px 0;"><?= (int)$o['delivery_fee'] > 0 ? e(money($o['delivery_fee'])) : 'Free' ?></td></tr>
      <tr><td align="right" style="padding:10px 0 0;font-size:16px;font-weight:700;color:#111111;border-top:2px solid #111111;">Total paid</td><td align="right" style="padding:10px 0 0;font-size:16px;font-weight:700;color:#FF7900;border-top:2px solid #111111;"><?= e(money($o['total'])) ?></td></tr>
    </table>
  </td></tr>
  <tr><td style="background:#FFF9F3;padding:16px 28px;font-size:12px;color:#737373;line-height:1.6;">
    Questions about this receipt? Email <?= e(SITE_EMAIL) ?> or call <?= e(SITE_PHONE) ?>.<br>
    This is a computer-generated receipt and is valid without a signature.
  </td></tr>
</table>
    <?php
    return (string)ob_get_clean();
}

function receipt_text(array $o, array $items, string $issuedAt): string
{
    $lines = [
        SITE_NAME . ' - PAYMENT RECEIPT',
        '',
        'Thank you, ' . explode(' ', trim((string)$o['customer_name']))[0] . '. We have received your payment.',
        '',
        'Receipt no.:    ' . receipt_number($o),
        'Date issued:    ' . date('j M Y, H:i', strtotime($issuedAt)),
        'Order no.:      ' . $o['order_no'],
        'Payment method: ' . receipt_payment_label($o),
    ];
    if (!empty($o['payment_ref'])) {
        $lines[] = 'Reference:      ' . payment_reference_label((string)$o['payment_ref']);
    }
    $lines[] = '';
    foreach ($items as $i) {
        $lines[] = $i['name'] . ' x ' . (int)$i['qty'] . '  ' . money($i['price'] * $i['qty']);
    }
    $lines[] = '';
    $lines[] = 'Subtotal: ' . money($o['subtotal']);
    if ((int)$o['discount'] > 0) {
        $lines[] = 'Discount: -' . money($o['discount']);
    }
    $lines[] = 'Delivery: ' . ((int)$o['delivery_fee'] > 0 ? money($o['delivery_fee']) : 'Free');
    $lines[] = 'TOTAL PAID: ' . money($o['total']);
    $lines[] = '';
    $lines[] = 'View or print this receipt: ' . receipt_url($o, true);
    $lines[] = '';
    $lines[] = SITE_NAME . ' | ' . SITE_EMAIL . ' | ' . SITE_PHONE;
    return implode("\n", $lines);
}

/**
 * Issue the receipt for a paid order (once) and email it to the customer.
 * $force = true re-sends the email even if it was already sent (admin "Resend").
 * Returns ['issued' => bool, 'emailed' => bool, 'error' => string].
 */
function receipt_issue_and_send(int $orderId, bool $force = false): array
{
    $result = ['issued' => false, 'emailed' => false, 'error' => ''];
    try {
        $o = q('SELECT * FROM orders WHERE id = ?', [$orderId])->fetch();
        if (!$o || !receipt_is_paid($o)) {
            $result['error'] = 'This order has not been paid yet.';
            return $result;
        }
        $rec = receipt_issue($o);
        if (!$rec) {
            $result['error'] = 'The receipt could not be created.';
            return $result;
        }
        $result['issued'] = true;

        if (!empty($rec['_new']) && !empty($o['user_id'])) {
            customer_notify((int)$o['user_id'], 'Receipt ready', 'Your receipt for order ' . $o['order_no'] . ' is ready to view or print.', receipt_path($o));
        }
        if (!empty($rec['emailed_at']) && !$force) {
            $result['emailed'] = true;
            return $result;
        }

        if (!function_exists('send_store_email')) {
            require_once __DIR__ . '/email.php';
        }
        if (!email_smtp_configured()) {
            q('UPDATE order_receipts SET email_status = ?, email_error = ? WHERE id = ?', ['not_configured', 'SMTP is not configured.', (int)$rec['id']]);
            $result['error'] = 'Email is not set up, so the receipt could not be emailed.';
            return $result;
        }

        $items = q('SELECT * FROM order_items WHERE order_id = ? ORDER BY id', [$orderId])->fetchAll();
        $html = '<!DOCTYPE html><html><body style="margin:0;padding:20px;background:#F5F5F5;">'
            . receipt_html($o, $items, (string)$rec['issued_at'])
            . '<p style="text-align:center;font-family:Arial,Helvetica,sans-serif;font-size:13px;color:#737373;">'
            . '<a href="' . e(receipt_url($o, true)) . '" style="color:#E65C00;">View or print this receipt online</a></p></body></html>';
        $sent = send_store_email(
            (string)$o['email'],
            (string)$o['customer_name'],
            SITE_NAME . ' receipt ' . receipt_number($o),
            receipt_text($o, $items, (string)$rec['issued_at']),
            null,
            null,
            $html
        );
        if (!empty($sent['success'])) {
            q('UPDATE order_receipts SET emailed_at = ?, email_status = ?, email_error = NULL WHERE id = ?', [date('Y-m-d H:i:s'), 'sent', (int)$rec['id']]);
            $result['emailed'] = true;
        } else {
            $err = (string)($sent['error'] ?? 'Unknown error');
            q('UPDATE order_receipts SET email_status = ?, email_error = ? WHERE id = ?', [(string)($sent['state'] ?? 'failed'), mb_substr($err, 0, 255), (int)$rec['id']]);
            $result['error'] = $err;
        }
    } catch (Throwable $e) {
        error_log('receipt_issue_and_send failed: ' . $e->getMessage());
        $result['error'] = 'Something went wrong while sending the receipt.';
    }
    return $result;
}

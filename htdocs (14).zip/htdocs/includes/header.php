<?php
// Usage: $title = 'Page title'; $desc = '...'; require 'includes/header.php';
$title = $title ?? SITE_NAME;
$desc = $desc ?? 'Affordable kitchen and home appliances for students and families in Uganda. Genuine warranty, fast Masaka delivery, pay with mobile money or on delivery.';
$cats = q('SELECT * FROM categories ORDER BY sort_order')->fetchAll();
$cartN = cart_count();
$here = basename($_SERVER['SCRIPT_NAME'] ?? '');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($title === SITE_NAME ? SITE_NAME . ' | Affordable Home Appliances Uganda' : $title . ' | ' . SITE_NAME) ?></title>
<meta name="description" content="<?= e($desc) ?>">
<meta name="theme-color" content="#FF7900">
<link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Cpath d='M50 10 L90 90 L10 90 Z' fill='%23e87924'/%3E%3C/svg%3E">
<link rel="stylesheet" href="<?= e(url('assets/css/style.css?v=' . filemtime(__DIR__ . '/../assets/css/style.css'))) ?>">
</head>
<body class="<?= $here === 'login.php' ? 'login-shell' : '' ?>" data-ga="<?= e(GA_ID) ?>">
<a class="skip" href="#main">Skip to content</a>
<div class="topbar">
  <div class="wrap">
    <span><svg aria-hidden="true" width="16" height="16" viewBox="0 0 24 24" style="vertical-align:-2px;"><path d="M21 10V5c0-1.1-.9-2-2-2H5c-1.1 0-2 .9-2 2v14l7-3.73 7 3.73V10c0-1.1.9-2 2-2z"/></svg> Free Masaka delivery over <?= e(money(FREE_DELIVERY_FROM)) ?></span>
    <span class="hide-sm"><svg aria-hidden="true" width="16" height="16" viewBox="0 0 24 24" style="vertical-align:-2px;"><path d="M20 13H4v-2h16v2zm0-4H4v-2h16v2zm0-6v2H4V3h16z"/></svg> Students: use code <strong>STUDENT10</strong> for 10% off</span>
    <span><svg aria-hidden="true" width="16" height="16" viewBox="0 0 24 24" style="vertical-align:-1px;"><path d="M6.62 10.79c1.44-2.83 3.75-4.81 6.59-4.81 1.94 0 3.57 1.1 4.5 2.78.93-1.68 2.56-2.78 4.5-2.78 2.84 0 5.15 1.98 6.59 4.81L20 15H4zM12 17a3 3 0 1 0 0-6 3 3 0 0 0 0 6z"/></svg> <?= e(SITE_PHONE) ?></span>
  </div>
</div>
<header class="site-header">
  <div class="wrap header-row">
    <a class="brand" href="<?= e(url('index.php')) ?>"><span class="logo"><svg width="24" height="24" viewBox="0 0 24 24" aria-hidden="true"><path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z"/></svg></span><?= e(SITE_NAME) ?></a>
    <form class="search" action="<?= e(url('products.php')) ?>" method="get" role="search">
      <label class="sr" for="q">Search products</label>
      <input id="q" type="search" name="q" placeholder="Search kettle, fridge, blender…" value="<?= e($_GET['q'] ?? '') ?>">
      <button type="submit" aria-label="Search"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false" class="icon"><circle cx="11" cy="11" r="7"/><path d="m21 21-4.35-4.35"/></svg></button>
    </form>
    <a class="nav-icon" href="<?= e(url('wishlist.php')) ?>" aria-label="Wishlist"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false" class="icon"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg></a>
    <?php if (is_customer()): ?>
      <a class="nav-icon" href="<?= e(url('customer/dashboard.php')) ?>" aria-label="My Account"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false" class="icon"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg></a>
    <?php else: ?>
      <a class="nav-icon" href="<?= e(url('login.php')) ?>" aria-label="Login"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false" class="icon"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg></a>
    <?php endif; ?>
    <a class="cart-link" href="<?= e(url('cart.php')) ?>" aria-label="Cart, <?= $cartN ?> items"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false" class="icon"><circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/></svg> <span>Cart</span><b class="cart-badge"><?= $cartN ?></b></a>
    <button class="menu-btn" type="button" aria-expanded="false" aria-controls="nav" aria-label="Menu"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false" class="icon"><path d="M3 6h18M3 12h18M3 18h18"/></svg></button>
  </div>
  <nav id="nav" class="main-nav" aria-label="Main">
    <div class="wrap">
      <a href="<?= e(url('index.php')) ?>" class="<?= $here === 'index.php' ? 'on' : '' ?>">Home</a>
      <a href="<?= e(url('categories.php')) ?>" class="<?= $here === 'categories.php' ? 'on' : '' ?>">Categories</a>
      <a href="<?= e(url('products.php')) ?>" class="<?= $here === 'products.php' && empty($_GET['cat']) ? 'on' : '' ?>">All products</a>
      <?php if (is_customer()): ?>
        <a href="<?= e(url('customer/dashboard.php')) ?>" class="<?= $here === 'customer/dashboard.php' ? 'on' : '' ?>">My Account</a>
        <a href="<?= e(url('logout.php')) ?>" class="<?= $here === 'logout.php' ? 'on' : '' ?>">Logout</a>
      <?php else: ?>
        <a href="<?= e(url('wishlist.php')) ?>" class="<?= $here === 'wishlist.php' ? 'on' : '' ?>">Wishlist</a>
        <a href="<?= e(url('login.php')) ?>" class="<?= $here === 'login.php' ? 'on' : '' ?>">Login</a>
      <?php endif; ?>
    </div>
  </nav>
</header>
<main id="main" class="wrap">
<?php foreach (flashes() as [$type, $msg]): ?>
  <div class="alert <?= e($type) ?>" role="alert"><?= e($msg) ?></div>
<?php endforeach; ?>

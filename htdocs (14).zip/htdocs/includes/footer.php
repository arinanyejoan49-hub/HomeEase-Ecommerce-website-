</main>
<footer class="site-footer">
  <div class="wrap footer-grid">
    <div>
      <h3><?= e(SITE_NAME) ?></h3>
      <p>Affordable, genuine kitchen and home appliances for students and families across Uganda.</p>
      <?php
      $telDigits = preg_replace('/\D/', '', (string)SITE_PHONE);
      $telHref = 'tel:' . (strncmp($telDigits, '0', 1) === 0 ? '+256' . substr($telDigits, 1) : '+' . $telDigits);
      ?>
      <div class="footer-contact">
        <a href="<?= e($telHref) ?>"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.13.96.36 1.9.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.91.34 1.85.57 2.81.7A2 2 0 0 1 22 16.92z"/></svg> <span><?= e(SITE_PHONE) ?></span></a>
        <a href="mailto:<?= e(SITE_EMAIL) ?>"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="m22 7-10 6L2 7"/></svg> <span><?= e(SITE_EMAIL) ?></span></a>
        <a href="https://wa.me/<?= e(SITE_WHATSAPP) ?>?text=Hello%20<?= e(rawurlencode(SITE_NAME)) ?>%2C%20I%20need%20help%20with%20an%20appliance" target="_blank" rel="noopener"><svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" focusable="false"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/></svg> <span>Chat on WhatsApp</span></a>
      </div>
    </div>
    <div>
      <h3>Shop</h3>
      <?php foreach ($cats as $c): ?>
        <a href="<?= e(url('products.php?cat=' . $c['slug'])) ?>"><?= e($c['name']) ?></a>
      <?php endforeach; ?>
    </div>
    <div>
      <h3>Help</h3>
      <a href="<?= e(url('contact.php')) ?>">Contact us</a>
      <a href="<?= e(url('faq.php')) ?>">FAQ</a>
      <a href="<?= e(url('track.php')) ?>">Track your order</a>
      <a href="<?= e(url('delivery.php')) ?>">Delivery information</a>
      <a href="<?= e(url('returns.php')) ?>">Returns &amp; warranty</a>
    </div>
    <div>
      <h3>About</h3>
      <a href="<?= e(url('about.php')) ?>">About <?= e(SITE_NAME) ?></a>
      <a href="<?= e(url('sustainability.php')) ?>">Sustainability &amp; ethics</a>
      <a href="<?= e(url('privacy.php')) ?>">Privacy policy</a>
      <a href="<?= e(url('terms.php')) ?>">Terms &amp; conditions</a>
    </div>
  </div>
  <div class="wrap legal">
    <span>© <?= date('Y') ?> <?= e(SITE_NAME) ?>. All rights reserved.</span>
  </div>
</footer>

<?php if ($here === 'products.php'): ?>
<button class="back-to-top" type="button" aria-label="Back to top" title="Back to top" hidden>
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" aria-hidden="true"><path d="m18 15-6-6-6 6"/><path d="M12 9v12"/></svg>
</button>
<?php endif; ?>
<a class="wa-float" href="https://wa.me/<?= e(SITE_WHATSAPP) ?>?text=Hello%20<?= e(rawurlencode(SITE_NAME)) ?>%2C%20I%20need%20help%20with%20an%20appliance" target="_blank" rel="noopener" aria-label="Chat on WhatsApp"><svg class="wa-icon" width="24" height="24" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/></svg> <span>Chat</span></a>

<div id="consent" class="consent" hidden>
  <p>We use cookies for the cart and, if you agree, Google Analytics to understand how the site is used. See our <a href="<?= e(url('privacy.php')) ?>">privacy policy</a>.</p>
  <div><button type="button" class="btn small" data-consent="yes">Accept</button> <button type="button" class="btn small ghost" data-consent="no">Decline</button></div>
</div>
<nav class="bottom-nav">
  <a href="<?= e(url('index.php')) ?>" class="<?= $here === 'index.php' ? 'on' : '' ?>" aria-label="Home">
    <svg aria-hidden="true"><path d="M3 12l2-2m0 0l7-7 7 7M3 12v10a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V12z"/></svg>
    <span>Home</span>
  </a>
  <a href="<?= e(url('categories.php')) ?>" class="<?= $here === 'categories.php' ? 'on' : '' ?>" aria-label="Categories">
    <svg aria-hidden="true"><path d="M20 13V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v12m8 0V6m0 0l8 8-8-8m8 8H4m0 0l8-8"/></svg>
    <span>Categories</span>
  </a>
  <a href="<?= e(url('cart.php')) ?>" class="<?= $here === 'cart.php' ? 'on' : '' ?>" aria-label="Cart">
    <svg aria-hidden="true"><circle cx="1" cy="5" r="1"/><circle cx="4" cy="5" r="1"/><path d="M5 19H2l1-3.5A2 2 0 0 1 4.5 15H18a2 2 0 0 1 1.61.85l1.78 3.57A2 2 0 0 1 20.83 21H6.12"/></svg>
    <span>Cart</span>
    <?php if ($cartN > 0): ?><span class="cart-badge" style="font-size:.62rem;"><?= (int)$cartN ?></span><?php endif; ?>
  </a>
  <a href="<?= e(url('wishlist.php')) ?>" class="<?= $here === 'wishlist.php' ? 'on' : '' ?>" aria-label="Wishlist">
    <svg aria-hidden="true"><path d="M19 14c1.49-1.46 3 3.21 3 5.5 0 5.5-9 9-9 9s-9-3.5-9-9c0-2.3 1.5-4.05 3-5.53L12 7l3 3.47z"/></svg>
    <span>Wishlist</span>
  </a>
  <?php if (is_customer()): ?>
    <a href="<?= e(url('customer/dashboard.php')) ?>" class="<?= $here === 'customer/dashboard.php' ? 'on' : '' ?>" aria-label="My Account">
      <svg aria-hidden="true"><circle cx="12" cy="12" r="10"/><path d="M12 6v6m4 6v6m-4-6v6"/></svg>
      <span>Account</span>
    </a>
  <?php else: ?>
    <a href="<?= e(url('login.php')) ?>" class="<?= $here === 'login.php' ? 'on' : '' ?>" aria-label="Login">
      <svg aria-hidden="true"><circle cx="12" cy="12" r="10"/><path d="M12 6v6m4 6v6m-4-6v6"/></svg>
      <span>Login</span>
    </a>
  <?php endif; ?>
</nav>
<script src="<?= e(url('assets/js/app.js?v=' . filemtime(__DIR__ . '/../assets/js/app.js'))) ?>"></script>
</body>
</html>

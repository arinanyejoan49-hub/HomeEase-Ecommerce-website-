<?php
declare(strict_types=1);

/**
 * Admin-side notifications.
 *
 * Customers keep using the existing `notifications` table (it is keyed to users.id).
 * Admins live in a separate table, so their alerts go in `admin_notifications`,
 * which is a shared feed for every admin account.
 *
 * Every function here fails quietly: a notification problem must never break
 * checkout, registration, or any other customer action.
 */

function admin_notif_ready(): bool
{
    static $ok = null;
    if ($ok === null) {
        try {
            $ok = table_exists('admin_notifications');
        } catch (Throwable $e) {
            $ok = false;
        }
    }
    return $ok;
}

/** Display metadata for each notification type: label, colour, icon path. */
function admin_notif_types(): array
{
    return [
        'order'    => ['label' => 'Orders',    'color' => '#FF7900', 'icon' => '<path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/><path d="M3 6h18"/><path d="M16 10a4 4 0 0 1-8 0"/>'],
        'payment'  => ['label' => 'Payments',  'color' => '#16803C', 'icon' => '<rect x="2" y="5" width="20" height="14" rx="2"/><path d="M2 10h20"/>'],
        'message'  => ['label' => 'Enquiries', 'color' => '#1e40af', 'icon' => '<path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><path d="m22 6-10 7L2 6"/>'],
        'support'  => ['label' => 'Support',   'color' => '#B54708', 'icon' => '<path d="M21 11.5a8.4 8.4 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.4 8.4 0 0 1-3.8-.9L3 21l1.9-5.7a8.4 8.4 0 0 1-.9-3.8A8.5 8.5 0 0 1 8.7 3.9a8.4 8.4 0 0 1 3.8-.9h.5a8.5 8.5 0 0 1 8 8z"/>'],
        'return'   => ['label' => 'Returns',   'color' => '#7c3aed', 'icon' => '<path d="M3 7v6h6"/><path d="M21 17a9 9 0 0 0-15-6.7L3 13"/>'],
        'customer' => ['label' => 'Customers', 'color' => '#0e7490', 'icon' => '<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>'],
        'review'   => ['label' => 'Reviews',   'color' => '#FF7900', 'icon' => '<path d="M12 2.5l2.9 6.1 6.6.9-4.8 4.6 1.2 6.6L12 17.5l-5.9 3.2 1.2-6.6L2.5 9.5l6.6-.9z"/>'],
        'stock'    => ['label' => 'Stock',     'color' => '#D92D20', 'icon' => '<path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/>'],
    ];
}

/** Create a notification. $link is a site-relative path such as 'admin/order.php?id=5'. */
function admin_notify(string $type, string $title, string $message, ?string $link = null): void
{
    try {
        if (!admin_notif_ready()) {
            return;
        }
        q(
            'INSERT INTO admin_notifications (type, title, message, link) VALUES (?, ?, ?, ?)',
            [
                mb_substr($type, 0, 24),
                mb_substr($title, 0, 160),
                mb_substr($message, 0, 500),
                $link !== null && $link !== '' ? mb_substr($link, 0, 255) : null,
            ]
        );
    } catch (Throwable $e) {
        error_log('admin_notify failed: ' . $e->getMessage());
    }
}

/**
 * Like admin_notify(), but if an UNREAD notification with the same type + link already
 * exists it is refreshed instead of duplicated (used for low-stock alerts).
 */
function admin_notify_once(string $type, string $title, string $message, string $link): void
{
    try {
        if (!admin_notif_ready()) {
            return;
        }
        $existing = q(
            'SELECT id FROM admin_notifications WHERE type = ? AND link = ? AND is_read = 0 ORDER BY id DESC LIMIT 1',
            [$type, $link]
        )->fetchColumn();
        if ($existing) {
            q(
                'UPDATE admin_notifications SET title = ?, message = ?, created_at = ? WHERE id = ?',
                [mb_substr($title, 0, 160), mb_substr($message, 0, 500), date('Y-m-d H:i:s'), (int)$existing]
            );
            return;
        }
        admin_notify($type, $title, $message, $link);
    } catch (Throwable $e) {
        error_log('admin_notify_once failed: ' . $e->getMessage());
    }
}

/** After stock is deducted, raise "low stock" / "out of stock" alerts (same thresholds as admin/inventory.php). */
function admin_notify_low_stock(array $productIds): void
{
    try {
        foreach (array_unique(array_map('intval', $productIds)) as $pid) {
            if ($pid <= 0) {
                continue;
            }
            $p = q('SELECT id, name, stock FROM products WHERE id = ?', [$pid])->fetch();
            if (!$p || (int)$p['stock'] > 5) {
                continue;
            }
            $stock = (int)$p['stock'];
            admin_notify_once(
                'stock',
                $stock < 1 ? 'Out of stock' : 'Low stock',
                $stock < 1
                    ? $p['name'] . ' is now out of stock.'
                    : $p['name'] . ' is running low: ' . $stock . ' left.',
                'admin/inventory.php?product=' . $pid
            );
        }
    } catch (Throwable $e) {
        error_log('admin_notify_low_stock failed: ' . $e->getMessage());
    }
}

function admin_notif_unread_count(): int
{
    try {
        return admin_notif_ready()
            ? (int)q('SELECT COUNT(*) FROM admin_notifications WHERE is_read = 0')->fetchColumn()
            : 0;
    } catch (Throwable $e) {
        return 0;
    }
}

function admin_notif_recent(int $limit = 8): array
{
    try {
        if (!admin_notif_ready()) {
            return [];
        }
        $limit = max(1, min(50, $limit));
        return q('SELECT * FROM admin_notifications ORDER BY id DESC LIMIT ' . $limit)->fetchAll();
    } catch (Throwable $e) {
        return [];
    }
}

function admin_notif_time_ago(string $datetime): string
{
    $ts = strtotime($datetime);
    if (!$ts) {
        return '';
    }
    $diff = max(0, time() - $ts);
    if ($diff < 60) {
        return 'Just now';
    }
    if ($diff < 3600) {
        return (int)floor($diff / 60) . ' min ago';
    }
    if ($diff < 86400) {
        return (int)floor($diff / 3600) . ' hr ago';
    }
    if ($diff < 7 * 86400) {
        return (int)floor($diff / 86400) . ' day' . ((int)floor($diff / 86400) === 1 ? '' : 's') . ' ago';
    }
    return date('j M Y', $ts);
}

/** Shape one row for the dropdown / JSON endpoint. Clicking goes through notifications.php?go=ID so it is marked read. */
function admin_notif_item(array $n): array
{
    $types = admin_notif_types();
    $type = isset($types[$n['type']]) ? $n['type'] : 'order';
    return [
        'id'      => (int)$n['id'],
        'type'    => $type,
        'title'   => (string)$n['title'],
        'message' => (string)$n['message'],
        'read'    => (int)$n['is_read'] === 1,
        'time'    => admin_notif_time_ago((string)$n['created_at']),
        'url'     => url('admin/notifications.php?go=' . (int)$n['id']),
        'color'   => $types[$type]['color'],
        'icon'    => $types[$type]['icon'],
    ];
}

/** Create a notification for a customer (stored in the existing `notifications` table, shown on customer/notifications.php). */
function customer_notify(int $userId, string $title, string $message, ?string $link = null): void
{
    try {
        if ($userId <= 0 || !table_exists('notifications')) {
            return;
        }
        q(
            'INSERT INTO notifications (user_id, title, message, link) VALUES (?, ?, ?, ?)',
            [$userId, mb_substr($title, 0, 160), mb_substr($message, 0, 500), $link !== null && $link !== '' ? mb_substr($link, 0, 255) : null]
        );
    } catch (Throwable $e) {
        error_log('customer_notify failed: ' . $e->getMessage());
    }
}

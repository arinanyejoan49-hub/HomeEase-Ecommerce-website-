<?php
/**
 * "Continue with Google" for customers (OAuth 2.0 authorization-code flow with PKCE).
 * Setup: see README.md > Google sign-in. Needs GOOGLE_CLIENT_ID / GOOGLE_CLIENT_SECRET in config.local.php.
 */

function google_login_enabled(): bool
{
    return GOOGLE_CLIENT_ID !== '' && GOOGLE_CLIENT_SECRET !== '' && function_exists('curl_init') && table_exists('users');
}

/** Why Google sign-in can't run right now (empty string when it can). */
function google_login_problem(): string
{
    if (GOOGLE_CLIENT_ID === '' || GOOGLE_CLIENT_SECRET === '') {
        return 'Google sign-in is not set up yet. The site administrator needs to add the Google client ID and secret.';
    }
    if (!function_exists('curl_init')) {
        return 'Google sign-in is unavailable because this server does not have the cURL extension enabled.';
    }
    if (!table_exists('users')) {
        return 'Google sign-in is unavailable until the customer account tables are installed.';
    }
    return '';
}

/** The address Google sends the visitor back to. Register exactly this in Google Cloud Console. */
function google_redirect_uri(): string
{
    if (GOOGLE_REDIRECT_URI !== '') {
        return GOOGLE_REDIRECT_URI;
    }
    $host = $_SERVER['HTTP_HOST'] ?? parse_url(SITE_URL, PHP_URL_HOST);
    return (request_is_https() ? 'https' : 'http') . '://' . $host . url('google-callback.php');
}

function google_b64url(string $bin): string
{
    return rtrim(strtr(base64_encode($bin), '+/', '-_'), '=');
}

/** Build the Google consent-screen address and remember the one-time values in the session. */
function google_auth_url(): string
{
    $state = bin2hex(random_bytes(16));
    $nonce = bin2hex(random_bytes(16));
    $verifier = google_b64url(random_bytes(48));
    $_SESSION['google_oauth'] = ['state' => $state, 'nonce' => $nonce, 'verifier' => $verifier, 'time' => time()];
    return 'https://accounts.google.com/o/oauth2/v2/auth?' . http_build_query([
        'client_id' => GOOGLE_CLIENT_ID,
        'redirect_uri' => google_redirect_uri(),
        'response_type' => 'code',
        'scope' => 'openid email profile',
        'state' => $state,
        'nonce' => $nonce,
        'code_challenge' => google_b64url(hash('sha256', $verifier, true)),
        'code_challenge_method' => 'S256',
        'prompt' => 'select_account',
    ], '', '&', PHP_QUERY_RFC3986);
}

/** POST form data to Google's token endpoint. Returns the decoded JSON or null. */
function google_token_request(array $fields): ?array
{
    $ch = curl_init('https://oauth2.googleapis.com/token');
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => http_build_query($fields),
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 15,
        CURLOPT_CONNECTTIMEOUT => 8,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_HTTPHEADER => ['Accept: application/json'],
    ]);
    $body = curl_exec($ch);
    $status = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err = curl_error($ch);
    curl_close($ch);
    if ($body === false || $status !== 200) {
        error_log('Google token request failed (HTTP ' . $status . ') ' . $err);
        return null;
    }
    $json = json_decode((string)$body, true);
    return is_array($json) ? $json : null;
}

/**
 * Read the ID token's claims. The token came straight from Google's token endpoint over TLS,
 * so (per Google's guidance) the signature need not be re-checked; the claims are still validated.
 */
function google_claims(string $idToken, string $nonce): ?array
{
    $parts = explode('.', $idToken);
    if (count($parts) !== 3) {
        return null;
    }
    $claims = json_decode((string)base64_decode(strtr($parts[1], '-_', '+/')), true);
    if (!is_array($claims)) {
        return null;
    }
    $issOk = in_array($claims['iss'] ?? '', ['https://accounts.google.com', 'accounts.google.com'], true);
    $audOk = ($claims['aud'] ?? '') === GOOGLE_CLIENT_ID;
    $expOk = (int)($claims['exp'] ?? 0) > time();
    $nonceOk = isset($claims['nonce']) && hash_equals($nonce, (string)$claims['nonce']);
    $emailOk = !empty($claims['email']) && (($claims['email_verified'] ?? false) === true || ($claims['email_verified'] ?? '') === 'true');
    if (!$issOk || !$audOk || !$expOk || !$nonceOk || !$emailOk || empty($claims['sub'])) {
        return null;
    }
    return $claims;
}

/** Add the users.google_sub column the first time Google sign-in is used. */
function google_ensure_schema(): void
{
    static $done = false;
    if ($done) {
        return;
    }
    $done = true;
    if (!column_exists('users', 'google_sub')) {
        q('ALTER TABLE users ADD COLUMN google_sub VARCHAR(64) NULL');
        try {
            q('CREATE UNIQUE INDEX idx_users_google_sub ON users (google_sub)');
        } catch (Throwable $e) {
            error_log('google_sub index: ' . $e->getMessage());
        }
    }
}

/**
 * Match the Google account to a customer, or create one.
 * Returns [user row|null, error message|null].
 */
function google_find_or_create_customer(array $claims): array
{
    google_ensure_schema();
    $sub = (string)$claims['sub'];
    $email = mb_substr(mb_strtolower(trim((string)$claims['email'])), 0, 150);

    $user = q("SELECT * FROM users WHERE google_sub = ? AND role = 'customer'", [$sub])->fetch();
    if (!$user) {
        $user = q("SELECT * FROM users WHERE email = ? AND role = 'customer'", [$email])->fetch();
        if ($user) {
            if (!empty($user['google_sub']) && $user['google_sub'] !== $sub) {
                return [null, 'This email is already linked to a different Google account.'];
            }
            q('UPDATE users SET google_sub = ? WHERE id = ?', [$sub, (int)$user['id']]); // Google verified the email
            $user['google_sub'] = $sub;
        }
    }
    if ($user) {
        return $user['status'] === 'active'
            ? [$user, null]
            : [null, 'This account is currently disabled. Please contact ' . SITE_NAME . ' support.'];
    }

    // New customer
    $first = trim((string)($claims['given_name'] ?? ''));
    $last = trim((string)($claims['family_name'] ?? ''));
    if ($first === '') {
        $parts = preg_split('/\s+/', trim((string)($claims['name'] ?? '')), 2) ?: [];
        $first = $parts[0] ?? '';
        $last = $last !== '' ? $last : ($parts[1] ?? '');
    }
    $local = strstr($email, '@', true) ?: 'customer';
    if ($first === '') {
        $first = ucfirst(preg_replace('/[^A-Za-z]/', '', $local) ?: 'Customer');
    }
    $first = mb_substr($first, 0, 100);
    $last = mb_substr($last !== '' ? $last : '-', 0, 100);

    $base = substr(preg_replace('/[^a-z0-9_.]/', '', strtolower($local)) ?: 'user', 0, 40);
    if (strlen($base) < 3) { $base .= 'user'; }
    $username = $base;
    for ($i = 0; q('SELECT 1 FROM users WHERE username = ?', [$username])->fetch() && $i < 25; $i++) {
        $username = $base . random_int(100, 99999);
    }

    try {
        $now = date('Y-m-d H:i:s');
        $hash = password_hash(bin2hex(random_bytes(32)), PASSWORD_DEFAULT); // unusable until the customer uses "Forgot password"
        q("INSERT INTO users (first_name, last_name, username, email, phone, password_hash, country, role, status, terms_accepted_at, privacy_accepted_at, google_sub, created_at, updated_at)
           VALUES (?, ?, ?, ?, '', ?, 'Uganda', 'customer', 'active', ?, ?, ?, ?, ?)",
          [$first, $last, $username, $email, $hash, $now, $now, $sub, $now, $now]);
        $user = q('SELECT * FROM users WHERE google_sub = ?', [$sub])->fetch();
        if ($user) {
            admin_notify('customer', 'New customer registered', trim($first . ' ' . $last) . ' (' . $email . ') signed up with Google.', 'admin/customer-details.php?id=' . (int)$user['id']);
            return [$user, null];
        }
    } catch (Throwable $e) {
        error_log('Google sign-up failed: ' . $e->getMessage());
    }
    return [null, 'We could not create your account. Please try again.'];
}

/** The "or continue with [G]" block shown under the login and registration forms. */
function render_google_signin(): void
{
    // Always shown. If Google isn't configured yet, google-login.php explains that when it is clicked.
    ?>
    <div class="social-login">
      <div class="social-divider"><span>or continue with</span></div>
      <a class="google-btn" href="<?= e(url('google-login.php')) ?>" aria-label="Continue with Google" title="Continue with Google">
        <svg viewBox="0 0 48 48" aria-hidden="true"><path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"/><path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"/><path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"/><path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"/></svg>
      </a>
      <p class="social-terms">By continuing you agree to our <a href="<?= e(url('terms.php')) ?>">Terms</a> and <a href="<?= e(url('privacy.php')) ?>">Privacy Policy</a>.</p>
    </div>
    <?php
}

<?php
/**
 * Promotions: database-backed offers with live countdowns on the home page.
 * Managed by admins at admin/promotions.php. All times are Kampala time (UTC+3).
 */

const PROMO_TZ = 'Africa/Kampala';

function promotions_tz(): DateTimeZone
{
    static $tz = null;
    return $tz ??= new DateTimeZone(PROMO_TZ);
}

/** Colour presets built from the store palette (orange #FF7900, cream #FFF9F3, black #111111). */
function promotions_themes(): array
{
    return [
        'orange'   => ['label' => 'Orange & cream', 'from' => '#E86A00', 'to' => '#B84400', 'accent' => '#FFF1DD', 'text' => '#FFFFFF'],
        'cream'    => ['label' => 'Cream & orange', 'from' => '#FFFDF9', 'to' => '#FFE3C4', 'accent' => '#FF7900', 'text' => '#111111'],
        'charcoal' => ['label' => 'Charcoal & orange', 'from' => '#111111', 'to' => '#2B2B2B', 'accent' => '#FF7900', 'text' => '#FFF9F3'],
    ];
}

function promotions_ensure_table(): bool
{
    static $ok = null;
    if ($ok !== null) {
        return $ok;
    }
    try {
        if (!table_exists('promotions')) {
            $sqlite = DB_DRIVER === 'sqlite';
            $id   = $sqlite ? 'INTEGER PRIMARY KEY AUTOINCREMENT' : 'INT AUTO_INCREMENT PRIMARY KEY';
            $dt   = $sqlite ? 'TEXT' : 'DATETIME';
            $tail = $sqlite ? '' : ' ENGINE=InnoDB DEFAULT CHARSET=utf8mb4';
            $t = promotions_themes()['orange'];
            q("CREATE TABLE IF NOT EXISTS promotions (
                id $id,
                badge VARCHAR(60) NOT NULL DEFAULT '',
                title VARCHAR(120) NOT NULL,
                button_text VARCHAR(40) NOT NULL DEFAULT 'Shop the offer',
                link_url VARCHAR(255) NOT NULL DEFAULT 'products.php',
                starts_at $dt NOT NULL,
                ends_at $dt NOT NULL,
                color_from CHAR(7) NOT NULL DEFAULT '{$t['from']}',
                color_to CHAR(7) NOT NULL DEFAULT '{$t['to']}',
                color_accent CHAR(7) NOT NULL DEFAULT '{$t['accent']}',
                color_text CHAR(7) NOT NULL DEFAULT '{$t['text']}',
                sort_order INT NOT NULL DEFAULT 0,
                is_active TINYINT NOT NULL DEFAULT 1,
                created_at $dt NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at $dt NOT NULL DEFAULT CURRENT_TIMESTAMP
            )$tail");
            $seed = [
                ['Black Friday offer', 'Black Friday', '2026-11-01 00:00:00', '2026-11-27 23:59:59', 1],
                ['November offer', 'Black November', '2026-11-01 00:00:00', '2026-11-30 23:59:59', 2],
            ];
            foreach ($seed as [$badge, $title, $from, $to, $sort]) {
                q('INSERT INTO promotions (badge, title, button_text, link_url, starts_at, ends_at, color_from, color_to, color_accent, color_text, sort_order, is_active)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?,1)',
                  [$badge, $title, 'Shop the offer', 'products.php', $from, $to, $t['from'], $t['to'], $t['accent'], $t['text'], $sort]);
            }
        }
        return $ok = true;
    } catch (Throwable $e) {
        error_log('Promotions table unavailable: ' . $e->getMessage());
        return $ok = false;
    }
}

// ---------- Small helpers ----------
function promo_color($v, string $default): string
{
    return is_string($v) && preg_match('/^#[0-9a-fA-F]{6}$/', $v) ? strtoupper($v) : $default;
}

function promo_rgb(string $hex): string
{
    return hexdec(substr($hex, 1, 2)) . ',' . hexdec(substr($hex, 3, 2)) . ',' . hexdec(substr($hex, 5, 2));
}

/** Text colour (dark or white) that reads best on the given background colour. */
function promo_ink(string $hex): string
{
    $lin = function (int $c): float {
        $c /= 255;
        return $c <= 0.03928 ? $c / 12.92 : (($c + 0.055) / 1.055) ** 2.4;
    };
    $l = 0.2126 * $lin((int)hexdec(substr($hex, 1, 2))) + 0.7152 * $lin((int)hexdec(substr($hex, 3, 2))) + 0.0722 * $lin((int)hexdec(substr($hex, 5, 2)));
    $onDark = (1.05) / ($l + 0.05);      // white text
    $onLight = ($l + 0.05) / 0.0556;     // #111111 text
    return $onLight >= $onDark ? '#111111' : '#FFFFFF';
}

function promo_style_vars(array $p): string
{
    $d = promotions_themes()['orange'];
    $from = promo_color($p['color_from'] ?? '', $d['from']);
    $to = promo_color($p['color_to'] ?? '', $d['to']);
    $acc = promo_color($p['color_accent'] ?? '', $d['accent']);
    $txt = promo_color($p['color_text'] ?? '', $d['text']);
    return "--pm-from:$from;--pm-to:$to;--pm-accent:$acc;--pm-ink:" . promo_ink($acc) . ";--pm-text:$txt;"
        . '--pm-from-rgb:' . promo_rgb($from) . ';--pm-accent-rgb:' . promo_rgb($acc) . ';--pm-text-rgb:' . promo_rgb($txt);
}

function promo_link_valid(string $u): bool
{
    return (bool)preg_match('#^https?://\S+$#i', $u) || (bool)preg_match('#^[A-Za-z0-9_\-./?=&%\#]+$#', $u);
}

/** Pickable link targets for the admin form: [label => url] groups. */
function promo_link_options(): array
{
    $out = ['pages' => ['All products' => 'products.php', 'All categories' => 'categories.php'], 'categories' => [], 'products' => []];
    try {
        foreach (q('SELECT name, slug FROM categories ORDER BY sort_order, name')->fetchAll() as $c) {
            $out['categories'][$c['name']] = 'products.php?cat=' . $c['slug'];
        }
        foreach (q('SELECT name, slug FROM products WHERE is_active = 1 ORDER BY name LIMIT 500')->fetchAll() as $r) {
            $out['products'][$r['name']] = 'product.php?slug=' . $r['slug'];
        }
    } catch (Throwable $e) {
        error_log('Promotion link options failed: ' . $e->getMessage());
    }
    return $out;
}

/**
 * Turn what the admin typed into a usable link: a valid address is kept as is, and an exact
 * product or category name (e.g. "2-Plate Electric Hotplate") is converted to that page's link.
 * Returns null when it can't be understood.
 */
function promo_resolve_link(string $input): ?string
{
    $input = trim($input);
    if ($input === '') {
        return 'products.php';
    }
    if (promo_link_valid($input)) {
        return $input;
    }
    $opts = promo_link_options();
    foreach (['products', 'categories'] as $group) {
        foreach ($opts[$group] as $name => $link) {
            if (mb_strtolower($name) === mb_strtolower($input)) {
                return $link;
            }
        }
    }
    return null;
}

function promo_href(string $u): string
{
    $u = trim($u);
    if ($u === '') {
        $u = 'products.php';
    }
    return preg_match('#^https?://#i', $u) ? $u : url($u);
}

function promo_days_left_label(int $seconds): string
{
    $days = intdiv($seconds, 86400);
    if ($days >= 2) { return $days . ' days left'; }
    if ($days === 1) { return '1 day left'; }
    return 'Ends today';
}

function promo_dt(string $value): DateTimeImmutable
{
    return new DateTimeImmutable($value, promotions_tz());
}

/** live | scheduled | ended | hidden */
function promo_status(array $p, ?DateTimeImmutable $now = null): string
{
    $now = $now ?: new DateTimeImmutable('now', promotions_tz());
    if (empty($p['is_active'])) { return 'hidden'; }
    if ($now < promo_dt($p['starts_at'])) { return 'scheduled'; }
    if ($now >= promo_dt($p['ends_at'])) { return 'ended'; }
    return 'live';
}

function promotions_active(?DateTimeImmutable $now = null): array
{
    if (!promotions_ensure_table()) {
        return [];
    }
    $now = $now ?: new DateTimeImmutable('now', promotions_tz());
    $out = [];
    try {
        $rows = q('SELECT * FROM promotions WHERE is_active = 1 ORDER BY sort_order, id')->fetchAll();
    } catch (Throwable $e) {
        error_log('Promotions query failed: ' . $e->getMessage());
        return [];
    }
    foreach ($rows as $p) {
        if (promo_status($p, $now) !== 'live') {
            continue;
        }
        $end = promo_dt($p['ends_at']);
        $p['end_ts'] = $end->getTimestamp();
        $p['remaining'] = max(0, $p['end_ts'] - $now->getTimestamp());
        $out[] = $p;
    }
    return $out;
}

/** One promotion card. $preview = static sample numbers, no live ticking (used in the admin editor). */
function render_promo_card(array $p, bool $preview = false): void
{
    $end = promo_dt($p['ends_at']);
    $s = $preview ? 1409722 : (int)$p['remaining']; // preview: 16d 07h 35m 22s
    $d = intdiv($s, 86400); $h = intdiv($s % 86400, 3600); $m = intdiv($s % 3600, 60); $sec = $s % 60;
    ?>
    <article class="pm-card"<?= $preview ? ' data-promo-preview' : ' data-promo-card data-promo-end="' . (int)$p['end_ts'] . '"' ?> style="<?= e(promo_style_vars($p)) ?>">
      <span class="pm-orb pm-orb-a" aria-hidden="true"></span>
      <span class="pm-orb pm-orb-b" aria-hidden="true"></span>
      <?php for ($i = 1; $i <= 8; $i++): ?><span class="pm-spark pm-spark-<?= $i ?>" aria-hidden="true"></span><?php endfor; ?>
      <div class="pm-body">
        <?php if (($p['badge'] ?? '') !== '' || $preview): ?><span class="pm-badge" data-pv="badge"><?= e($p['badge'] ?? '') ?></span><?php endif; ?>
        <h3 class="pm-title" data-pv="title"><?= e($p['title']) ?></h3>
        <a class="pm-cta" href="<?= $preview ? '#' : e(promo_href($p['link_url'])) ?>"<?= $preview ? ' tabindex="-1" aria-disabled="true"' : '' ?>>
          <span data-pv="button_text"><?= e($p['button_text'] ?: 'Shop the offer') ?></span>
          <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg>
        </a>
        <span class="pm-left">
          <svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>
          <b data-promo-left><?= e(promo_days_left_label($s)) ?></b>
        </span>
        <div class="pm-timer"<?= $preview ? '' : ' role="timer" aria-label="' . e($p['title']) . ' time remaining"' ?>>
          <div class="pm-unit"><b data-unit="days"><?= sprintf('%02d', $d) ?></b><small>Days</small></div>
          <div class="pm-unit"><b data-unit="hours"><?= sprintf('%02d', $h) ?></b><small>Hours</small></div>
          <div class="pm-unit"><b data-unit="mins"><?= sprintf('%02d', $m) ?></b><small>Mins</small></div>
          <div class="pm-unit"><b data-unit="secs" class="pm-secs"><?= sprintf('%02d', $sec) ?></b><small>Secs</small></div>
        </div>
        <p class="pm-valid">Valid until the end of <span data-pv="valid"><?= e($end->format('l j F Y')) ?></span></p>
      </div>
    </article>
    <?php
}

function render_promotions(): void
{
    $promos = promotions_active();
    if (!$promos) {
        return;
    }
    ?>
<section class="pm" aria-labelledby="pm-heading" data-promo-section data-server-now="<?= time() ?>">
  <div class="pm-head">
    <h2 id="pm-heading">Promotion of the month</h2>
    <span class="pm-rule" aria-hidden="true"></span>
    <p>Limited-time offers. Each one ends on the date shown, so don&rsquo;t wait too long.</p>
  </div>
  <div class="pm-grid<?= count($promos) === 1 ? ' pm-grid-single' : '' ?>">
    <?php foreach ($promos as $p) { render_promo_card($p); } ?>
  </div>
</section>
    <?php
}

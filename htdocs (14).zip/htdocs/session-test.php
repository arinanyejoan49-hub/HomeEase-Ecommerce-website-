<?php
// TEMPORARY diagnostic. Delete this file after use.
session_set_cookie_params(['path'=>'/','httponly'=>true,'samesite'=>'Lax',
  'secure'=>!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS']!=='off']);
session_name('homeease_sid');
$ok = @session_start();
$_SESSION['hits'] = ($_SESSION['hits'] ?? 0) + 1;
header('Content-Type: text/plain'); header('Cache-Control: no-store');
echo "session_start ok : " . var_export($ok, true) . "\n";
echo "hits (should go 1,2,3 on each refresh): " . $_SESSION['hits'] . "\n";
echo "cookie received  : " . (isset($_COOKIE['homeease_sid']) ? 'yes' : 'NO (first load is normal; after refresh must be yes)') . "\n";
echo "scheme PHP sees  : " . ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS']!=='off') ? 'https' : 'http') . "\n";
echo "X-Forwarded-Proto: " . ($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '(none)') . "\n";
echo "host             : " . ($_SERVER['HTTP_HOST'] ?? '') . "\n";
$sp = session_save_path();
echo "save path        : " . ($sp === '' ? '(default)' : $sp) . "  writable: " . var_export($sp === '' ? null : is_writable($sp), true) . "\n";
echo "cookie names     : " . implode(', ', array_keys($_COOKIE)) . "\n";

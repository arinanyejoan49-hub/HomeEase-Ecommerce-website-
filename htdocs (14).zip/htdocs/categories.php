<?php
require __DIR__ . '/includes/bootstrap.php';
require __DIR__ . '/includes/card.php';

$title = 'Categories';
$desc = 'Browse all appliance categories.';
$here = 'categories.php';
require __DIR__ . '/includes/header.php';

$cats = q('SELECT c.*, (SELECT COUNT(*) FROM products p WHERE p.category_id = c.id AND p.is_active = 1) AS n FROM categories c ORDER BY sort_order, name')->fetchAll();
?>
<h1>Categories</h1>
<p>Browse appliances by category.</p>
<div class="cat-grid">
  <?php foreach ($cats as $c): $categoryMedia = category_media($c); ?>
    <a class="cat" href="<?= e(url('products.php?cat=' . $c['slug'])) ?>">
      <?php if ($categoryMedia !== ''): ?>
        <?= $categoryMedia ?>
      <?php else: ?>
        <span class="ico"><?= e($c['icon'] ?? '📦') ?></span>
      <?php endif; ?>
      <b><?= e($c['name']) ?></b>
      <small><?= (int)$c['n'] ?> products</small>
    </a>
  <?php endforeach; ?>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>

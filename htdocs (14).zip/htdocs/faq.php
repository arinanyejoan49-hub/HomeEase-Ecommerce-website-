<?php
require __DIR__ . '/includes/bootstrap.php';
$title = 'Frequently asked questions';
$here = 'faq.php';

$faqs = [];
if (table_exists('faqs')) {
    $faqs = q('SELECT question, answer FROM faqs WHERE is_published = 1 ORDER BY sort_order, id')->fetchAll();
}
if (!$faqs) {
    $faqs = [
        ['question' => 'Are your appliances genuine?', 'answer' => 'Yes. We source from authorised distributors and every appliance comes with a manufacturer or store warranty of 12 to 24 months, stated on each product page.'],
        ['question' => 'How long does delivery take?', 'answer' => 'Within Masaka City 1 to 2 working days, around Masaka 2 to 3 days and the rest of Uganda 3 to 6 days. See the Delivery page for fees and details.'],
        ['question' => 'What payment methods do you accept?', 'answer' => (pesajet_enabled() ? 'MTN or Airtel mobile money, or cash on delivery. For mobile money you approve a prompt sent to your phone.' : 'MTN or Airtel mobile money, card, or cash on delivery. Card and mobile-money payments are simulated; no real money is taken.')],
        ['question' => 'Can I return an item?', 'answer' => 'Yes. Faulty or wrong items can be returned within 7 days of delivery. Unused items in original packaging can be returned within 7 days for a refund or exchange minus delivery cost. See Returns & warranty.'],
        ['question' => 'Do appliances work with Uganda power supply?', 'answer' => 'All items are rated for 220 to 240 V, 50 Hz, the Ugandan standard. We also sell surge-protected extensions and solar lamps for outages.'],
        ['question' => 'Is there a student discount?', 'answer' => 'Yes. Use code STUDENT10 in your cart for 10% off. Our Student Starter Bundle is also reduced.'],
        ['question' => 'Do you keep my card details?', 'answer' => 'No. Card details are checked and discarded. We keep only the last four digits for your receipt.'],
    ];
}
require __DIR__ . '/includes/header.php';
?>
<h1>Frequently asked questions</h1>
<div class="faq">
  <?php foreach ($faqs as $f): ?>
    <details><summary><?= e($f['question']) ?></summary><p><?= e($f['answer']) ?></p></details>
  <?php endforeach; ?>
</div>
<p>Still stuck? <a class="btn small" href="<?= e(url('contact.php')) ?>">Contact support</a></p>
<?php require __DIR__ . '/includes/footer.php'; ?>
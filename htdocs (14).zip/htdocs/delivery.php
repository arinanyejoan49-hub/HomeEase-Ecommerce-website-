<?php
require __DIR__ . '/includes/bootstrap.php';
$title = 'Delivery information';
require __DIR__ . '/includes/header.php';
?>
<h1>Delivery information</h1>
<p class="lead">We deliver to your door across Uganda, and you can also collect from our store in Masaka.</p>
<table class="data">
  <thead><tr><th>Option</th><th>Fee</th><th>Estimated time</th></tr></thead>
  <tbody>
    <?php foreach (ZONES as $z): ?>
      <tr><td><?= e($z[0]) ?></td><td><?= $z[1] ? e(money($z[1])) : 'Free' ?></td><td><?= e($z[2]) ?></td></tr>
    <?php endforeach; ?>
  </tbody>
</table>
<p><strong>Free delivery</strong> in Masaka City and around Masaka when your order (after discounts) is <?= e(money(FREE_DELIVERY_FROM)) ?> or more.</p>

<h2>How it works</h2>
<ol class="steps">
  <li><b>You order.</b> You receive an order number straight after checkout.</li>
  <li><b>We confirm.</b> We call you on the number you gave to agree a delivery time.</li>
  <li><b>We dispatch.</b> Masaka orders go by our riders and vans. Orders to the rest of Uganda, including Kampala, go by courier or bus, packed in protective boxes, and we send you the driver or bus details.</li>
  <li><b>You inspect and receive.</b> Check the item with the rider. Report any damage on the spot, or within 48 hours.</li>
</ol>
<h2>Good to know</h2>
<ul>
  <li>Delivery times are working days (Mon to Sat) after confirmation and are estimates, not guarantees.</li>
  <li>Please give a clear address with a landmark. Boda boda and van drivers rely on it.</li>
  <li>Cash on delivery is available in Masaka City and around Masaka.</li>
  <li>Track any order with your order number and email on the <a href="<?= e(url('track.php')) ?>">tracking page</a>.</li>
</ul>
<?php require __DIR__ . '/includes/footer.php'; ?>

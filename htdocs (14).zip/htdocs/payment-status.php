<?php
// Polled by order-success.php while a mobile-money payment is pending.
require __DIR__ . '/includes/bootstrap.php';

header('Content-Type: application/json');
header('Cache-Control: no-store');

$no = is_string($_GET['no'] ?? '') ? $_GET['no'] : '';
if ($no === '' || ($_SESSION['last_order'] ?? '') !== $no) {
    http_response_code(403);
    exit(json_encode(['state' => 'unknown']));
}

$o = q('SELECT payment_status FROM orders WHERE order_no = ?', [$no])->fetch();
if (!$o) {
    http_response_code(404);
    exit(json_encode(['state' => 'unknown']));
}

// Fallback in case the webhook has not reached us: ask PesaJet directly (at most every 4s).
if ($o['payment_status'] === 'awaiting payment' && pesajet_enabled()
    && time() - (int)($_SESSION['pj_last_check'] ?? 0) >= 4) {
    $_SESSION['pj_last_check'] = time();
    session_write_close();
    pesajet_refresh_order($no);
    $o = q('SELECT payment_status FROM orders WHERE order_no = ?', [$no])->fetch();
}

$ps = (string)$o['payment_status'];
$state = $ps === 'awaiting payment' ? 'pending' : (str_starts_with($ps, 'paid') ? 'paid' : 'failed');
echo json_encode(['state' => $state, 'payment_status' => $ps]);
